window.KG_GRAPH = {
  "meta": {
    "topicKey": "topic-02",
    "topicName": "恶心呕吐症状管理",
    "subtitle": "面向患者的恶心呕吐症状管理知识图谱（含文献出处层）",
    "generatedAt": "2026-11-02"
  },
  "nodeTypes": [
    {
      "key": "DiseaseCategory",
      "label": "疾病分类",
      "color": "#5B7C99",
      "shape": "round",
      "size": 22,
      "desc": "疾病大类"
    },
    {
      "key": "SymptomSign",
      "label": "症状体征",
      "color": "#C0563F",
      "shape": "diamond",
      "size": 18,
      "desc": "可观察到的体征"
    },
    {
      "key": "Exam",
      "label": "检查项目",
      "color": "#2F855A",
      "shape": "round",
      "size": 20,
      "desc": "检查 / 检验 / 用药"
    },
    {
      "key": "ManagementPrinciple",
      "label": "处置原则",
      "color": "#6B46C1",
      "shape": "round",
      "size": 18,
      "desc": "护理处置原则"
    },
    {
      "key": "NursingTheory",
      "label": "护理理论",
      "color": "#975A16",
      "shape": "triangle",
      "size": 20,
      "desc": "护理理论框架"
    },
    {
      "key": "DiseaseEducation",
      "label": "疾病教育",
      "color": "#2B6CB0",
      "shape": "round",
      "size": 18,
      "desc": "健康宣教内容"
    },
    {
      "key": "SymptomExperience",
      "label": "症状体验",
      "color": "#B83280",
      "shape": "diamond",
      "size": 18,
      "desc": "患者主观症状体验"
    },
    {
      "key": "ManagementStrategy",
      "label": "管理策略",
      "color": "#2C7A7B",
      "shape": "round",
      "size": 18,
      "desc": "症状管理策略"
    },
    {
      "key": "ManagementOutcome",
      "label": "管理效果",
      "color": "#38A169",
      "shape": "round",
      "size": 18,
      "desc": "症状管理结果"
    },
    {
      "key": "SymptomCategory",
      "label": "症状分类",
      "color": "#B7791F",
      "shape": "triangle",
      "size": 20,
      "desc": "症状大类"
    },
    {
      "key": "AssessmentTool",
      "label": "评估工具",
      "color": "#4A5568",
      "shape": "round",
      "size": 18,
      "desc": "评估量表 / 工具"
    },
    {
      "key": "RiskFactor",
      "label": "危险因素",
      "color": "#9B2C2C",
      "shape": "triangle",
      "size": 20,
      "desc": "风险因素"
    },
    {
      "key": "PharmacologicalManagement",
      "label": "药物治疗",
      "color": "#276749",
      "shape": "round",
      "size": 18,
      "desc": "用药处置"
    },
    {
      "key": "NonPharmacologicalManagement",
      "label": "非药物管理",
      "color": "#285E61",
      "shape": "round",
      "size": 18,
      "desc": "非药物处置"
    },
    {
      "key": "SymptomStatus",
      "label": "症状状态",
      "color": "#5A67D8",
      "shape": "round",
      "size": 16,
      "desc": "症状当前状态"
    },
    {
      "key": "FunctionalStatus",
      "label": "功能状态",
      "color": "#6B46C1",
      "shape": "round",
      "size": 16,
      "desc": "功能受影响程度"
    },
    {
      "key": "Reference",
      "label": "文献",
      "color": "#718096",
      "shape": "round",
      "size": 16,
      "desc": "文献出处节点"
    },
    {
      "key": "CaseReport",
      "label": "个案",
      "color": "#A0AEC0",
      "shape": "round",
      "size": 16,
      "desc": "个案（本期零节点）"
    }
  ],
  "relationTypes": [
    {
      "key": "BELONGS_TO",
      "label": "属于",
      "desc": "属于"
    },
    {
      "key": "HAS_SYMPTOM",
      "label": "存在症状",
      "desc": "存在症状"
    },
    {
      "key": "DETECTED_BY",
      "label": "通过检查发现",
      "desc": "通过检查发现"
    },
    {
      "key": "MANAGED_BY",
      "label": "由……处置",
      "desc": "由……处置"
    },
    {
      "key": "EDUCATED_BY",
      "label": "由……教育",
      "desc": "由……教育"
    },
    {
      "key": "EXPERIENCED_AS",
      "label": "表现为",
      "desc": "表现为"
    },
    {
      "key": "ASSESSED_BY",
      "label": "由……评估",
      "desc": "由……评估"
    },
    {
      "key": "AT_RISK_BY",
      "label": "风险来自",
      "desc": "风险来自"
    },
    {
      "key": "TREATED_BY",
      "label": "由……治疗",
      "desc": "由……治疗"
    },
    {
      "key": "EFFECT_ON",
      "label": "影响",
      "desc": "影响"
    },
    {
      "key": "PART_OF_CASE",
      "label": "属于个案",
      "desc": "属于个案"
    },
    {
      "key": "SUPPORTED_BY",
      "label": "有文献支持",
      "desc": "有文献支持"
    }
  ],
  "nodes": [
    {
      "id": "t02-exp-nausea",
      "name": "恶心",
      "type": "SymptomExperience",
      "graph": "topic-02",
      "tags": [
        "症状",
        "恶心呕吐",
        "核心症状"
      ],
      "aliases": [
        "恶心",
        "nausea",
        "Nausea",
        "恶心感",
        "反胃",
        "想吐",
        "恶心（nausea）"
      ],
      "summary": "恶心是一种想吐、咽部或上腹部不适的感觉，常伴出汗、乏力、流口水。它常常先于呕吐出现，也可以只恶心不呕吐。",
      "attrs": [
        {
          "k": "中文名",
          "v": "恶心"
        },
        {
          "k": "英文名",
          "v": "Nausea"
        },
        {
          "k": "典型表现",
          "v": "咽部不适 · 上腹不适 · 唾液增多 · 出汗乏力"
        },
        {
          "k": "常见伴随",
          "v": "干呕 · 食欲下降 · 体重下降"
        }
      ],
      "evidence": [
        {
          "type": "最佳证据",
          "author": "Zheng P, Ou Y, Jiang J, Liu H, Mo X, Li J",
          "title": "癌症患者化疗相关恶心呕吐评估与管理的最佳证据总结",
          "journal": "长江医学",
          "year": 2023,
          "grade": "最佳证据总结",
          "locate": "DOI 10.4236/ym.2023.71004",
          "ref": "R16",
          "cite": "Zheng P, Ou Y, Jiang J, Liu H, Mo X, Li J/癌症患者化疗相关恶心呕吐评估与管理的最佳证据总结/长江医学/2023"
        },
        {
          "type": "声明",
          "author": "Vidall C, Dielenseger P, Farrell C, et al.",
          "title": "化疗相关恶心呕吐的循证管理：欧洲肿瘤护理论坛立场声明",
          "journal": "欧洲癌症医学科学",
          "year": 2011,
          "grade": "学会立场声明",
          "locate": "PMID 22276054 · DOI 10.3332/ecancer.2011.211",
          "ref": "R13",
          "cite": "Vidall C, Dielenseger P, Farrell C, et al./化疗相关恶心呕吐的循证管理：欧洲肿瘤护理论坛立场声明/欧洲癌症医学科学/2011"
        },
        {
          "type": "指南",
          "author": "Herrstedt J, Clark-Snow R, Ruhlmann CH, et al.",
          "title": "2023 年国际癌症支持治疗协会与欧洲肿瘤内科学会指南更新：化疗及放疗相关恶心呕吐的预防",
          "journal": "欧洲肿瘤内科学会开放版",
          "year": 2024,
          "grade": "指南（最新版本）",
          "locate": "PMID 38458657 · DOI 10.1016/j.esmoop.2023.102195",
          "ref": "R02",
          "cite": "Herrstedt J, Clark-Snow R, Ruhlmann CH, et al./2023 年国际癌症支持治疗协会与欧洲肿瘤内科学会指南更新：化疗及放疗相关恶心呕吐的预防/欧洲肿瘤内科学会开放版/2024"
        }
      ]
    },
    {
      "id": "t02-exp-vomiting",
      "name": "呕吐",
      "type": "SymptomExperience",
      "graph": "topic-02",
      "tags": [
        "症状",
        "恶心呕吐",
        "核心症状"
      ],
      "aliases": [
        "呕吐",
        "vomiting",
        "Vomiting",
        "emesis",
        "呕吐物",
        "喷射性呕吐",
        "呕吐（vomiting）"
      ],
      "summary": "呕吐是胃内容物经口强烈排出的动作，可分为呕吐前（恶心、流涎）、呕吐中（内容物排出）、呕吐后（乏力、面色苍白）。",
      "attrs": [
        {
          "k": "中文名",
          "v": "呕吐"
        },
        {
          "k": "英文名",
          "v": "Vomiting"
        },
        {
          "k": "典型表现",
          "v": "胃内容物经口排出"
        },
        {
          "k": "常见伴随",
          "v": "脱水 · 电解质紊乱 · 误吸风险"
        }
      ],
      "evidence": [
        {
          "type": "最佳证据",
          "author": "Zheng P, Ou Y, Jiang J, Liu H, Mo X, Li J",
          "title": "癌症患者化疗相关恶心呕吐评估与管理的最佳证据总结",
          "journal": "长江医学",
          "year": 2023,
          "grade": "最佳证据总结",
          "locate": "DOI 10.4236/ym.2023.71004",
          "ref": "R16",
          "cite": "Zheng P, Ou Y, Jiang J, Liu H, Mo X, Li J/癌症患者化疗相关恶心呕吐评估与管理的最佳证据总结/长江医学/2023"
        },
        {
          "type": "声明",
          "author": "Vidall C, Dielenseger P, Farrell C, et al.",
          "title": "化疗相关恶心呕吐的循证管理：欧洲肿瘤护理论坛立场声明",
          "journal": "欧洲癌症医学科学",
          "year": 2011,
          "grade": "学会立场声明",
          "locate": "PMID 22276054 · DOI 10.3332/ecancer.2011.211",
          "ref": "R13",
          "cite": "Vidall C, Dielenseger P, Farrell C, et al./化疗相关恶心呕吐的循证管理：欧洲肿瘤护理论坛立场声明/欧洲癌症医学科学/2011"
        },
        {
          "type": "系统评价",
          "author": "Matthews A, Haas DM, O'Mathúna DP, Dowswell T, Doyle M",
          "title": "妊娠早期恶心呕吐的干预措施",
          "journal": "考克兰系统评价数据库",
          "year": 2015,
          "grade": "系统评价",
          "locate": "DOI 10.1002/14651858.CD007575.pub4",
          "ref": "R18",
          "cite": "Matthews A, Haas DM, O'Mathúna DP, Dowswell T, Doyle M/妊娠早期恶心呕吐的干预措施/考克兰系统评价数据库/2015"
        }
      ]
    },
    {
      "id": "t02-cat-cinv",
      "name": "化疗相关恶心呕吐",
      "type": "SymptomCategory",
      "graph": "topic-02",
      "tags": [
        "症状分类",
        "化疗",
        "肿瘤"
      ],
      "aliases": [
        "化疗相关恶心呕吐",
        "CINV",
        "chemotherapy-induced nausea and vomiting",
        "化疗致恶心呕吐",
        "化疗引起的恶心呕吐",
        "肿瘤化疗呕吐",
        "抗肿瘤治疗相关恶心呕吐"
      ],
      "summary": "抗肿瘤药物治疗引起的恶心呕吐。按发作时间分为急性（给药后24小时内）、延迟性（24小时后，最常见）、预期性（化疗前就出现）和爆发性（预防用药后仍发生）。",
      "attrs": [
        {
          "k": "英文缩写",
          "v": "CINV"
        },
        {
          "k": "分类依据",
          "v": "给药后时间 + 发作情形"
        },
        {
          "k": "背景",
          "v": "抗肿瘤药物治疗（化疗 · 靶向 · 免疫治疗）"
        },
        {
          "k": "高发人群",
          "v": "使用高致吐风险方案的患者"
        }
      ],
      "evidence": [
        {
          "type": "指南",
          "author": "Hesketh PJ, Kris MG, Basch E, et al.",
          "title": "止吐药物：美国临床肿瘤学会指南更新",
          "journal": "临床肿瘤学杂志",
          "year": 2020,
          "grade": "指南（最新版本）",
          "locate": "PMID 32658626 · DOI 10.1200/JCO.20.01296",
          "ref": "R01",
          "cite": "Hesketh PJ, Kris MG, Basch E, et al./止吐药物：美国临床肿瘤学会指南更新/临床肿瘤学杂志/2020"
        },
        {
          "type": "指南",
          "author": "Herrstedt J, Clark-Snow R, Ruhlmann CH, et al.",
          "title": "2023 年国际癌症支持治疗协会与欧洲肿瘤内科学会指南更新：化疗及放疗相关恶心呕吐的预防",
          "journal": "欧洲肿瘤内科学会开放版",
          "year": 2024,
          "grade": "指南（最新版本）",
          "locate": "PMID 38458657 · DOI 10.1016/j.esmoop.2023.102195",
          "ref": "R02",
          "cite": "Herrstedt J, Clark-Snow R, Ruhlmann CH, et al./2023 年国际癌症支持治疗协会与欧洲肿瘤内科学会指南更新：化疗及放疗相关恶心呕吐的预防/欧洲肿瘤内科学会开放版/2024"
        },
        {
          "type": "推荐",
          "author": "Herrstedt J, Celio L, Hesketh PJ, et al.",
          "title": "2023 年国际癌症支持治疗协会与欧洲肿瘤内科学会共识更新：高致吐风险抗肿瘤药物所致恶心呕吐的预防",
          "journal": "癌症支持治疗",
          "year": 2023,
          "grade": "共识推荐条目",
          "locate": "PMID 38127246 · DOI 10.1007/s00520-023-08221-4",
          "ref": "R12",
          "cite": "Herrstedt J, Celio L, Hesketh PJ, et al./2023 年国际癌症支持治疗协会与欧洲肿瘤内科学会共识更新：高致吐风险抗肿瘤药物所致恶心呕吐的预防/癌症支持治疗/2023"
        },
        {
          "type": "共识",
          "author": "中国抗癌协会肿瘤临床化疗专业委员会, 中国抗癌协会肿瘤支持治疗专业委员会",
          "title": "中国肿瘤药物治疗相关恶心呕吐防治专家共识（2022年版）",
          "journal": "中华医学杂志",
          "year": 2022,
          "grade": "专家共识",
          "locate": "DOI 10.3760/cma.j.cn112137-20220810-01724",
          "ref": "R06",
          "cite": "中国抗癌协会肿瘤临床化疗专业委员会, 中国抗癌协会肿瘤支持治疗专业委员会/中国肿瘤药物治疗相关恶心呕吐防治专家共识（2022年版）/中华医学杂志/2022"
        },
        {
          "type": "指南",
          "author": "美国国家综合癌症网络",
          "title": "美国国家综合癌症网络肿瘤临床实践指南：止吐（2025 年第 2 版）",
          "journal": "美国国家综合癌症网络",
          "year": 2025,
          "grade": "指南（最新版本）",
          "locate": "https://www.nccn.org/guidelines/guidelines-detail?category=3&id=1415",
          "ref": "R03",
          "cite": "美国国家综合癌症网络/美国国家综合癌症网络肿瘤临床实践指南：止吐（2025 年第 2 版）/美国国家综合癌症网络/2025"
        }
      ]
    },
    {
      "id": "t02-cat-rinv",
      "name": "放疗相关恶心呕吐",
      "type": "SymptomCategory",
      "graph": "topic-02",
      "tags": [
        "症状分类",
        "放疗",
        "肿瘤"
      ],
      "aliases": [
        "放疗相关恶心呕吐",
        "RINV",
        "radiotherapy-induced nausea and vomiting",
        "放疗致恶心呕吐"
      ],
      "summary": "放射治疗引起的恶心呕吐，分为急性（治疗开始24小时内）与延迟性（治疗开始24小时后，多见于上腹部照射）。",
      "attrs": [
        {
          "k": "英文缩写",
          "v": "RINV"
        },
        {
          "k": "分类依据",
          "v": "放疗开始后时间"
        },
        {
          "k": "好发部位",
          "v": "上腹部及腹部照射"
        }
      ],
      "evidence": [
        {
          "type": "指南",
          "author": "Herrstedt J, Clark-Snow R, Ruhlmann CH, et al.",
          "title": "2023 年国际癌症支持治疗协会与欧洲肿瘤内科学会指南更新：化疗及放疗相关恶心呕吐的预防",
          "journal": "欧洲肿瘤内科学会开放版",
          "year": 2024,
          "grade": "指南（最新版本）",
          "locate": "PMID 38458657 · DOI 10.1016/j.esmoop.2023.102195",
          "ref": "R02",
          "cite": "Herrstedt J, Clark-Snow R, Ruhlmann CH, et al./2023 年国际癌症支持治疗协会与欧洲肿瘤内科学会指南更新：化疗及放疗相关恶心呕吐的预防/欧洲肿瘤内科学会开放版/2024"
        },
        {
          "type": "指南",
          "author": "Hesketh PJ, Kris MG, Basch E, et al.",
          "title": "止吐药物：美国临床肿瘤学会指南更新",
          "journal": "临床肿瘤学杂志",
          "year": 2020,
          "grade": "指南（最新版本）",
          "locate": "PMID 32658626 · DOI 10.1200/JCO.20.01296",
          "ref": "R01",
          "cite": "Hesketh PJ, Kris MG, Basch E, et al./止吐药物：美国临床肿瘤学会指南更新/临床肿瘤学杂志/2020"
        }
      ]
    },
    {
      "id": "t02-cat-nvp",
      "name": "妊娠期恶心呕吐",
      "type": "SymptomCategory",
      "graph": "topic-02",
      "tags": [
        "症状分类",
        "妊娠",
        "妇产科"
      ],
      "aliases": [
        "妊娠期恶心呕吐",
        "NVP",
        "nausea and vomiting of pregnancy",
        "pregnancy nausea and vomiting",
        "孕吐",
        "妊娠呕吐",
        "早孕反应"
      ],
      "summary": "妊娠早期最常见的症状，见于约 70%–90% 的孕妇。按严重程度分为轻度、中度和重度，重度即妊娠剧吐。",
      "attrs": [
        {
          "k": "英文缩写",
          "v": "NVP"
        },
        {
          "k": "高发时点",
          "v": "妊娠 6–9 周起"
        },
        {
          "k": "自然病程",
          "v": "多数于 16–20 周后缓解"
        }
      ],
      "evidence": [
        {
          "type": "指南",
          "author": "Nelson-Piercy C, Dean C, Shehmar M, et al.",
          "title": "妊娠期恶心呕吐与妊娠剧吐的管理（英国皇家妇产科医学院绿皮书第 69 号）",
          "journal": "国际妇产科杂志",
          "year": 2024,
          "grade": "指南（最新版本）",
          "locate": "PMID 38311315",
          "ref": "R04",
          "cite": "Nelson-Piercy C, Dean C, Shehmar M, et al./妊娠期恶心呕吐与妊娠剧吐的管理（英国皇家妇产科医学院绿皮书第 69 号）/国际妇产科杂志/2024"
        },
        {
          "type": "系统评价",
          "author": "Matthews A, Haas DM, O'Mathúna DP, Dowswell T, Doyle M",
          "title": "妊娠早期恶心呕吐的干预措施",
          "journal": "考克兰系统评价数据库",
          "year": 2015,
          "grade": "系统评价",
          "locate": "DOI 10.1002/14651858.CD007575.pub4",
          "ref": "R18",
          "cite": "Matthews A, Haas DM, O'Mathúna DP, Dowswell T, Doyle M/妊娠早期恶心呕吐的干预措施/考克兰系统评价数据库/2015"
        },
        {
          "type": "建议",
          "author": "世界卫生组织",
          "title": "世界卫生组织关于产前保健促进积极妊娠体验的建议",
          "journal": "世界卫生组织",
          "year": 2016,
          "grade": "指南推荐条目",
          "locate": "ISBN 9789241549912 · 推荐条目 D.1",
          "ref": "R11",
          "cite": "世界卫生组织/世界卫生组织关于产前保健促进积极妊娠体验的建议/世界卫生组织/2016"
        }
      ]
    },
    {
      "id": "t02-cat-hg",
      "name": "妊娠剧吐",
      "type": "SymptomCategory",
      "graph": "topic-02",
      "tags": [
        "症状分类",
        "妊娠",
        "重症"
      ],
      "aliases": [
        "妊娠剧吐",
        "HG",
        "hyperemesis gravidarum",
        "妊娠剧烈呕吐",
        "严重妊娠呕吐",
        "妊娠剧吐（HG）"
      ],
      "summary": "妊娠期恶心呕吐的严重类型：持续呕吐导致进食饮水困难、体重下降超过 5%、脱水、电解质紊乱和酮症，需要住院静脉补液与药物治疗。",
      "attrs": [
        {
          "k": "英文缩写",
          "v": "HG"
        },
        {
          "k": "严重度判据",
          "v": "体重下降>5% + 脱水 + 电解质紊乱"
        },
        {
          "k": "处理层级",
          "v": "需医疗干预，必要时住院"
        }
      ],
      "evidence": [
        {
          "type": "指南",
          "author": "Nelson-Piercy C, Dean C, Shehmar M, et al.",
          "title": "妊娠期恶心呕吐与妊娠剧吐的管理（英国皇家妇产科医学院绿皮书第 69 号）",
          "journal": "国际妇产科杂志",
          "year": 2024,
          "grade": "指南（最新版本）",
          "locate": "PMID 38311315",
          "ref": "R04",
          "cite": "Nelson-Piercy C, Dean C, Shehmar M, et al./妊娠期恶心呕吐与妊娠剧吐的管理（英国皇家妇产科医学院绿皮书第 69 号）/国际妇产科杂志/2024"
        },
        {
          "type": "系统评价",
          "author": "Matthews A, Haas DM, O'Mathúna DP, Dowswell T, Doyle M",
          "title": "妊娠早期恶心呕吐的干预措施",
          "journal": "考克兰系统评价数据库",
          "year": 2015,
          "grade": "系统评价",
          "locate": "DOI 10.1002/14651858.CD007575.pub4",
          "ref": "R18",
          "cite": "Matthews A, Haas DM, O'Mathúna DP, Dowswell T, Doyle M/妊娠早期恶心呕吐的干预措施/考克兰系统评价数据库/2015"
        },
        {
          "type": "最佳证据",
          "author": "Zheng P, Ou Y, Jiang J, Liu H, Mo X, Li J",
          "title": "癌症患者化疗相关恶心呕吐评估与管理的最佳证据总结",
          "journal": "长江医学",
          "year": 2023,
          "grade": "最佳证据总结",
          "locate": "DOI 10.4236/ym.2023.71004",
          "ref": "R16",
          "cite": "Zheng P, Ou Y, Jiang J, Liu H, Mo X, Li J/癌症患者化疗相关恶心呕吐评估与管理的最佳证据总结/长江医学/2023"
        }
      ]
    },
    {
      "id": "t02-cat-ponv",
      "name": "术后恶心呕吐",
      "type": "SymptomCategory",
      "graph": "topic-02",
      "tags": [
        "症状分类",
        "外科",
        "麻醉"
      ],
      "aliases": [
        "术后恶心呕吐",
        "PONV",
        "postoperative nausea and vomiting",
        "术后呕吐",
        "麻醉后恶心呕吐",
        "术后恶心"
      ],
      "summary": "手术后24小时内发生的恶心呕吐，与麻醉药、阿片类镇痛、手术类型和患者自身风险因素相关，整体发生率约 30%，高危患者可达 80%。",
      "attrs": [
        {
          "k": "英文缩写",
          "v": "PONV"
        },
        {
          "k": "时间窗",
          "v": "术后 24 小时内"
        },
        {
          "k": "主要诱因",
          "v": "吸入麻醉药 · 阿片类镇痛 · 女性 · 非吸烟 · 晕动史"
        }
      ],
      "evidence": [
        {
          "type": "共识",
          "author": "Gan TJ, Jin Z, Ayad S, et al.",
          "title": "术后恶心呕吐管理第五版共识指南（摘要）",
          "journal": "麻醉与镇痛",
          "year": 2025,
          "grade": "专家共识（最新版本）",
          "locate": "PMID 41237407 · DOI 10.1213/ANE.0000000000007816",
          "ref": "R05",
          "cite": "Gan TJ, Jin Z, Ayad S, et al./术后恶心呕吐管理第五版共识指南（摘要）/麻醉与镇痛/2025"
        },
        {
          "type": "指南",
          "author": "Hesketh PJ, Kris MG, Basch E, et al.",
          "title": "止吐药物：美国临床肿瘤学会指南更新",
          "journal": "临床肿瘤学杂志",
          "year": 2020,
          "grade": "指南（最新版本）",
          "locate": "PMID 32658626 · DOI 10.1200/JCO.20.01296",
          "ref": "R01",
          "cite": "Hesketh PJ, Kris MG, Basch E, et al./止吐药物：美国临床肿瘤学会指南更新/临床肿瘤学杂志/2020"
        }
      ]
    },
    {
      "id": "t02-cat-acute",
      "name": "急性恶心呕吐",
      "type": "SymptomCategory",
      "graph": "topic-02",
      "tags": [
        "症状分类",
        "时间分型"
      ],
      "aliases": [
        "急性恶心呕吐",
        "acute nausea and vomiting",
        "急性期恶心呕吐",
        "急性呕吐"
      ],
      "summary": "症状出现后数小时内达到高峰的类型。化疗相关恶心呕吐中，给药后 24 小时内出现的即属急性型。",
      "attrs": [
        {
          "k": "时间窗",
          "v": "化疗给药后 0–24 小时"
        },
        {
          "k": "主要用药",
          "v": "5-HT3 受体拮抗剂 + 地塞米松"
        }
      ],
      "evidence": [
        {
          "type": "指南",
          "author": "Herrstedt J, Clark-Snow R, Ruhlmann CH, et al.",
          "title": "2023 年国际癌症支持治疗协会与欧洲肿瘤内科学会指南更新：化疗及放疗相关恶心呕吐的预防",
          "journal": "欧洲肿瘤内科学会开放版",
          "year": 2024,
          "grade": "指南（最新版本）",
          "locate": "PMID 38458657 · DOI 10.1016/j.esmoop.2023.102195",
          "ref": "R02",
          "cite": "Herrstedt J, Clark-Snow R, Ruhlmann CH, et al./2023 年国际癌症支持治疗协会与欧洲肿瘤内科学会指南更新：化疗及放疗相关恶心呕吐的预防/欧洲肿瘤内科学会开放版/2024"
        },
        {
          "type": "推荐",
          "author": "Herrstedt J, Celio L, Hesketh PJ, et al.",
          "title": "2023 年国际癌症支持治疗协会与欧洲肿瘤内科学会共识更新：高致吐风险抗肿瘤药物所致恶心呕吐的预防",
          "journal": "癌症支持治疗",
          "year": 2023,
          "grade": "共识推荐条目",
          "locate": "PMID 38127246 · DOI 10.1007/s00520-023-08221-4",
          "ref": "R12",
          "cite": "Herrstedt J, Celio L, Hesketh PJ, et al./2023 年国际癌症支持治疗协会与欧洲肿瘤内科学会共识更新：高致吐风险抗肿瘤药物所致恶心呕吐的预防/癌症支持治疗/2023"
        },
        {
          "type": "共识",
          "author": "中国抗癌协会肿瘤临床化疗专业委员会, 中国抗癌协会肿瘤支持治疗专业委员会",
          "title": "中国肿瘤药物治疗相关恶心呕吐防治专家共识（2022年版）",
          "journal": "中华医学杂志",
          "year": 2022,
          "grade": "专家共识",
          "locate": "DOI 10.3760/cma.j.cn112137-20220810-01724",
          "ref": "R06",
          "cite": "中国抗癌协会肿瘤临床化疗专业委员会, 中国抗癌协会肿瘤支持治疗专业委员会/中国肿瘤药物治疗相关恶心呕吐防治专家共识（2022年版）/中华医学杂志/2022"
        }
      ]
    },
    {
      "id": "t02-cat-delayed",
      "name": "延迟性恶心呕吐",
      "type": "SymptomCategory",
      "graph": "topic-02",
      "tags": [
        "症状分类",
        "时间分型"
      ],
      "aliases": [
        "延迟性恶心呕吐",
        "delayed nausea and vomiting",
        "迟发性恶心呕吐",
        "延迟呕吐"
      ],
      "summary": "急性期之后才出现的类型，常在化疗开始后 24 小时至第 5 天发生，是化疗相关恶心呕吐中最常见、也最难控制的一型。",
      "attrs": [
        {
          "k": "时间窗",
          "v": "化疗开始后 24 小时至第 5 天"
        },
        {
          "k": "主要用药",
          "v": "5-HT3 受体拮抗剂 + NK-1 受体拮抗剂（+奥氮平）"
        }
      ],
      "evidence": [
        {
          "type": "指南",
          "author": "Herrstedt J, Clark-Snow R, Ruhlmann CH, et al.",
          "title": "2023 年国际癌症支持治疗协会与欧洲肿瘤内科学会指南更新：化疗及放疗相关恶心呕吐的预防",
          "journal": "欧洲肿瘤内科学会开放版",
          "year": 2024,
          "grade": "指南（最新版本）",
          "locate": "PMID 38458657 · DOI 10.1016/j.esmoop.2023.102195",
          "ref": "R02",
          "cite": "Herrstedt J, Clark-Snow R, Ruhlmann CH, et al./2023 年国际癌症支持治疗协会与欧洲肿瘤内科学会指南更新：化疗及放疗相关恶心呕吐的预防/欧洲肿瘤内科学会开放版/2024"
        },
        {
          "type": "推荐",
          "author": "Herrstedt J, Celio L, Hesketh PJ, et al.",
          "title": "2023 年国际癌症支持治疗协会与欧洲肿瘤内科学会共识更新：高致吐风险抗肿瘤药物所致恶心呕吐的预防",
          "journal": "癌症支持治疗",
          "year": 2023,
          "grade": "共识推荐条目",
          "locate": "PMID 38127246 · DOI 10.1007/s00520-023-08221-4",
          "ref": "R12",
          "cite": "Herrstedt J, Celio L, Hesketh PJ, et al./2023 年国际癌症支持治疗协会与欧洲肿瘤内科学会共识更新：高致吐风险抗肿瘤药物所致恶心呕吐的预防/癌症支持治疗/2023"
        },
        {
          "type": "共识",
          "author": "中国抗癌协会肿瘤临床化疗专业委员会, 中国抗癌协会肿瘤支持治疗专业委员会",
          "title": "中国肿瘤药物治疗相关恶心呕吐防治专家共识（2022年版）",
          "journal": "中华医学杂志",
          "year": 2022,
          "grade": "专家共识",
          "locate": "DOI 10.3760/cma.j.cn112137-20220810-01724",
          "ref": "R06",
          "cite": "中国抗癌协会肿瘤临床化疗专业委员会, 中国抗癌协会肿瘤支持治疗专业委员会/中国肿瘤药物治疗相关恶心呕吐防治专家共识（2022年版）/中华医学杂志/2022"
        }
      ]
    },
    {
      "id": "t02-cat-anticipatory",
      "name": "预期性恶心呕吐",
      "type": "SymptomCategory",
      "graph": "topic-02",
      "tags": [
        "症状分类",
        "时间分型",
        "心理"
      ],
      "aliases": [
        "预期性恶心呕吐",
        "anticipatory nausea and vomiting",
        "预期性反应",
        "预期性恶心"
      ],
      "summary": "在化疗开始前、看到输液架或一闻到化疗室气味就出现的恶心呕吐，与以往化疗时的强烈体验和焦虑有关，主要靠心理支持与行为干预处理。",
      "attrs": [
        {
          "k": "发生时机",
          "v": "化疗开始之前"
        },
        {
          "k": "核心机制",
          "v": "条件反射 + 焦虑"
        },
        {
          "k": "主要处理",
          "v": "行为干预 + 穴位刺激 + 健康教育"
        }
      ],
      "evidence": [
        {
          "type": "共识",
          "author": "中国抗癌协会肿瘤临床化疗专业委员会, 中国抗癌协会肿瘤支持治疗专业委员会",
          "title": "中国肿瘤药物治疗相关恶心呕吐防治专家共识（2022年版）",
          "journal": "中华医学杂志",
          "year": 2022,
          "grade": "专家共识",
          "locate": "DOI 10.3760/cma.j.cn112137-20220810-01724",
          "ref": "R06",
          "cite": "中国抗癌协会肿瘤临床化疗专业委员会, 中国抗癌协会肿瘤支持治疗专业委员会/中国肿瘤药物治疗相关恶心呕吐防治专家共识（2022年版）/中华医学杂志/2022"
        },
        {
          "type": "共识",
          "author": "《四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识》编写专家组",
          "title": "四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识2024版",
          "journal": "中国循证医学杂志",
          "year": 2024,
          "grade": "专家共识",
          "locate": "DOI 10.7507/1672-2531.202407066",
          "ref": "R07",
          "cite": "《四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识》编写专家组/四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识2024版/中国循证医学杂志/2024"
        },
        {
          "type": "指南",
          "author": "Herrstedt J, Clark-Snow R, Ruhlmann CH, et al.",
          "title": "2023 年国际癌症支持治疗协会与欧洲肿瘤内科学会指南更新：化疗及放疗相关恶心呕吐的预防",
          "journal": "欧洲肿瘤内科学会开放版",
          "year": 2024,
          "grade": "指南（最新版本）",
          "locate": "PMID 38458657 · DOI 10.1016/j.esmoop.2023.102195",
          "ref": "R02",
          "cite": "Herrstedt J, Clark-Snow R, Ruhlmann CH, et al./2023 年国际癌症支持治疗协会与欧洲肿瘤内科学会指南更新：化疗及放疗相关恶心呕吐的预防/欧洲肿瘤内科学会开放版/2024"
        }
      ]
    },
    {
      "id": "t02-cat-breakthrough",
      "name": "爆发性恶心呕吐",
      "type": "SymptomCategory",
      "graph": "topic-02",
      "tags": [
        "症状分类",
        "处理分型"
      ],
      "aliases": [
        "爆发性恶心呕吐",
        "breakthrough nausea and vomiting",
        "难治性恶心呕吐",
        "爆发性呕吐"
      ],
      "summary": "已经按预防方案用药仍然发生的恶心呕吐。处理原则是换用与预防用药作用机制不同的药物，同时重新评估风险与支持治疗。",
      "attrs": [
        {
          "k": "发生条件",
          "v": "规范预防后仍出现"
        },
        {
          "k": "处理原则",
          "v": "换机制 + 重新评估 + 支持治疗"
        }
      ],
      "evidence": [
        {
          "type": "指南",
          "author": "Herrstedt J, Clark-Snow R, Ruhlmann CH, et al.",
          "title": "2023 年国际癌症支持治疗协会与欧洲肿瘤内科学会指南更新：化疗及放疗相关恶心呕吐的预防",
          "journal": "欧洲肿瘤内科学会开放版",
          "year": 2024,
          "grade": "指南（最新版本）",
          "locate": "PMID 38458657 · DOI 10.1016/j.esmoop.2023.102195",
          "ref": "R02",
          "cite": "Herrstedt J, Clark-Snow R, Ruhlmann CH, et al./2023 年国际癌症支持治疗协会与欧洲肿瘤内科学会指南更新：化疗及放疗相关恶心呕吐的预防/欧洲肿瘤内科学会开放版/2024"
        },
        {
          "type": "推荐",
          "author": "Herrstedt J, Celio L, Hesketh PJ, et al.",
          "title": "2023 年国际癌症支持治疗协会与欧洲肿瘤内科学会共识更新：高致吐风险抗肿瘤药物所致恶心呕吐的预防",
          "journal": "癌症支持治疗",
          "year": 2023,
          "grade": "共识推荐条目",
          "locate": "PMID 38127246 · DOI 10.1007/s00520-023-08221-4",
          "ref": "R12",
          "cite": "Herrstedt J, Celio L, Hesketh PJ, et al./2023 年国际癌症支持治疗协会与欧洲肿瘤内科学会共识更新：高致吐风险抗肿瘤药物所致恶心呕吐的预防/癌症支持治疗/2023"
        },
        {
          "type": "指南",
          "author": "Hesketh PJ, Kris MG, Basch E, et al.",
          "title": "止吐药物：美国临床肿瘤学会指南更新",
          "journal": "临床肿瘤学杂志",
          "year": 2020,
          "grade": "指南（最新版本）",
          "locate": "PMID 32658626 · DOI 10.1200/JCO.20.01296",
          "ref": "R01",
          "cite": "Hesketh PJ, Kris MG, Basch E, et al./止吐药物：美国临床肿瘤学会指南更新/临床肿瘤学杂志/2020"
        }
      ]
    },
    {
      "id": "t02-tool-ctca",
      "name": "CTCAE 不良反应评价标准 v5.0",
      "type": "AssessmentTool",
      "graph": "topic-02",
      "tags": [
        "评估工具",
        "量表",
        "通用"
      ],
      "aliases": [
        "CTCAE",
        "CTCAE v5.0",
        "CTCAE 5.0",
        "Common Terminology Criteria for Adverse Events",
        "不良反应评价标准",
        "CTCAE不良反应评价标准",
        "CTCAE评分标准"
      ],
      "summary": "美国国家癌症研究所的不良反应评价标准，把恶心、呕吐按严重程度分为 1–5 级：1 级轻微、2 级需要干预、3 级严重影响自理、4 级危及生命、5 级死亡。国际多中心抗肿瘤药物临床试验通用。",
      "attrs": [
        {
          "k": "版本",
          "v": "v5.0"
        },
        {
          "k": "分级",
          "v": "1–5 级"
        },
        {
          "k": "适用",
          "v": "肿瘤治疗相关不良反应的统一描述"
        }
      ],
      "evidence": [
        {
          "type": "标准",
          "author": "美国国立卫生研究院·国家癌症研究所",
          "title": "不良事件通用术语标准（CTCAE 第 5.0 版）",
          "journal": "美国国家癌症研究所",
          "year": 2017,
          "grade": "标准文本",
          "locate": "https://ctep.cancer.gov/protocoldevelopment/electronic_applications/ctc.htm",
          "ref": "R08",
          "cite": "美国国立卫生研究院, 美国国家癌症研究所/不良事件通用术语标准（CTCAE 第 5.0 版）/美国国家癌症研究所/2017"
        }
      ]
    },
    {
      "id": "t02-tool-eortc-qlq-c30",
      "name": "EORTC QLQ-C30 肿瘤生活质量问卷",
      "type": "AssessmentTool",
      "graph": "topic-02",
      "tags": [
        "评估工具",
        "量表",
        "生活质量"
      ],
      "aliases": [
        "EORTC QLQ-C30",
        "QLQ-C30",
        "肿瘤生活质量问卷",
        "EORTC QLQ-C30量表",
        "EORTC生活质量问卷",
        "生活质量问卷"
      ],
      "summary": "欧洲癌症研究与治疗组织开发的核心生活质量问卷（30 项），含恶心、呕吐、食欲下降、整体健康状况等 15 个分量表，0–100 分，用于评估症状对生活质量的影响。",
      "attrs": [
        {
          "k": "条目数",
          "v": "30 项 · 15 个分量表"
        },
        {
          "k": "计分",
          "v": "0–100 分"
        },
        {
          "k": "适用",
          "v": "症状对生活质量影响的量化"
        }
      ],
      "evidence": [
        {
          "type": "标准",
          "author": "Fayers PM, Aaronson NK, Bjordal K, Groenvold M, Curran D, Bottomley A",
          "title": "肿瘤患者生活质量问卷（EORTC QLQ-C30）评分手册（第 3 版）",
          "journal": "欧洲癌症研究与治疗组织",
          "year": 2001,
          "grade": "标准文本（量表与评分标准）",
          "locate": "ISBN 2-930064-22-6",
          "ref": "R09",
          "cite": "Fayers PM, Aaronson NK, Bjordal K, Groenvold M, Curran D, Bottomley A/肿瘤患者生活质量问卷（EORTC QLQ-C30）评分手册（第 3 版）/欧洲癌症研究与治疗组织/2001"
        },
        {
          "type": "最佳证据",
          "author": "Zheng P, Ou Y, Jiang J, Liu H, Mo X, Li J",
          "title": "癌症患者化疗相关恶心呕吐评估与管理的最佳证据总结",
          "journal": "长江医学",
          "year": 2023,
          "grade": "最佳证据总结",
          "locate": "DOI 10.4236/ym.2023.71004",
          "ref": "R16",
          "cite": "Zheng P, Ou Y, Jiang J, Liu H, Mo X, Li J/癌症患者化疗相关恶心呕吐评估与管理的最佳证据总结/长江医学/2023"
        }
      ]
    },
    {
      "id": "t02-tool-mascc-mat",
      "name": "MASCC 止吐自评工具",
      "type": "AssessmentTool",
      "graph": "topic-02",
      "tags": [
        "评估工具",
        "量表",
        "化疗"
      ],
      "aliases": [
        "MASCC止吐自评工具",
        "MASCC Antiemesis Tool",
        "MAT",
        "MASCC量表",
        "MASCC止吐工具",
        "恶心呕吐严重程度量表",
        "MASCC 止吐自评工具"
      ],
      "summary": "8 项患者自评量表，分急性期（0–24 小时）和延迟期（24–120 小时）分别记录呕吐次数、恶心程度和补救止吐药使用情况，是目前应用最广的化疗相关恶心呕吐疗效评价工具之一。",
      "attrs": [
        {
          "k": "条目数",
          "v": "8 项"
        },
        {
          "k": "时间分段",
          "v": "急性期 / 延迟期"
        },
        {
          "k": "核心指标",
          "v": "完全缓解（无呕吐、无需补救药）"
        }
      ],
      "evidence": [
        {
          "type": "标准",
          "author": "Molassiotis A, Coventry PA, Stricker CT, et al.",
          "title": "化疗相关恶心呕吐简明临床量表的验证与心理测量学评价：国际癌症支持治疗协会止吐自评工具",
          "journal": "疼痛与症状管理杂志",
          "year": 2007,
          "grade": "标准文本（量表信效度验证）",
          "locate": "PMID 17509816 · DOI 10.1016/j.jpainsymman.2006.10.018",
          "ref": "R10",
          "cite": "Molassiotis A, Coventry PA, Stricker CT, et al./化疗相关恶心呕吐简明临床量表的验证与心理测量学评价：国际癌症支持治疗协会止吐自评工具/疼痛与症状管理杂志/2007"
        },
        {
          "type": "最佳证据",
          "author": "Zheng P, Ou Y, Jiang J, Liu H, Mo X, Li J",
          "title": "癌症患者化疗相关恶心呕吐评估与管理的最佳证据总结",
          "journal": "长江医学",
          "year": 2023,
          "grade": "最佳证据总结",
          "locate": "DOI 10.4236/ym.2023.71004",
          "ref": "R16",
          "cite": "Zheng P, Ou Y, Jiang J, Liu H, Mo X, Li J/癌症患者化疗相关恶心呕吐评估与管理的最佳证据总结/长江医学/2023"
        }
      ]
    },
    {
      "id": "t02-tool-apfel",
      "name": "Apfel 简化风险评分",
      "type": "AssessmentTool",
      "graph": "topic-02",
      "tags": [
        "评估工具",
        "风险评分",
        "围术期"
      ],
      "aliases": [
        "Apfel简化风险评分",
        "Apfel评分",
        "Apfel score",
        "术后恶心呕吐风险评分",
        "简化风险评分"
      ],
      "summary": "术后恶心呕吐风险的四因素简化评分：女性、非吸烟、晕动病史、术后阿片类镇痛各计 1 分。0 分为低危（发生率约 10%），1–2 分为中危（20%–40%），3–4 分为高危（60%–80%）。",
      "attrs": [
        {
          "k": "因素数",
          "v": "4 项"
        },
        {
          "k": "分值范围",
          "v": "0–4 分"
        },
        {
          "k": "用途",
          "v": "术前分层决定预防强度"
        }
      ],
      "evidence": [
        {
          "type": "共识",
          "author": "Gan TJ, Jin Z, Ayad S, et al.",
          "title": "术后恶心呕吐管理第五版共识指南（摘要）",
          "journal": "麻醉与镇痛",
          "year": 2025,
          "grade": "专家共识（最新版本）",
          "locate": "PMID 41237407 · DOI 10.1213/ANE.0000000000007816",
          "ref": "R05",
          "cite": "Gan TJ, Jin Z, Ayad S, et al./术后恶心呕吐管理第五版共识指南（摘要）/麻醉与镇痛/2025"
        },
        {
          "type": "指南",
          "author": "Hesketh PJ, Kris MG, Basch E, et al.",
          "title": "止吐药物：美国临床肿瘤学会指南更新",
          "journal": "临床肿瘤学杂志",
          "year": 2020,
          "grade": "指南（最新版本）",
          "locate": "PMID 32658626 · DOI 10.1200/JCO.20.01296",
          "ref": "R01",
          "cite": "Hesketh PJ, Kris MG, Basch E, et al./止吐药物：美国临床肿瘤学会指南更新/临床肿瘤学杂志/2020"
        }
      ]
    },
    {
      "id": "t02-tool-puqe",
      "name": "PUQE 妊娠剧吐严重程度评分",
      "type": "AssessmentTool",
      "graph": "topic-02",
      "tags": [
        "评估工具",
        "评分",
        "妊娠"
      ],
      "aliases": [
        "PUQE",
        "PUQE评分",
        "妊娠剧吐严重度评分",
        "Pregnancy-Unique Quantified Emesis",
        "妊娠剧吐严重程度评分"
      ],
      "summary": "用妊娠指数、呕吐次数和进食受限程度三项评估妊娠剧吐严重度（0–13 分，≥7 分提示需要治疗），是国际通用的妊娠剧吐严重度分级工具。",
      "attrs": [
        {
          "k": "条目数",
          "v": "3 项"
        },
        {
          "k": "总分",
          "v": "0–13 分"
        },
        {
          "k": "阈值",
          "v": "≥7 分提示需要治疗"
        }
      ],
      "evidence": [
        {
          "type": "指南",
          "author": "Nelson-Piercy C, Dean C, Shehmar M, et al.",
          "title": "妊娠期恶心呕吐与妊娠剧吐的管理（英国皇家妇产科医学院绿皮书第 69 号）",
          "journal": "国际妇产科杂志",
          "year": 2024,
          "grade": "指南（最新版本）",
          "locate": "PMID 38311315",
          "ref": "R04",
          "cite": "Nelson-Piercy C, Dean C, Shehmar M, et al./妊娠期恶心呕吐与妊娠剧吐的管理（英国皇家妇产科医学院绿皮书第 69 号）/国际妇产科杂志/2024"
        },
        {
          "type": "系统评价",
          "author": "Matthews A, Haas DM, O'Mathúna DP, Dowswell T, Doyle M",
          "title": "妊娠早期恶心呕吐的干预措施",
          "journal": "考克兰系统评价数据库",
          "year": 2015,
          "grade": "系统评价",
          "locate": "DOI 10.1002/14651858.CD007575.pub4",
          "ref": "R18",
          "cite": "Matthews A, Haas DM, O'Mathúna DP, Dowswell T, Doyle M/妊娠早期恶心呕吐的干预措施/考克兰系统评价数据库/2015"
        }
      ]
    },
    {
      "id": "t02-risk-female",
      "name": "女性",
      "type": "RiskFactor",
      "graph": "topic-02",
      "tags": [
        "高危因素",
        "人口学"
      ],
      "aliases": [
        "女性",
        "female",
        "female sex",
        "女性性别",
        "性别女"
      ],
      "summary": "女性是化疗相关恶心呕吐和术后恶心呕吐最一致的高危因素之一，可能与激素波动、焦虑概率较高有关。",
      "attrs": [
        {
          "k": "类别",
          "v": "人口学因素"
        },
        {
          "k": "适用",
          "v": "化疗相关与术后恶心呕吐"
        }
      ],
      "evidence": [
        {
          "type": "指南",
          "author": "Hesketh PJ, Kris MG, Basch E, et al.",
          "title": "止吐药物：美国临床肿瘤学会指南更新",
          "journal": "临床肿瘤学杂志",
          "year": 2020,
          "grade": "指南（最新版本）",
          "locate": "PMID 32658626 · DOI 10.1200/JCO.20.01296",
          "ref": "R01",
          "cite": "Hesketh PJ, Kris MG, Basch E, et al./止吐药物：美国临床肿瘤学会指南更新/临床肿瘤学杂志/2020"
        },
        {
          "type": "指南",
          "author": "Herrstedt J, Clark-Snow R, Ruhlmann CH, et al.",
          "title": "2023 年国际癌症支持治疗协会与欧洲肿瘤内科学会指南更新：化疗及放疗相关恶心呕吐的预防",
          "journal": "欧洲肿瘤内科学会开放版",
          "year": 2024,
          "grade": "指南（最新版本）",
          "locate": "PMID 38458657 · DOI 10.1016/j.esmoop.2023.102195",
          "ref": "R02",
          "cite": "Herrstedt J, Clark-Snow R, Ruhlmann CH, et al./2023 年国际癌症支持治疗协会与欧洲肿瘤内科学会指南更新：化疗及放疗相关恶心呕吐的预防/欧洲肿瘤内科学会开放版/2024"
        },
        {
          "type": "共识",
          "author": "Gan TJ, Jin Z, Ayad S, et al.",
          "title": "术后恶心呕吐管理第五版共识指南（摘要）",
          "journal": "麻醉与镇痛",
          "year": 2025,
          "grade": "专家共识（最新版本）",
          "locate": "PMID 41237407 · DOI 10.1213/ANE.0000000000007816",
          "ref": "R05",
          "cite": "Gan TJ, Jin Z, Ayad S, et al./术后恶心呕吐管理第五版共识指南（摘要）/麻醉与镇痛/2025"
        }
      ]
    },
    {
      "id": "t02-risk-young-age",
      "name": "年龄较轻",
      "type": "RiskFactor",
      "graph": "topic-02",
      "tags": [
        "高危因素",
        "人口学"
      ],
      "aliases": [
        "年龄较轻",
        "年轻",
        "younger age",
        "50岁以下",
        "年龄小于50岁"
      ],
      "summary": "在化疗相关恶心呕吐中，年龄小于 50 岁者风险更高；而在术后恶心呕吐中，年龄较大者风险更高，需按具体场景分别判断。",
      "attrs": [
        {
          "k": "类别",
          "v": "人口学因素"
        },
        {
          "k": "注意",
          "v": "方向随场景不同：化疗偏年轻，术后偏年长"
        }
      ],
      "evidence": [
        {
          "type": "共识",
          "author": "《四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识》编写专家组",
          "title": "四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识2024版",
          "journal": "中国循证医学杂志",
          "year": 2024,
          "grade": "专家共识",
          "locate": "DOI 10.7507/1672-2531.202407066",
          "ref": "R07",
          "cite": "《四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识》编写专家组/四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识2024版/中国循证医学杂志/2024"
        },
        {
          "type": "指南",
          "author": "Herrstedt J, Clark-Snow R, Ruhlmann CH, et al.",
          "title": "2023 年国际癌症支持治疗协会与欧洲肿瘤内科学会指南更新：化疗及放疗相关恶心呕吐的预防",
          "journal": "欧洲肿瘤内科学会开放版",
          "year": 2024,
          "grade": "指南（最新版本）",
          "locate": "PMID 38458657 · DOI 10.1016/j.esmoop.2023.102195",
          "ref": "R02",
          "cite": "Herrstedt J, Clark-Snow R, Ruhlmann CH, et al./2023 年国际癌症支持治疗协会与欧洲肿瘤内科学会指南更新：化疗及放疗相关恶心呕吐的预防/欧洲肿瘤内科学会开放版/2024"
        },
        {
          "type": "共识",
          "author": "中国抗癌协会肿瘤临床化疗专业委员会, 中国抗癌协会肿瘤支持治疗专业委员会",
          "title": "中国肿瘤药物治疗相关恶心呕吐防治专家共识（2022年版）",
          "journal": "中华医学杂志",
          "year": 2022,
          "grade": "专家共识",
          "locate": "DOI 10.3760/cma.j.cn112137-20220810-01724",
          "ref": "R06",
          "cite": "中国抗癌协会肿瘤临床化疗专业委员会, 中国抗癌协会肿瘤支持治疗专业委员会/中国肿瘤药物治疗相关恶心呕吐防治专家共识（2022年版）/中华医学杂志/2022"
        }
      ]
    },
    {
      "id": "t02-risk-non-smoker",
      "name": "非吸烟者",
      "type": "RiskFactor",
      "graph": "topic-02",
      "tags": [
        "高危因素",
        "生活方式"
      ],
      "aliases": [
        "非吸烟",
        "不吸烟",
        "non-smoker",
        "non-smoking",
        "无吸烟史"
      ],
      "summary": "有吸烟史的人发生术后恶心呕吐的概率低于不吸烟者，因此非吸烟者属于术后恶心呕吐的高危人群。",
      "attrs": [
        {
          "k": "类别",
          "v": "生活方式因素"
        },
        {
          "k": "适用",
          "v": "术后恶心呕吐"
        }
      ],
      "evidence": [
        {
          "type": "共识",
          "author": "Gan TJ, Jin Z, Ayad S, et al.",
          "title": "术后恶心呕吐管理第五版共识指南（摘要）",
          "journal": "麻醉与镇痛",
          "year": 2025,
          "grade": "专家共识（最新版本）",
          "locate": "PMID 41237407 · DOI 10.1213/ANE.0000000000007816",
          "ref": "R05",
          "cite": "Gan TJ, Jin Z, Ayad S, et al./术后恶心呕吐管理第五版共识指南（摘要）/麻醉与镇痛/2025"
        },
        {
          "type": "指南",
          "author": "Hesketh PJ, Kris MG, Basch E, et al.",
          "title": "止吐药物：美国临床肿瘤学会指南更新",
          "journal": "临床肿瘤学杂志",
          "year": 2020,
          "grade": "指南（最新版本）",
          "locate": "PMID 32658626 · DOI 10.1200/JCO.20.01296",
          "ref": "R01",
          "cite": "Hesketh PJ, Kris MG, Basch E, et al./止吐药物：美国临床肿瘤学会指南更新/临床肿瘤学杂志/2020"
        }
      ]
    },
    {
      "id": "t02-risk-motion-sickness",
      "name": "晕动病史",
      "type": "RiskFactor",
      "graph": "topic-02",
      "tags": [
        "高危因素",
        "病史"
      ],
      "aliases": [
        "晕动病史",
        "晕动症",
        "motion sickness",
        "既往晕动史",
        "晕车史"
      ],
      "summary": "以往乘车、乘船时出现恶心呕吐的病史，提示前庭系统对运动刺激敏感，是术后恶心呕吐的独立高危因素。",
      "attrs": [
        {
          "k": "类别",
          "v": "病史因素"
        },
        {
          "k": "机制",
          "v": "前庭系统敏感"
        }
      ],
      "evidence": [
        {
          "type": "共识",
          "author": "Gan TJ, Jin Z, Ayad S, et al.",
          "title": "术后恶心呕吐管理第五版共识指南（摘要）",
          "journal": "麻醉与镇痛",
          "year": 2025,
          "grade": "专家共识（最新版本）",
          "locate": "PMID 41237407 · DOI 10.1213/ANE.0000000000007816",
          "ref": "R05",
          "cite": "Gan TJ, Jin Z, Ayad S, et al./术后恶心呕吐管理第五版共识指南（摘要）/麻醉与镇痛/2025"
        },
        {
          "type": "指南",
          "author": "Hesketh PJ, Kris MG, Basch E, et al.",
          "title": "止吐药物：美国临床肿瘤学会指南更新",
          "journal": "临床肿瘤学杂志",
          "year": 2020,
          "grade": "指南（最新版本）",
          "locate": "PMID 32658626 · DOI 10.1200/JCO.20.01296",
          "ref": "R01",
          "cite": "Hesketh PJ, Kris MG, Basch E, et al./止吐药物：美国临床肿瘤学会指南更新/临床肿瘤学杂志/2020"
        }
      ]
    },
    {
      "id": "t02-risk-prior-nv",
      "name": "既往恶心呕吐史",
      "type": "RiskFactor",
      "graph": "topic-02",
      "tags": [
        "高危因素",
        "病史"
      ],
      "aliases": [
        "既往恶心呕吐史",
        "既往化疗呕吐史",
        "previous nausea and vomiting history",
        "既往呕吐史",
        "previous PONV"
      ],
      "summary": "以往化疗或手术中曾发生严重恶心呕吐的经历，会明显提高再次发生的概率，并常伴随预期性恶心呕吐。",
      "attrs": [
        {
          "k": "类别",
          "v": "病史因素"
        },
        {
          "k": "为什么重要",
          "v": "既是风险因素，也是预期性反应的来源"
        }
      ],
      "evidence": [
        {
          "type": "指南",
          "author": "Herrstedt J, Clark-Snow R, Ruhlmann CH, et al.",
          "title": "2023 年国际癌症支持治疗协会与欧洲肿瘤内科学会指南更新：化疗及放疗相关恶心呕吐的预防",
          "journal": "欧洲肿瘤内科学会开放版",
          "year": 2024,
          "grade": "指南（最新版本）",
          "locate": "PMID 38458657 · DOI 10.1016/j.esmoop.2023.102195",
          "ref": "R02",
          "cite": "Herrstedt J, Clark-Snow R, Ruhlmann CH, et al./2023 年国际癌症支持治疗协会与欧洲肿瘤内科学会指南更新：化疗及放疗相关恶心呕吐的预防/欧洲肿瘤内科学会开放版/2024"
        },
        {
          "type": "共识",
          "author": "Gan TJ, Jin Z, Ayad S, et al.",
          "title": "术后恶心呕吐管理第五版共识指南（摘要）",
          "journal": "麻醉与镇痛",
          "year": 2025,
          "grade": "专家共识（最新版本）",
          "locate": "PMID 41237407 · DOI 10.1213/ANE.0000000000007816",
          "ref": "R05",
          "cite": "Gan TJ, Jin Z, Ayad S, et al./术后恶心呕吐管理第五版共识指南（摘要）/麻醉与镇痛/2025"
        },
        {
          "type": "共识",
          "author": "中国抗癌协会肿瘤临床化疗专业委员会, 中国抗癌协会肿瘤支持治疗专业委员会",
          "title": "中国肿瘤药物治疗相关恶心呕吐防治专家共识（2022年版）",
          "journal": "中华医学杂志",
          "year": 2022,
          "grade": "专家共识",
          "locate": "DOI 10.3760/cma.j.cn112137-20220810-01724",
          "ref": "R06",
          "cite": "中国抗癌协会肿瘤临床化疗专业委员会, 中国抗癌协会肿瘤支持治疗专业委员会/中国肿瘤药物治疗相关恶心呕吐防治专家共识（2022年版）/中华医学杂志/2022"
        }
      ]
    },
    {
      "id": "t02-risk-anxiety",
      "name": "焦虑",
      "type": "RiskFactor",
      "graph": "topic-02",
      "tags": [
        "高危因素",
        "心理"
      ],
      "aliases": [
        "焦虑",
        "焦虑状态",
        "anxiety",
        "预期性焦虑",
        "情绪焦虑"
      ],
      "summary": "焦虑状态与预期性恶心呕吐的发生和加重密切相关，需要在治疗前给予心理支持与行为干预。",
      "attrs": [
        {
          "k": "类别",
          "v": "心理因素"
        },
        {
          "k": "最相关场景",
          "v": "预期性恶心呕吐"
        }
      ],
      "evidence": [
        {
          "type": "共识",
          "author": "《四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识》编写专家组",
          "title": "四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识2024版",
          "journal": "中国循证医学杂志",
          "year": 2024,
          "grade": "专家共识",
          "locate": "DOI 10.7507/1672-2531.202407066",
          "ref": "R07",
          "cite": "《四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识》编写专家组/四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识2024版/中国循证医学杂志/2024"
        },
        {
          "type": "共识",
          "author": "中国抗癌协会肿瘤临床化疗专业委员会, 中国抗癌协会肿瘤支持治疗专业委员会",
          "title": "中国肿瘤药物治疗相关恶心呕吐防治专家共识（2022年版）",
          "journal": "中华医学杂志",
          "year": 2022,
          "grade": "专家共识",
          "locate": "DOI 10.3760/cma.j.cn112137-20220810-01724",
          "ref": "R06",
          "cite": "中国抗癌协会肿瘤临床化疗专业委员会, 中国抗癌协会肿瘤支持治疗专业委员会/中国肿瘤药物治疗相关恶心呕吐防治专家共识（2022年版）/中华医学杂志/2022"
        },
        {
          "type": "声明",
          "author": "Vidall C, Dielenseger P, Farrell C, et al.",
          "title": "化疗相关恶心呕吐的循证管理：欧洲肿瘤护理论坛立场声明",
          "journal": "欧洲癌症医学科学",
          "year": 2011,
          "grade": "学会立场声明",
          "locate": "PMID 22276054 · DOI 10.3332/ecancer.2011.211",
          "ref": "R13",
          "cite": "Vidall C, Dielenseger P, Farrell C, et al./化疗相关恶心呕吐的循证管理：欧洲肿瘤护理论坛立场声明/欧洲癌症医学科学/2011"
        }
      ]
    },
    {
      "id": "t02-risk-opioid",
      "name": "术后阿片类镇痛",
      "type": "RiskFactor",
      "graph": "topic-02",
      "tags": [
        "高危因素",
        "用药"
      ],
      "aliases": [
        "术后阿片类镇痛",
        "阿片类药物",
        "opioid",
        "术后阿片类药物",
        "麻醉性镇痛药",
        "阿片类镇痛药"
      ],
      "summary": "术后使用阿片类镇痛药物是术后恶心呕吐的独立高危因素，因此必须纳入预防方案，并配合多模式镇痛减少用量。",
      "attrs": [
        {
          "k": "类别",
          "v": "用药因素"
        },
        {
          "k": "处理",
          "v": "镇痛同时兼顾止吐，减少阿片用量"
        }
      ],
      "evidence": [
        {
          "type": "共识",
          "author": "Gan TJ, Jin Z, Ayad S, et al.",
          "title": "术后恶心呕吐管理第五版共识指南（摘要）",
          "journal": "麻醉与镇痛",
          "year": 2025,
          "grade": "专家共识（最新版本）",
          "locate": "PMID 41237407 · DOI 10.1213/ANE.0000000000007816",
          "ref": "R05",
          "cite": "Gan TJ, Jin Z, Ayad S, et al./术后恶心呕吐管理第五版共识指南（摘要）/麻醉与镇痛/2025"
        },
        {
          "type": "指南",
          "author": "Hesketh PJ, Kris MG, Basch E, et al.",
          "title": "止吐药物：美国临床肿瘤学会指南更新",
          "journal": "临床肿瘤学杂志",
          "year": 2020,
          "grade": "指南（最新版本）",
          "locate": "PMID 32658626 · DOI 10.1200/JCO.20.01296",
          "ref": "R01",
          "cite": "Hesketh PJ, Kris MG, Basch E, et al./止吐药物：美国临床肿瘤学会指南更新/临床肿瘤学杂志/2020"
        }
      ]
    },
    {
      "id": "t02-risk-sleep-disturbance",
      "name": "睡眠障碍",
      "type": "RiskFactor",
      "graph": "topic-02",
      "tags": [
        "高危因素",
        "生活方式"
      ],
      "aliases": [
        "睡眠障碍",
        "失眠",
        "sleep disturbance",
        "insomnia",
        "睡眠不足"
      ],
      "summary": "睡眠不足与情绪焦虑会降低机体对化疗不良反应的耐受力，与恶心呕吐的发生及主观严重程度相关。",
      "attrs": [
        {
          "k": "类别",
          "v": "生活方式因素"
        },
        {
          "k": "可干预",
          "v": "护理措施可覆盖"
        }
      ],
      "evidence": [
        {
          "type": "共识",
          "author": "《四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识》编写专家组",
          "title": "四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识2024版",
          "journal": "中国循证医学杂志",
          "year": 2024,
          "grade": "专家共识",
          "locate": "DOI 10.7507/1672-2531.202407066",
          "ref": "R07",
          "cite": "《四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识》编写专家组/四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识2024版/中国循证医学杂志/2024"
        },
        {
          "type": "声明",
          "author": "Vidall C, Dielenseger P, Farrell C, et al.",
          "title": "化疗相关恶心呕吐的循证管理：欧洲肿瘤护理论坛立场声明",
          "journal": "欧洲癌症医学科学",
          "year": 2011,
          "grade": "学会立场声明",
          "locate": "PMID 22276054 · DOI 10.3332/ecancer.2011.211",
          "ref": "R13",
          "cite": "Vidall C, Dielenseger P, Farrell C, et al./化疗相关恶心呕吐的循证管理：欧洲肿瘤护理论坛立场声明/欧洲癌症医学科学/2011"
        }
      ]
    },
    {
      "id": "t02-risk-low-alcohol",
      "name": "无饮酒史",
      "type": "RiskFactor",
      "graph": "topic-02",
      "tags": [
        "高危因素",
        "生活方式"
      ],
      "aliases": [
        "无饮酒史",
        "不饮酒",
        "little or no alcohol use",
        "饮酒史少",
        "无酗酒史"
      ],
      "summary": "既往有较多饮酒史的人发生术后恶心呕吐的概率更低，无饮酒史者属于风险更高的一组。",
      "attrs": [
        {
          "k": "类别",
          "v": "生活方式因素"
        },
        {
          "k": "适用",
          "v": "术后恶心呕吐"
        }
      ],
      "evidence": [
        {
          "type": "共识",
          "author": "《四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识》编写专家组",
          "title": "四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识2024版",
          "journal": "中国循证医学杂志",
          "year": 2024,
          "grade": "专家共识",
          "locate": "DOI 10.7507/1672-2531.202407066",
          "ref": "R07",
          "cite": "《四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识》编写专家组/四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识2024版/中国循证医学杂志/2024"
        },
        {
          "type": "共识",
          "author": "Gan TJ, Jin Z, Ayad S, et al.",
          "title": "术后恶心呕吐管理第五版共识指南（摘要）",
          "journal": "麻醉与镇痛",
          "year": 2025,
          "grade": "专家共识（最新版本）",
          "locate": "PMID 41237407 · DOI 10.1213/ANE.0000000000007816",
          "ref": "R05",
          "cite": "Gan TJ, Jin Z, Ayad S, et al./术后恶心呕吐管理第五版共识指南（摘要）/麻醉与镇痛/2025"
        }
      ]
    },
    {
      "id": "t02-risk-no-prior-meal",
      "name": "化疗前进食不足",
      "type": "RiskFactor",
      "graph": "topic-02",
      "tags": [
        "高危因素",
        "饮食"
      ],
      "aliases": [
        "化疗前进食不足",
        "化疗前未进食",
        "空腹化疗",
        "empty stomach before chemotherapy"
      ],
      "summary": "化疗前进食过少或空腹进行化疗，与化疗后恶心呕吐发生率升高相关，因此建议按医嘱在化疗前适量进食。",
      "attrs": [
        {
          "k": "类别",
          "v": "饮食因素"
        },
        {
          "k": "可干预",
          "v": "护理宣教可覆盖"
        }
      ],
      "evidence": [
        {
          "type": "共识",
          "author": "《四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识》编写专家组",
          "title": "四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识2024版",
          "journal": "中国循证医学杂志",
          "year": 2024,
          "grade": "专家共识",
          "locate": "DOI 10.7507/1672-2531.202407066",
          "ref": "R07",
          "cite": "《四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识》编写专家组/四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识2024版/中国循证医学杂志/2024"
        },
        {
          "type": "共识",
          "author": "中国抗癌协会肿瘤临床化疗专业委员会, 中国抗癌协会肿瘤支持治疗专业委员会",
          "title": "中国肿瘤药物治疗相关恶心呕吐防治专家共识（2022年版）",
          "journal": "中华医学杂志",
          "year": 2022,
          "grade": "专家共识",
          "locate": "DOI 10.3760/cma.j.cn112137-20220810-01724",
          "ref": "R06",
          "cite": "中国抗癌协会肿瘤临床化疗专业委员会, 中国抗癌协会肿瘤支持治疗专业委员会/中国肿瘤药物治疗相关恶心呕吐防治专家共识（2022年版）/中华医学杂志/2022"
        }
      ]
    },
    {
      "id": "t02-pharm-5ht3-ra",
      "name": "5-HT3 受体拮抗剂",
      "type": "PharmacologicalManagement",
      "graph": "topic-02",
      "tags": [
        "药物管理",
        "止吐药",
        "一线"
      ],
      "aliases": [
        "5-HT3受体拮抗剂",
        "5-HT3拮抗剂",
        "5-羟色胺3受体拮抗剂",
        "昂丹司琼",
        "托烷司琼",
        "帕洛诺司琼",
        "格拉司琼",
        "雷莫司琼",
        "ondansetron",
        "palonosetron",
        "granisetron",
        "setron"
      ],
      "summary": "作用于 5-羟色胺 3 受体的止吐药，是各类恶心呕吐预防方案的基础用药；与地塞米松联合可明显提高完全缓解率。",
      "attrs": [
        {
          "k": "类别",
          "v": "止吐药类别"
        },
        {
          "k": "代表药物",
          "v": "昂丹司琼 · 托烷司琼 · 帕洛诺司琼"
        },
        {
          "k": "定位",
          "v": "预防方案基础用药"
        }
      ],
      "evidence": [
        {
          "type": "指南",
          "author": "Hesketh PJ, Kris MG, Basch E, et al.",
          "title": "止吐药物：美国临床肿瘤学会指南更新",
          "journal": "临床肿瘤学杂志",
          "year": 2020,
          "grade": "指南（最新版本）",
          "locate": "PMID 32658626 · DOI 10.1200/JCO.20.01296",
          "ref": "R01",
          "cite": "Hesketh PJ, Kris MG, Basch E, et al./止吐药物：美国临床肿瘤学会指南更新/临床肿瘤学杂志/2020"
        },
        {
          "type": "指南",
          "author": "Herrstedt J, Clark-Snow R, Ruhlmann CH, et al.",
          "title": "2023 年国际癌症支持治疗协会与欧洲肿瘤内科学会指南更新：化疗及放疗相关恶心呕吐的预防",
          "journal": "欧洲肿瘤内科学会开放版",
          "year": 2024,
          "grade": "指南（最新版本）",
          "locate": "PMID 38458657 · DOI 10.1016/j.esmoop.2023.102195",
          "ref": "R02",
          "cite": "Herrstedt J, Clark-Snow R, Ruhlmann CH, et al./2023 年国际癌症支持治疗协会与欧洲肿瘤内科学会指南更新：化疗及放疗相关恶心呕吐的预防/欧洲肿瘤内科学会开放版/2024"
        },
        {
          "type": "推荐",
          "author": "Herrstedt J, Celio L, Hesketh PJ, et al.",
          "title": "2023 年国际癌症支持治疗协会与欧洲肿瘤内科学会共识更新：高致吐风险抗肿瘤药物所致恶心呕吐的预防",
          "journal": "癌症支持治疗",
          "year": 2023,
          "grade": "共识推荐条目",
          "locate": "PMID 38127246 · DOI 10.1007/s00520-023-08221-4",
          "ref": "R12",
          "cite": "Herrstedt J, Celio L, Hesketh PJ, et al./2023 年国际癌症支持治疗协会与欧洲肿瘤内科学会共识更新：高致吐风险抗肿瘤药物所致恶心呕吐的预防/癌症支持治疗/2023"
        }
      ]
    },
    {
      "id": "t02-pharm-dexamethasone",
      "name": "地塞米松",
      "type": "PharmacologicalManagement",
      "graph": "topic-02",
      "tags": [
        "药物管理",
        "止吐药",
        "辅助"
      ],
      "aliases": [
        "地塞米松",
        "dexamethasone",
        "糖皮质激素",
        "corticosteroids",
        "泼尼松",
        "强的松",
        "地塞米松（糖皮质激素）"
      ],
      "summary": "糖皮质激素类止吐药，与 5-HT3 受体拮抗剂联用是各指南中预防急性与延迟性恶心呕吐的标准组合；静脉用药宜在化疗前给予。",
      "attrs": [
        {
          "k": "类别",
          "v": "止吐药类别"
        },
        {
          "k": "给药时机",
          "v": "化疗前给药"
        },
        {
          "k": "注意",
          "v": "糖尿病患者需监测血糖"
        }
      ],
      "evidence": [
        {
          "type": "指南",
          "author": "Hesketh PJ, Kris MG, Basch E, et al.",
          "title": "止吐药物：美国临床肿瘤学会指南更新",
          "journal": "临床肿瘤学杂志",
          "year": 2020,
          "grade": "指南（最新版本）",
          "locate": "PMID 32658626 · DOI 10.1200/JCO.20.01296",
          "ref": "R01",
          "cite": "Hesketh PJ, Kris MG, Basch E, et al./止吐药物：美国临床肿瘤学会指南更新/临床肿瘤学杂志/2020"
        },
        {
          "type": "指南",
          "author": "Herrstedt J, Clark-Snow R, Ruhlmann CH, et al.",
          "title": "2023 年国际癌症支持治疗协会与欧洲肿瘤内科学会指南更新：化疗及放疗相关恶心呕吐的预防",
          "journal": "欧洲肿瘤内科学会开放版",
          "year": 2024,
          "grade": "指南（最新版本）",
          "locate": "PMID 38458657 · DOI 10.1016/j.esmoop.2023.102195",
          "ref": "R02",
          "cite": "Herrstedt J, Clark-Snow R, Ruhlmann CH, et al./2023 年国际癌症支持治疗协会与欧洲肿瘤内科学会指南更新：化疗及放疗相关恶心呕吐的预防/欧洲肿瘤内科学会开放版/2024"
        },
        {
          "type": "共识",
          "author": "中国抗癌协会肿瘤临床化疗专业委员会, 中国抗癌协会肿瘤支持治疗专业委员会",
          "title": "中国肿瘤药物治疗相关恶心呕吐防治专家共识（2022年版）",
          "journal": "中华医学杂志",
          "year": 2022,
          "grade": "专家共识",
          "locate": "DOI 10.3760/cma.j.cn112137-20220810-01724",
          "ref": "R06",
          "cite": "中国抗癌协会肿瘤临床化疗专业委员会, 中国抗癌协会肿瘤支持治疗专业委员会/中国肿瘤药物治疗相关恶心呕吐防治专家共识（2022年版）/中华医学杂志/2022"
        }
      ]
    },
    {
      "id": "t02-pharm-nk1-ra",
      "name": "NK-1 受体拮抗剂",
      "type": "PharmacologicalManagement",
      "graph": "topic-02",
      "tags": [
        "药物管理",
        "止吐药",
        "高致吐风险"
      ],
      "aliases": [
        "NK-1受体拮抗剂",
        "NK-1拮抗剂",
        "阿瑞匹坦",
        "磷阿瑞匹坦",
        "奈匹坦",
        "罗匹坦",
        "aprepitant",
        "fosaprepitant",
        "netupitant",
        "rolapitant",
        "NK1受体拮抗剂"
      ],
      "summary": "阻断 P 物质与 NK-1 受体结合的止吐药，是高致吐风险方案中与 5-HT3 受体拮抗剂、地塞米松、奥氮平并列的标准组成。",
      "attrs": [
        {
          "k": "类别",
          "v": "止吐药类别"
        },
        {
          "k": "适用",
          "v": "高度致吐风险方案"
        },
        {
          "k": "注意",
          "v": "与地塞米松有代谢相互作用，需遵医嘱联用"
        }
      ],
      "evidence": [
        {
          "type": "指南",
          "author": "Hesketh PJ, Kris MG, Basch E, et al.",
          "title": "止吐药物：美国临床肿瘤学会指南更新",
          "journal": "临床肿瘤学杂志",
          "year": 2020,
          "grade": "指南（最新版本）",
          "locate": "PMID 32658626 · DOI 10.1200/JCO.20.01296",
          "ref": "R01",
          "cite": "Hesketh PJ, Kris MG, Basch E, et al./止吐药物：美国临床肿瘤学会指南更新/临床肿瘤学杂志/2020"
        },
        {
          "type": "指南",
          "author": "Herrstedt J, Clark-Snow R, Ruhlmann CH, et al.",
          "title": "2023 年国际癌症支持治疗协会与欧洲肿瘤内科学会指南更新：化疗及放疗相关恶心呕吐的预防",
          "journal": "欧洲肿瘤内科学会开放版",
          "year": 2024,
          "grade": "指南（最新版本）",
          "locate": "PMID 38458657 · DOI 10.1016/j.esmoop.2023.102195",
          "ref": "R02",
          "cite": "Herrstedt J, Clark-Snow R, Ruhlmann CH, et al./2023 年国际癌症支持治疗协会与欧洲肿瘤内科学会指南更新：化疗及放疗相关恶心呕吐的预防/欧洲肿瘤内科学会开放版/2024"
        },
        {
          "type": "推荐",
          "author": "Herrstedt J, Celio L, Hesketh PJ, et al.",
          "title": "2023 年国际癌症支持治疗协会与欧洲肿瘤内科学会共识更新：高致吐风险抗肿瘤药物所致恶心呕吐的预防",
          "journal": "癌症支持治疗",
          "year": 2023,
          "grade": "共识推荐条目",
          "locate": "PMID 38127246 · DOI 10.1007/s00520-023-08221-4",
          "ref": "R12",
          "cite": "Herrstedt J, Celio L, Hesketh PJ, et al./2023 年国际癌症支持治疗协会与欧洲肿瘤内科学会共识更新：高致吐风险抗肿瘤药物所致恶心呕吐的预防/癌症支持治疗/2023"
        },
        {
          "type": "共识",
          "author": "中国抗癌协会肿瘤临床化疗专业委员会, 中国抗癌协会肿瘤支持治疗专业委员会",
          "title": "中国肿瘤药物治疗相关恶心呕吐防治专家共识（2022年版）",
          "journal": "中华医学杂志",
          "year": 2022,
          "grade": "专家共识",
          "locate": "DOI 10.3760/cma.j.cn112137-20220810-01724",
          "ref": "R06",
          "cite": "中国抗癌协会肿瘤临床化疗专业委员会, 中国抗癌协会肿瘤支持治疗专业委员会/中国肿瘤药物治疗相关恶心呕吐防治专家共识（2022年版）/中华医学杂志/2022"
        }
      ]
    },
    {
      "id": "t02-pharm-olanzapine",
      "name": "奥氮平",
      "type": "PharmacologicalManagement",
      "graph": "topic-02",
      "tags": [
        "药物管理",
        "止吐药",
        "多模式"
      ],
      "aliases": [
        "奥氮平",
        "olanzapine",
        "奥氮平片"
      ],
      "summary": "在化疗相关恶心呕吐的多模式预防中被纳入标准方案的药物，可与其他止吐药联合改善延迟期恶心控制；起始剂量需由医师评估镇静风险后确定。",
      "attrs": [
        {
          "k": "类别",
          "v": "止吐药类别"
        },
        {
          "k": "说明",
          "v": "非止吐适应证的抗精神病药，被证据推荐用于 CINV"
        },
        {
          "k": "注意",
          "v": "镇静与嗜睡风险需评估"
        }
      ],
      "evidence": [
        {
          "type": "指南",
          "author": "Hesketh PJ, Kris MG, Basch E, et al.",
          "title": "止吐药物：美国临床肿瘤学会指南更新",
          "journal": "临床肿瘤学杂志",
          "year": 2020,
          "grade": "指南（最新版本）",
          "locate": "PMID 32658626 · DOI 10.1200/JCO.20.01296",
          "ref": "R01",
          "cite": "Hesketh PJ, Kris MG, Basch E, et al./止吐药物：美国临床肿瘤学会指南更新/临床肿瘤学杂志/2020"
        },
        {
          "type": "指南",
          "author": "Herrstedt J, Clark-Snow R, Ruhlmann CH, et al.",
          "title": "2023 年国际癌症支持治疗协会与欧洲肿瘤内科学会指南更新：化疗及放疗相关恶心呕吐的预防",
          "journal": "欧洲肿瘤内科学会开放版",
          "year": 2024,
          "grade": "指南（最新版本）",
          "locate": "PMID 38458657 · DOI 10.1016/j.esmoop.2023.102195",
          "ref": "R02",
          "cite": "Herrstedt J, Clark-Snow R, Ruhlmann CH, et al./2023 年国际癌症支持治疗协会与欧洲肿瘤内科学会指南更新：化疗及放疗相关恶心呕吐的预防/欧洲肿瘤内科学会开放版/2024"
        },
        {
          "type": "推荐",
          "author": "Herrstedt J, Celio L, Hesketh PJ, et al.",
          "title": "2023 年国际癌症支持治疗协会与欧洲肿瘤内科学会共识更新：高致吐风险抗肿瘤药物所致恶心呕吐的预防",
          "journal": "癌症支持治疗",
          "year": 2023,
          "grade": "共识推荐条目",
          "locate": "PMID 38127246 · DOI 10.1007/s00520-023-08221-4",
          "ref": "R12",
          "cite": "Herrstedt J, Celio L, Hesketh PJ, et al./2023 年国际癌症支持治疗协会与欧洲肿瘤内科学会共识更新：高致吐风险抗肿瘤药物所致恶心呕吐的预防/癌症支持治疗/2023"
        }
      ]
    },
    {
      "id": "t02-pharm-metoclopramide",
      "name": "甲氧氯普胺",
      "type": "PharmacologicalManagement",
      "graph": "topic-02",
      "tags": [
        "药物管理",
        "止吐药",
        "妊娠可用"
      ],
      "aliases": [
        "甲氧氯普胺",
        "胃复安",
        "metoclopramide",
        "灭吐灵",
        "甲氧氯普胺（胃复安）"
      ],
      "summary": "多巴胺受体拮抗剂兼促胃动力药，常用于妊娠期恶心呕吐和爆发性恶心呕吐的救援治疗；可能引起锥体外系反应，用药需遵医嘱。",
      "attrs": [
        {
          "k": "类别",
          "v": "止吐药类别"
        },
        {
          "k": "双重作用",
          "v": "止吐 + 促胃动力"
        },
        {
          "k": "注意",
          "v": "锥体外系反应风险，剂量遵医嘱"
        }
      ],
      "evidence": [
        {
          "type": "指南",
          "author": "Nelson-Piercy C, Dean C, Shehmar M, et al.",
          "title": "妊娠期恶心呕吐与妊娠剧吐的管理（英国皇家妇产科医学院绿皮书第 69 号）",
          "journal": "国际妇产科杂志",
          "year": 2024,
          "grade": "指南（最新版本）",
          "locate": "PMID 38311315",
          "ref": "R04",
          "cite": "Nelson-Piercy C, Dean C, Shehmar M, et al./妊娠期恶心呕吐与妊娠剧吐的管理（英国皇家妇产科医学院绿皮书第 69 号）/国际妇产科杂志/2024"
        },
        {
          "type": "指南",
          "author": "Herrstedt J, Clark-Snow R, Ruhlmann CH, et al.",
          "title": "2023 年国际癌症支持治疗协会与欧洲肿瘤内科学会指南更新：化疗及放疗相关恶心呕吐的预防",
          "journal": "欧洲肿瘤内科学会开放版",
          "year": 2024,
          "grade": "指南（最新版本）",
          "locate": "PMID 38458657 · DOI 10.1016/j.esmoop.2023.102195",
          "ref": "R02",
          "cite": "Herrstedt J, Clark-Snow R, Ruhlmann CH, et al./2023 年国际癌症支持治疗协会与欧洲肿瘤内科学会指南更新：化疗及放疗相关恶心呕吐的预防/欧洲肿瘤内科学会开放版/2024"
        },
        {
          "type": "共识",
          "author": "中国抗癌协会肿瘤临床化疗专业委员会, 中国抗癌协会肿瘤支持治疗专业委员会",
          "title": "中国肿瘤药物治疗相关恶心呕吐防治专家共识（2022年版）",
          "journal": "中华医学杂志",
          "year": 2022,
          "grade": "专家共识",
          "locate": "DOI 10.3760/cma.j.cn112137-20220810-01724",
          "ref": "R06",
          "cite": "中国抗癌协会肿瘤临床化疗专业委员会, 中国抗癌协会肿瘤支持治疗专业委员会/中国肿瘤药物治疗相关恶心呕吐防治专家共识（2022年版）/中华医学杂志/2022"
        }
      ]
    },
    {
      "id": "t02-pharm-dopamine-antagonist",
      "name": "多巴胺受体拮抗剂",
      "type": "PharmacologicalManagement",
      "graph": "topic-02",
      "tags": [
        "药物管理",
        "止吐药",
        "救援"
      ],
      "aliases": [
        "多巴胺受体拮抗剂",
        "丙氯芬嗪",
        "氟哌利多",
        "异丙嗪",
        "多潘立酮",
        "prochlorperazine",
        "droperidol",
        "domperidone",
        "多巴胺拮抗剂"
      ],
      "summary": "阻断中枢多巴胺受体的止吐药，包括丙氯芬嗪、氟哌利多等，多用于预防方案无效时的爆发性呕吐处理。",
      "attrs": [
        {
          "k": "类别",
          "v": "止吐药类别"
        },
        {
          "k": "主要角色",
          "v": "爆发性呕吐的救援用药"
        },
        {
          "k": "注意",
          "v": "国内制剂与剂量差异较大，须遵医嘱"
        }
      ],
      "evidence": [
        {
          "type": "指南",
          "author": "Hesketh PJ, Kris MG, Basch E, et al.",
          "title": "止吐药物：美国临床肿瘤学会指南更新",
          "journal": "临床肿瘤学杂志",
          "year": 2020,
          "grade": "指南（最新版本）",
          "locate": "PMID 32658626 · DOI 10.1200/JCO.20.01296",
          "ref": "R01",
          "cite": "Hesketh PJ, Kris MG, Basch E, et al./止吐药物：美国临床肿瘤学会指南更新/临床肿瘤学杂志/2020"
        },
        {
          "type": "指南",
          "author": "Herrstedt J, Clark-Snow R, Ruhlmann CH, et al.",
          "title": "2023 年国际癌症支持治疗协会与欧洲肿瘤内科学会指南更新：化疗及放疗相关恶心呕吐的预防",
          "journal": "欧洲肿瘤内科学会开放版",
          "year": 2024,
          "grade": "指南（最新版本）",
          "locate": "PMID 38458657 · DOI 10.1016/j.esmoop.2023.102195",
          "ref": "R02",
          "cite": "Herrstedt J, Clark-Snow R, Ruhlmann CH, et al./2023 年国际癌症支持治疗协会与欧洲肿瘤内科学会指南更新：化疗及放疗相关恶心呕吐的预防/欧洲肿瘤内科学会开放版/2024"
        },
        {
          "type": "共识",
          "author": "中国抗癌协会肿瘤临床化疗专业委员会, 中国抗癌协会肿瘤支持治疗专业委员会",
          "title": "中国肿瘤药物治疗相关恶心呕吐防治专家共识（2022年版）",
          "journal": "中华医学杂志",
          "year": 2022,
          "grade": "专家共识",
          "locate": "DOI 10.3760/cma.j.cn112137-20220810-01724",
          "ref": "R06",
          "cite": "中国抗癌协会肿瘤临床化疗专业委员会, 中国抗癌协会肿瘤支持治疗专业委员会/中国肿瘤药物治疗相关恶心呕吐防治专家共识（2022年版）/中华医学杂志/2022"
        }
      ]
    },
    {
      "id": "t02-pharm-antihistamine",
      "name": "抗组胺药",
      "type": "PharmacologicalManagement",
      "graph": "topic-02",
      "tags": [
        "药物管理",
        "止吐药",
        "妊娠可用"
      ],
      "aliases": [
        "抗组胺药",
        "苯海拉明",
        "多西拉敏",
        "异丙嗪",
        "cyclizine",
        "diphenhydramine",
        "doxylamine",
        "H1受体拮抗剂"
      ],
      "summary": "H1 受体拮抗剂。苯海拉明与维生素 B6 的复方是妊娠早期恶心呕吐的经典一线用药；多西拉敏与维生素 B6 联用也是国际指南推荐的妊娠期方案之一。",
      "attrs": [
        {
          "k": "类别",
          "v": "止吐药类别"
        },
        {
          "k": "妊娠期地位",
          "v": "一线可选"
        },
        {
          "k": "注意",
          "v": "部分品种有嗜睡副作用"
        }
      ],
      "evidence": [
        {
          "type": "指南",
          "author": "Nelson-Piercy C, Dean C, Shehmar M, et al.",
          "title": "妊娠期恶心呕吐与妊娠剧吐的管理（英国皇家妇产科医学院绿皮书第 69 号）",
          "journal": "国际妇产科杂志",
          "year": 2024,
          "grade": "指南（最新版本）",
          "locate": "PMID 38311315",
          "ref": "R04",
          "cite": "Nelson-Piercy C, Dean C, Shehmar M, et al./妊娠期恶心呕吐与妊娠剧吐的管理（英国皇家妇产科医学院绿皮书第 69 号）/国际妇产科杂志/2024"
        },
        {
          "type": "建议",
          "author": "世界卫生组织",
          "title": "世界卫生组织关于产前保健促进积极妊娠体验的建议",
          "journal": "世界卫生组织",
          "year": 2016,
          "grade": "指南推荐条目",
          "locate": "ISBN 9789241549912 · 推荐条目 D.1",
          "ref": "R11",
          "cite": "世界卫生组织/世界卫生组织关于产前保健促进积极妊娠体验的建议/世界卫生组织/2016"
        },
        {
          "type": "系统评价",
          "author": "Matthews A, Haas DM, O'Mathúna DP, Dowswell T, Doyle M",
          "title": "妊娠早期恶心呕吐的干预措施",
          "journal": "考克兰系统评价数据库",
          "year": 2015,
          "grade": "系统评价",
          "locate": "DOI 10.1002/14651858.CD007575.pub4",
          "ref": "R18",
          "cite": "Matthews A, Haas DM, O'Mathúna DP, Dowswell T, Doyle M/妊娠早期恶心呕吐的干预措施/考克兰系统评价数据库/2015"
        }
      ]
    },
    {
      "id": "t02-pharm-vitamin-b6",
      "name": "维生素 B6",
      "type": "PharmacologicalManagement",
      "graph": "topic-02",
      "tags": [
        "药物管理",
        "止吐药",
        "妊娠一线"
      ],
      "aliases": [
        "维生素B6",
        "吡多醇",
        "pyridoxine",
        "维生素B 6",
        "pyridoxine",
        "维生素 B6"
      ],
      "summary": "维生素 B6 单独使用或与抗组胺药联用，是妊娠期恶心呕吐的首选药物方案；世界卫生组织与英国皇家妇产科医学院的指南均将其列入推荐用药。",
      "attrs": [
        {
          "k": "类别",
          "v": "止吐药类别"
        },
        {
          "k": "妊娠期地位",
          "v": "首选"
        },
        {
          "k": "注意",
          "v": "需遵医嘱确定剂量与疗程"
        }
      ],
      "evidence": [
        {
          "type": "建议",
          "author": "世界卫生组织",
          "title": "世界卫生组织关于产前保健促进积极妊娠体验的建议",
          "journal": "世界卫生组织",
          "year": 2016,
          "grade": "指南推荐条目",
          "locate": "ISBN 9789241549912 · 推荐条目 D.1",
          "ref": "R11",
          "cite": "世界卫生组织/世界卫生组织关于产前保健促进积极妊娠体验的建议/世界卫生组织/2016"
        },
        {
          "type": "指南",
          "author": "Nelson-Piercy C, Dean C, Shehmar M, et al.",
          "title": "妊娠期恶心呕吐与妊娠剧吐的管理（英国皇家妇产科医学院绿皮书第 69 号）",
          "journal": "国际妇产科杂志",
          "year": 2024,
          "grade": "指南（最新版本）",
          "locate": "PMID 38311315",
          "ref": "R04",
          "cite": "Nelson-Piercy C, Dean C, Shehmar M, et al./妊娠期恶心呕吐与妊娠剧吐的管理（英国皇家妇产科医学院绿皮书第 69 号）/国际妇产科杂志/2024"
        },
        {
          "type": "系统评价",
          "author": "Matthews A, Haas DM, O'Mathúna DP, Dowswell T, Doyle M",
          "title": "妊娠早期恶心呕吐的干预措施",
          "journal": "考克兰系统评价数据库",
          "year": 2015,
          "grade": "系统评价",
          "locate": "DOI 10.1002/14651858.CD007575.pub4",
          "ref": "R18",
          "cite": "Matthews A, Haas DM, O'Mathúna DP, Dowswell T, Doyle M/妊娠早期恶心呕吐的干预措施/考克兰系统评价数据库/2015"
        }
      ]
    },
    {
      "id": "t02-pharm-enteral-nutrition",
      "name": "肠内营养支持",
      "type": "PharmacologicalManagement",
      "graph": "topic-02",
      "tags": [
        "药物管理",
        "营养支持",
        "护理"
      ],
      "aliases": [
        "肠内营养",
        "肠内营养支持",
        "enteral nutrition",
        "营养管饲",
        "鼻肠管",
        "肠内营养（护理）"
      ],
      "summary": "经口摄入不足、营养风险高时，按中华护理学会团体标准实施肠内营养支持（基本要求、操作要点、并发症护理与健康教育），改善因恶心呕吐导致的营养不良。",
      "attrs": [
        {
          "k": "类别",
          "v": "营养支持"
        },
        {
          "k": "操作依据",
          "v": "T/CNAS 19—2020《成人肠内营养支持的护理》"
        },
        {
          "k": "注意",
          "v": "耐受性评分与并发症护理是关键"
        }
      ],
      "evidence": [
        {
          "type": "规范",
          "author": "中华护理学会",
          "title": "成人肠内营养支持的护理",
          "journal": "中华护理学会",
          "year": 2021,
          "grade": "团体标准（护理规范）",
          "locate": "T/CNAS 19—2020（编号年 2020 · 发布 2021-02-01 · 实施 2021-05-01）· https://www.ttbz.org.cn/standardDetail.html?id=s6s3qhpso8xyf3jot0eth1xlyxizyls",
          "ref": "R14",
          "cite": "中华护理学会/成人肠内营养支持的护理/中华护理学会/2021"
        },
        {
          "type": "书籍",
          "author": "李小寒, 尚少梅",
          "title": "基础护理学（第7版）",
          "journal": "人民卫生出版社",
          "year": 2022,
          "grade": "本科规划教材",
          "locate": "ISBN 9787117333511",
          "ref": "R15",
          "cite": "李小寒, 尚少梅/基础护理学（第7版）/人民卫生出版社/2022"
        },
        {
          "type": "最佳证据",
          "author": "Zheng P, Ou Y, Jiang J, Liu H, Mo X, Li J",
          "title": "癌症患者化疗相关恶心呕吐评估与管理的最佳证据总结",
          "journal": "长江医学",
          "year": 2023,
          "grade": "最佳证据总结",
          "locate": "DOI 10.4236/ym.2023.71004",
          "ref": "R16",
          "cite": "Zheng P, Ou Y, Jiang J, Liu H, Mo X, Li J/癌症患者化疗相关恶心呕吐评估与管理的最佳证据总结/长江医学/2023"
        }
      ]
    },
    {
      "id": "t02-pharm-thiamine",
      "name": "硫胺素（维生素 B1）",
      "type": "PharmacologicalManagement",
      "graph": "topic-02",
      "tags": [
        "药物管理",
        "营养支持",
        "妊娠剧吐"
      ],
      "aliases": [
        "硫胺素",
        "维生素B1",
        "thiamine",
        "维生素 B1",
        "硫胺素（维生素B1）"
      ],
      "summary": "妊娠剧吐患者因长期进食不足可能出现硫胺素缺乏，需及时补充以预防韦尼克脑病；与葡萄糖同时补液时尤其要注意给药顺序。",
      "attrs": [
        {
          "k": "类别",
          "v": "营养支持"
        },
        {
          "k": "适用人群",
          "v": "妊娠剧吐等长期不能进食者"
        },
        {
          "k": "注意",
          "v": "先补硫胺素再用葡萄糖，须遵医嘱"
        }
      ],
      "evidence": [
        {
          "type": "指南",
          "author": "Nelson-Piercy C, Dean C, Shehmar M, et al.",
          "title": "妊娠期恶心呕吐与妊娠剧吐的管理（英国皇家妇产科医学院绿皮书第 69 号）",
          "journal": "国际妇产科杂志",
          "year": 2024,
          "grade": "指南（最新版本）",
          "locate": "PMID 38311315",
          "ref": "R04",
          "cite": "Nelson-Piercy C, Dean C, Shehmar M, et al./妊娠期恶心呕吐与妊娠剧吐的管理（英国皇家妇产科医学院绿皮书第 69 号）/国际妇产科杂志/2024"
        }
      ]
    },
    {
      "id": "t02-nonpharm-lifestyle",
      "name": "起居护理",
      "type": "NonPharmacologicalManagement",
      "graph": "topic-02",
      "tags": [
        "非药物管理",
        "护理措施"
      ],
      "aliases": [
        "起居护理",
        "起居照护",
        "生活方式护理",
        "lifestyle care",
        "环境与饮食护理",
        "体位护理",
        "日常起居护理",
        "起居护理（生活方式调整）"
      ],
      "summary": "通过调整生活起居与饮食环境减轻恶心：保持空气流通、无强烈气味、少量多餐、清淡饮食，进食后取半卧位休息，避免过冷过热与油腻食物。",
      "attrs": [
        {
          "k": "类别",
          "v": "非药物护理"
        },
        {
          "k": "要点",
          "v": "少量多餐 · 半卧位 · 通风无异味 · 避免油腻"
        },
        {
          "k": "角色",
          "v": "所有方案的共同基础"
        }
      ],
      "evidence": [
        {
          "type": "共识",
          "author": "《四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识》编写专家组",
          "title": "四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识2024版",
          "journal": "中国循证医学杂志",
          "year": 2024,
          "grade": "专家共识",
          "locate": "DOI 10.7507/1672-2531.202407066",
          "ref": "R07",
          "cite": "《四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识》编写专家组/四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识2024版/中国循证医学杂志/2024"
        },
        {
          "type": "书籍",
          "author": "李小寒, 尚少梅",
          "title": "基础护理学（第7版）",
          "journal": "人民卫生出版社",
          "year": 2022,
          "grade": "本科规划教材",
          "locate": "ISBN 9787117333511",
          "ref": "R15",
          "cite": "李小寒, 尚少梅/基础护理学（第7版）/人民卫生出版社/2022"
        },
        {
          "type": "共识",
          "author": "Gan TJ, Jin Z, Ayad S, et al.",
          "title": "术后恶心呕吐管理第五版共识指南（摘要）",
          "journal": "麻醉与镇痛",
          "year": 2025,
          "grade": "专家共识（最新版本）",
          "locate": "PMID 41237407 · DOI 10.1213/ANE.0000000000007816",
          "ref": "R05",
          "cite": "Gan TJ, Jin Z, Ayad S, et al./术后恶心呕吐管理第五版共识指南（摘要）/麻醉与镇痛/2025"
        }
      ]
    },
    {
      "id": "t02-nonpharm-acupoint",
      "name": "穴位刺激",
      "type": "NonPharmacologicalManagement",
      "graph": "topic-02",
      "tags": [
        "非药物管理",
        "中医护理",
        "辅助"
      ],
      "aliases": [
        "穴位刺激",
        "穴位按摩",
        "穴位贴敷",
        "耳穴压豆",
        "耳穴贴压",
        "acupoint stimulation",
        "acupressure",
        "P6",
        "内关",
        "耳穴",
        "穴位按摩法",
        "腕带穴位按压",
        "足三里"
      ],
      "summary": "在特定穴位（最常用内关/PC6、耳穴）施加按压、贴敷或电刺激以减轻恶心呕吐的护理技术，可作为药物预防的辅助手段。",
      "attrs": [
        {
          "k": "类别",
          "v": "中医护理技术"
        },
        {
          "k": "常用穴位",
          "v": "内关 PC6 · 足三里 ST36 · 耳穴"
        },
        {
          "k": "证据提示",
          "v": "Meta 分析提示有一定改善，纳入研究质量有限"
        }
      ],
      "evidence": [
        {
          "type": "Meta分析",
          "author": "Xiao C, Qin M, Xia H, Xing Q, Wang D, Qian W",
          "title": "内关穴（PC6）按压对恶性肿瘤患者化疗所致急性与延迟性恶心呕吐的影响：荟萃分析",
          "journal": "癌症支持治疗",
          "year": 2023,
          "grade": "Meta分析",
          "locate": "PMID 37548707 · DOI 10.1007/s00520-023-07976-0",
          "ref": "R19",
          "cite": "Xiao C, Qin M, Xia H, Xing Q, Wang D, Qian W/内关穴（PC6）按压对恶性肿瘤患者化疗所致急性与延迟性恶心呕吐的影响：荟萃分析/癌症支持治疗/2023"
        },
        {
          "type": "Meta分析",
          "author": "张英英, 乔欣, 赵丽丽, 汤媛媛, 刘芳",
          "title": "非药物干预对癌症化疗致恶心呕吐影响的网状Meta分析",
          "journal": "循证护理",
          "year": 2024,
          "grade": "Meta分析（网状）",
          "locate": "DOI 10.12102/j.issn.2095-8668.2024.10.001",
          "ref": "R21",
          "cite": "张英英, 乔欣, 赵丽丽, 汤媛媛, 刘芳/非药物干预对癌症化疗致恶心呕吐影响的网状Meta分析/循证护理/2024"
        },
        {
          "type": "建议",
          "author": "世界卫生组织",
          "title": "世界卫生组织关于产前保健促进积极妊娠体验的建议",
          "journal": "世界卫生组织",
          "year": 2016,
          "grade": "指南推荐条目",
          "locate": "ISBN 9789241549912 · 推荐条目 D.1",
          "ref": "R11",
          "cite": "世界卫生组织/世界卫生组织关于产前保健促进积极妊娠体验的建议/世界卫生组织/2016"
        },
        {
          "type": "推荐实践",
          "author": "Han J, Xu Q, Wang W, Zhou Y",
          "title": "护士主导的非药物干预在腹腔镜手术成人患者术后恶心呕吐预防与管理中的证据总结",
          "journal": "BMC 护理",
          "year": 2026,
          "grade": "证据总结（推荐实践）",
          "locate": "DOI 10.1186/s12912-026-05029-5",
          "ref": "R17",
          "cite": "Han J, Xu Q, Wang W, Zhou Y/护士主导的非药物干预在腹腔镜手术成人患者术后恶心呕吐预防与管理中的证据总结/BMC 护理/2026"
        }
      ]
    },
    {
      "id": "t02-nonpharm-fluid",
      "name": "液体疗法",
      "type": "NonPharmacologicalManagement",
      "graph": "topic-02",
      "tags": [
        "非药物管理",
        "补液",
        "护理措施"
      ],
      "aliases": [
        "液体疗法",
        "补液",
        "液体治疗",
        "补液治疗",
        "fluid therapy",
        "oral rehydration",
        "静脉补液",
        "水电解质平衡",
        "液体疗法（补液）"
      ],
      "summary": "呕吐导致摄入不足时按医嘱补充水分与电解质，维持水电解质平衡。轻症以口服补液为先；重症（如妊娠剧吐伴脱水）需静脉补液并补充硫胺素。",
      "attrs": [
        {
          "k": "类别",
          "v": "支持治疗"
        },
        {
          "k": "轻度",
          "v": "口服补液优先"
        },
        {
          "k": "重度",
          "v": "静脉补液 + 硫胺素，遵医嘱"
        }
      ],
      "evidence": [
        {
          "type": "指南",
          "author": "Nelson-Piercy C, Dean C, Shehmar M, et al.",
          "title": "妊娠期恶心呕吐与妊娠剧吐的管理（英国皇家妇产科医学院绿皮书第 69 号）",
          "journal": "国际妇产科杂志",
          "year": 2024,
          "grade": "指南（最新版本）",
          "locate": "PMID 38311315",
          "ref": "R04",
          "cite": "Nelson-Piercy C, Dean C, Shehmar M, et al./妊娠期恶心呕吐与妊娠剧吐的管理（英国皇家妇产科医学院绿皮书第 69 号）/国际妇产科杂志/2024"
        },
        {
          "type": "书籍",
          "author": "李小寒, 尚少梅",
          "title": "基础护理学（第7版）",
          "journal": "人民卫生出版社",
          "year": 2022,
          "grade": "本科规划教材",
          "locate": "ISBN 9787117333511",
          "ref": "R15",
          "cite": "李小寒, 尚少梅/基础护理学（第7版）/人民卫生出版社/2022"
        },
        {
          "type": "共识",
          "author": "《四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识》编写专家组",
          "title": "四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识2024版",
          "journal": "中国循证医学杂志",
          "year": 2024,
          "grade": "专家共识",
          "locate": "DOI 10.7507/1672-2531.202407066",
          "ref": "R07",
          "cite": "《四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识》编写专家组/四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识2024版/中国循证医学杂志/2024"
        }
      ]
    },
    {
      "id": "t02-nonpharm-aromatherapy",
      "name": "芳香疗法（精油疗法）",
      "type": "NonPharmacologicalManagement",
      "graph": "topic-02",
      "tags": [
        "非药物管理",
        "辅助"
      ],
      "aliases": [
        "芳香疗法",
        "精油疗法",
        "精油吸入",
        "吸入性芳香疗法",
        "aromatherapy",
        "essential oil",
        "peppermint oil",
        "薄荷精油",
        "芳香吸入",
        "芳香疗法（精油疗法）"
      ],
      "summary": "经鼻吸入薄荷、柠檬等精油以缓解恶心的非药物方法，可作为药物预防的辅助措施，不替代规范止吐方案。",
      "attrs": [
        {
          "k": "类别",
          "v": "辅助措施"
        },
        {
          "k": "常用精油",
          "v": "薄荷 · 柠檬 · 生姜 · 薰衣草"
        },
        {
          "k": "证据提示",
          "v": "Meta 分析纳入研究多为小样本、确定性偏低"
        }
      ],
      "evidence": [
        {
          "type": "Meta分析",
          "author": "Gergő D, Garmaa G, Tóth-Mészáros A, et al.",
          "title": "吸入薄荷精油作为恶心呕吐治疗的辅助疗法：一项有前景的补充治疗",
          "journal": "临床医学杂志",
          "year": 2025,
          "grade": "Meta分析",
          "locate": "PMID 40725767 · DOI 10.3390/jcm14145069",
          "ref": "R20",
          "cite": "Gergő D, Garmaa G, Tóth-Mészáros A, et al./吸入薄荷精油作为恶心呕吐治疗的辅助疗法：一项有前景的补充治疗/临床医学杂志/2025"
        },
        {
          "type": "Meta分析",
          "author": "张英英, 乔欣, 赵丽丽, 汤媛媛, 刘芳",
          "title": "非药物干预对癌症化疗致恶心呕吐影响的网状Meta分析",
          "journal": "循证护理",
          "year": 2024,
          "grade": "Meta分析（网状）",
          "locate": "DOI 10.12102/j.issn.2095-8668.2024.10.001",
          "ref": "R21",
          "cite": "张英英, 乔欣, 赵丽丽, 汤媛媛, 刘芳/非药物干预对癌症化疗致恶心呕吐影响的网状Meta分析/循证护理/2024"
        },
        {
          "type": "推荐实践",
          "author": "Han J, Xu Q, Wang W, Zhou Y",
          "title": "护士主导的非药物干预在腹腔镜手术成人患者术后恶心呕吐预防与管理中的证据总结",
          "journal": "BMC 护理",
          "year": 2026,
          "grade": "证据总结（推荐实践）",
          "locate": "DOI 10.1186/s12912-026-05029-5",
          "ref": "R17",
          "cite": "Han J, Xu Q, Wang W, Zhou Y/护士主导的非药物干预在腹腔镜手术成人患者术后恶心呕吐预防与管理中的证据总结/BMC 护理/2026"
        }
      ]
    },
    {
      "id": "t02-nonpharm-ginger",
      "name": "生姜疗法",
      "type": "NonPharmacologicalManagement",
      "graph": "topic-02",
      "tags": [
        "非药物管理",
        "辅助",
        "妊娠可用"
      ],
      "aliases": [
        "生姜疗法",
        "生姜",
        "姜",
        "ginger",
        "生姜粉",
        "ginger therapy",
        "生姜疗法（辅助）"
      ],
      "summary": "口服生姜或生姜粉缓解恶心，世界卫生组织产前保健建议 D.1 明确推荐生姜用于孕早期恶心缓解；系统评价显示对恶心的改善证据为低至中等确定性。",
      "attrs": [
        {
          "k": "类别",
          "v": "辅助措施"
        },
        {
          "k": "WHO 推荐",
          "v": "产前保健建议 D.1 明确点名生姜"
        },
        {
          "k": "注意",
          "v": "服用方式与剂量遵医嘱"
        }
      ],
      "evidence": [
        {
          "type": "建议",
          "author": "世界卫生组织",
          "title": "世界卫生组织关于产前保健促进积极妊娠体验的建议",
          "journal": "世界卫生组织",
          "year": 2016,
          "grade": "指南推荐条目",
          "locate": "ISBN 9789241549912 · 推荐条目 D.1",
          "ref": "R11",
          "cite": "世界卫生组织/世界卫生组织关于产前保健促进积极妊娠体验的建议/世界卫生组织/2016"
        },
        {
          "type": "系统评价",
          "author": "Matthews A, Haas DM, O'Mathúna DP, Dowswell T, Doyle M",
          "title": "妊娠早期恶心呕吐的干预措施",
          "journal": "考克兰系统评价数据库",
          "year": 2015,
          "grade": "系统评价",
          "locate": "DOI 10.1002/14651858.CD007575.pub4",
          "ref": "R18",
          "cite": "Matthews A, Haas DM, O'Mathúna DP, Dowswell T, Doyle M/妊娠早期恶心呕吐的干预措施/考克兰系统评价数据库/2015"
        },
        {
          "type": "Meta分析",
          "author": "张英英, 乔欣, 赵丽丽, 汤媛媛, 刘芳",
          "title": "非药物干预对癌症化疗致恶心呕吐影响的网状Meta分析",
          "journal": "循证护理",
          "year": 2024,
          "grade": "Meta分析（网状）",
          "locate": "DOI 10.12102/j.issn.2095-8668.2024.10.001",
          "ref": "R21",
          "cite": "张英英, 乔欣, 赵丽丽, 汤媛媛, 刘芳/非药物干预对癌症化疗致恶心呕吐影响的网状Meta分析/循证护理/2024"
        }
      ]
    },
    {
      "id": "t02-nonpharm-health-education",
      "name": "健康教育",
      "type": "NonPharmacologicalManagement",
      "graph": "topic-02",
      "tags": [
        "非药物管理",
        "护理措施",
        "患者教育"
      ],
      "aliases": [
        "健康教育",
        "健康宣教",
        "患者教育",
        "病人教育",
        "health education",
        "patient education",
        "用药宣教",
        "自我照护指导",
        "健康科普",
        "科普",
        "恶心呕吐自我照护",
        "symptom self-care",
        "居家护理",
        "自我照护指南"
      ],
      "summary": "面向患者和家属的宣教与自我照护指导：讲清恶心呕吐的原因、预防方案、用药要点、饮食起居调整、什么时候必须求助，以及如何记录症状日记（何时、多久、吃了什么药、程度几分）。这是患者扫码后最直接看到的内容。",
      "attrs": [
        {
          "k": "类别",
          "v": "护理措施"
        },
        {
          "k": "内容",
          "v": "原因 · 方案 · 用药 · 饮食起居 · 求助时机 · 记录"
        },
        {
          "k": "工具",
          "v": "症状日记模板 + 口腔护理清单 + 补液要点"
        },
        {
          "k": "落点",
          "v": "出院后仍能自我管理"
        }
      ],
      "evidence": [
        {
          "type": "共识",
          "author": "《四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识》编写专家组",
          "title": "四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识2024版",
          "journal": "中国循证医学杂志",
          "year": 2024,
          "grade": "专家共识",
          "locate": "DOI 10.7507/1672-2531.202407066",
          "ref": "R07",
          "cite": "《四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识》编写专家组/四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识2024版/中国循证医学杂志/2024"
        },
        {
          "type": "声明",
          "author": "Vidall C, Dielenseger P, Farrell C, et al.",
          "title": "化疗相关恶心呕吐的循证管理：欧洲肿瘤护理论坛立场声明",
          "journal": "欧洲癌症医学科学",
          "year": 2011,
          "grade": "学会立场声明",
          "locate": "PMID 22276054 · DOI 10.3332/ecancer.2011.211",
          "ref": "R13",
          "cite": "Vidall C, Dielenseger P, Farrell C, et al./化疗相关恶心呕吐的循证管理：欧洲肿瘤护理论坛立场声明/欧洲癌症医学科学/2011"
        },
        {
          "type": "推荐实践",
          "author": "Han J, Xu Q, Wang W, Zhou Y",
          "title": "护士主导的非药物干预在腹腔镜手术成人患者术后恶心呕吐预防与管理中的证据总结",
          "journal": "BMC 护理",
          "year": 2026,
          "grade": "证据总结（推荐实践）",
          "locate": "DOI 10.1186/s12912-026-05029-5",
          "ref": "R17",
          "cite": "Han J, Xu Q, Wang W, Zhou Y/护士主导的非药物干预在腹腔镜手术成人患者术后恶心呕吐预防与管理中的证据总结/BMC 护理/2026"
        }
      ]
    },
    {
      "id": "t02-nonpharm-oral-care",
      "name": "口腔护理",
      "type": "NonPharmacologicalManagement",
      "graph": "topic-02",
      "tags": [
        "非药物管理",
        "基础护理"
      ],
      "aliases": [
        "口腔护理",
        "mouth care",
        "oral care",
        "口腔清洁",
        "呕吐后口腔护理",
        "口腔护理（基础护理）"
      ],
      "summary": "呕吐后及时清洁口腔、去除残留气味，可减轻恶心与口渴不适、预防口腔黏膜损伤，同时提高随后进食的接受度。",
      "attrs": [
        {
          "k": "类别",
          "v": "基础护理"
        },
        {
          "k": "时机",
          "v": "每次呕吐后"
        },
        {
          "k": "目的",
          "v": "减轻恶心 · 预防黏膜损伤"
        }
      ],
      "evidence": [
        {
          "type": "书籍",
          "author": "李小寒, 尚少梅",
          "title": "基础护理学（第7版）",
          "journal": "人民卫生出版社",
          "year": 2022,
          "grade": "本科规划教材",
          "locate": "ISBN 9787117333511",
          "ref": "R15",
          "cite": "李小寒, 尚少梅/基础护理学（第7版）/人民卫生出版社/2022"
        },
        {
          "type": "共识",
          "author": "《四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识》编写专家组",
          "title": "四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识2024版",
          "journal": "中国循证医学杂志",
          "year": 2024,
          "grade": "专家共识",
          "locate": "DOI 10.7507/1672-2531.202407066",
          "ref": "R07",
          "cite": "《四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识》编写专家组/四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识2024版/中国循证医学杂志/2024"
        },
        {
          "type": "声明",
          "author": "Vidall C, Dielenseger P, Farrell C, et al.",
          "title": "化疗相关恶心呕吐的循证管理：欧洲肿瘤护理论坛立场声明",
          "journal": "欧洲癌症医学科学",
          "year": 2011,
          "grade": "学会立场声明",
          "locate": "PMID 22276054 · DOI 10.3332/ecancer.2011.211",
          "ref": "R13",
          "cite": "Vidall C, Dielenseger P, Farrell C, et al./化疗相关恶心呕吐的循证管理：欧洲肿瘤护理论坛立场声明/欧洲癌症医学科学/2011"
        }
      ]
    },
    {
      "id": "t02-nonpharm-behavioral",
      "name": "行为干预",
      "type": "NonPharmacologicalManagement",
      "graph": "topic-02",
      "tags": [
        "非药物管理",
        "心理",
        "预期性"
      ],
      "aliases": [
        "行为干预",
        "放松训练",
        "音乐疗法",
        "behavioral intervention",
        "relaxation",
        "music therapy",
        "意象疗法",
        "渐进性肌肉放松",
        "行为干预（心理）"
      ],
      "summary": "针对预期性恶心呕吐的放松训练、音乐疗法与意象引导等行为干预，配合心理支持，可减轻化疗前后的焦虑与预期性症状。",
      "attrs": [
        {
          "k": "类别",
          "v": "心理护理"
        },
        {
          "k": "适用场景",
          "v": "预期性恶心呕吐"
        },
        {
          "k": "配合",
          "v": "健康教育 + 穴位刺激"
        }
      ],
      "evidence": [
        {
          "type": "推荐实践",
          "author": "Han J, Xu Q, Wang W, Zhou Y",
          "title": "护士主导的非药物干预在腹腔镜手术成人患者术后恶心呕吐预防与管理中的证据总结",
          "journal": "BMC 护理",
          "year": 2026,
          "grade": "证据总结（推荐实践）",
          "locate": "DOI 10.1186/s12912-026-05029-5",
          "ref": "R17",
          "cite": "Han J, Xu Q, Wang W, Zhou Y/护士主导的非药物干预在腹腔镜手术成人患者术后恶心呕吐预防与管理中的证据总结/BMC 护理/2026"
        },
        {
          "type": "共识",
          "author": "《四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识》编写专家组",
          "title": "四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识2024版",
          "journal": "中国循证医学杂志",
          "year": 2024,
          "grade": "专家共识",
          "locate": "DOI 10.7507/1672-2531.202407066",
          "ref": "R07",
          "cite": "《四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识》编写专家组/四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识2024版/中国循证医学杂志/2024"
        },
        {
          "type": "共识",
          "author": "中国抗癌协会肿瘤临床化疗专业委员会, 中国抗癌协会肿瘤支持治疗专业委员会",
          "title": "中国肿瘤药物治疗相关恶心呕吐防治专家共识（2022年版）",
          "journal": "中华医学杂志",
          "year": 2022,
          "grade": "专家共识",
          "locate": "DOI 10.3760/cma.j.cn112137-20220810-01724",
          "ref": "R06",
          "cite": "中国抗癌协会肿瘤临床化疗专业委员会, 中国抗癌协会肿瘤支持治疗专业委员会/中国肿瘤药物治疗相关恶心呕吐防治专家共识（2022年版）/中华医学杂志/2022"
        }
      ]
    },
    {
      "id": "t02-strategy-cinv",
      "name": "化疗相关恶心呕吐管理策略",
      "type": "ManagementStrategy",
      "graph": "topic-02",
      "tags": [
        "管理策略",
        "化疗",
        "总策略"
      ],
      "aliases": [
        "化疗相关恶心呕吐管理策略",
        "CINV管理策略",
        "化疗止吐方案",
        "CINV management",
        "化疗期恶心呕吐管理策略"
      ],
      "summary": "按致吐风险分级（高度 >90%、中度 30%–90%、轻度 10%–30%、极低 <10%）选择多模式预防方案：以 5-HT3 受体拮抗剂为基础联合地塞米松，高风险再加 NK-1 受体拮抗剂与奥氮平；同时配合穴位刺激、芳香疗法、健康教育与起居护理，并按急性/延迟/预期性/爆发性分别处理。",
      "attrs": [
        {
          "k": "四步",
          "v": "风险分层 → 选药 → 非药物辅助 → 动态复评"
        },
        {
          "k": "致吐风险分级",
          "v": "高度>90% · 中度30–90% · 轻度10–30% · 极低<10%"
        },
        {
          "k": "核心原则",
          "v": "预防优先 · 多模式联合 · 分层分级 · 个体化评估"
        }
      ],
      "evidence": [
        {
          "type": "指南",
          "author": "Hesketh PJ, Kris MG, Basch E, et al.",
          "title": "止吐药物：美国临床肿瘤学会指南更新",
          "journal": "临床肿瘤学杂志",
          "year": 2020,
          "grade": "指南（最新版本）",
          "locate": "PMID 32658626 · DOI 10.1200/JCO.20.01296",
          "ref": "R01",
          "cite": "Hesketh PJ, Kris MG, Basch E, et al./止吐药物：美国临床肿瘤学会指南更新/临床肿瘤学杂志/2020"
        },
        {
          "type": "指南",
          "author": "Herrstedt J, Clark-Snow R, Ruhlmann CH, et al.",
          "title": "2023 年国际癌症支持治疗协会与欧洲肿瘤内科学会指南更新：化疗及放疗相关恶心呕吐的预防",
          "journal": "欧洲肿瘤内科学会开放版",
          "year": 2024,
          "grade": "指南（最新版本）",
          "locate": "PMID 38458657 · DOI 10.1016/j.esmoop.2023.102195",
          "ref": "R02",
          "cite": "Herrstedt J, Clark-Snow R, Ruhlmann CH, et al./2023 年国际癌症支持治疗协会与欧洲肿瘤内科学会指南更新：化疗及放疗相关恶心呕吐的预防/欧洲肿瘤内科学会开放版/2024"
        },
        {
          "type": "推荐",
          "author": "Herrstedt J, Celio L, Hesketh PJ, et al.",
          "title": "2023 年国际癌症支持治疗协会与欧洲肿瘤内科学会共识更新：高致吐风险抗肿瘤药物所致恶心呕吐的预防",
          "journal": "癌症支持治疗",
          "year": 2023,
          "grade": "共识推荐条目",
          "locate": "PMID 38127246 · DOI 10.1007/s00520-023-08221-4",
          "ref": "R12",
          "cite": "Herrstedt J, Celio L, Hesketh PJ, et al./2023 年国际癌症支持治疗协会与欧洲肿瘤内科学会共识更新：高致吐风险抗肿瘤药物所致恶心呕吐的预防/癌症支持治疗/2023"
        },
        {
          "type": "共识",
          "author": "中国抗癌协会肿瘤临床化疗专业委员会, 中国抗癌协会肿瘤支持治疗专业委员会",
          "title": "中国肿瘤药物治疗相关恶心呕吐防治专家共识（2022年版）",
          "journal": "中华医学杂志",
          "year": 2022,
          "grade": "专家共识",
          "locate": "DOI 10.3760/cma.j.cn112137-20220810-01724",
          "ref": "R06",
          "cite": "中国抗癌协会肿瘤临床化疗专业委员会, 中国抗癌协会肿瘤支持治疗专业委员会/中国肿瘤药物治疗相关恶心呕吐防治专家共识（2022年版）/中华医学杂志/2022"
        },
        {
          "type": "共识",
          "author": "《四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识》编写专家组",
          "title": "四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识2024版",
          "journal": "中国循证医学杂志",
          "year": 2024,
          "grade": "专家共识",
          "locate": "DOI 10.7507/1672-2531.202407066",
          "ref": "R07",
          "cite": "《四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识》编写专家组/四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识2024版/中国循证医学杂志/2024"
        },
        {
          "type": "指南",
          "author": "美国国家综合癌症网络",
          "title": "美国国家综合癌症网络肿瘤临床实践指南：止吐（2025 年第 2 版）",
          "journal": "美国国家综合癌症网络",
          "year": 2025,
          "grade": "指南（最新版本）",
          "locate": "https://www.nccn.org/guidelines/guidelines-detail?category=3&id=1415",
          "ref": "R03",
          "cite": "美国国家综合癌症网络/美国国家综合癌症网络肿瘤临床实践指南：止吐（2025 年第 2 版）/美国国家综合癌症网络/2025"
        }
      ]
    },
    {
      "id": "t02-strategy-nvp",
      "name": "妊娠期恶心呕吐管理策略",
      "type": "ManagementStrategy",
      "graph": "topic-02",
      "tags": [
        "管理策略",
        "妊娠",
        "总策略"
      ],
      "aliases": [
        "妊娠期恶心呕吐管理策略",
        "孕吐管理策略",
        "NVP management",
        "妊娠期恶心呕吐护理策略",
        "妊娠管理策略"
      ],
      "summary": "以营养支持为核心：少食多餐、避免空腹与油腻食物；症状明显者用维生素 B6 加抗组胺药或甲氧氯普胺；重症（妊娠剧吐）需静脉补液、补充硫胺素并按病情收住院。世界卫生组织与英国皇家妇产科医学院均强调非药物措施优先。",
      "attrs": [
        {
          "k": "分层",
          "v": "轻度饮食调整 / 中度加药 / 重度住院"
        },
        {
          "k": "核心",
          "v": "营养支持 + 少量多餐 + 及时补液"
        },
        {
          "k": "依据",
          "v": "世界卫生组织建议 D.1 + 英国皇家妇产科医学院绿皮书第 69 号"
        },
        {
          "k": "核心原则",
          "v": "非药物优先 · 个体化评估"
        }
      ],
      "evidence": [
        {
          "type": "指南",
          "author": "Nelson-Piercy C, Dean C, Shehmar M, et al.",
          "title": "妊娠期恶心呕吐与妊娠剧吐的管理（英国皇家妇产科医学院绿皮书第 69 号）",
          "journal": "国际妇产科杂志",
          "year": 2024,
          "grade": "指南（最新版本）",
          "locate": "PMID 38311315",
          "ref": "R04",
          "cite": "Nelson-Piercy C, Dean C, Shehmar M, et al./妊娠期恶心呕吐与妊娠剧吐的管理（英国皇家妇产科医学院绿皮书第 69 号）/国际妇产科杂志/2024"
        },
        {
          "type": "建议",
          "author": "世界卫生组织",
          "title": "世界卫生组织关于产前保健促进积极妊娠体验的建议",
          "journal": "世界卫生组织",
          "year": 2016,
          "grade": "指南推荐条目",
          "locate": "ISBN 9789241549912 · 推荐条目 D.1",
          "ref": "R11",
          "cite": "世界卫生组织/世界卫生组织关于产前保健促进积极妊娠体验的建议/世界卫生组织/2016"
        },
        {
          "type": "系统评价",
          "author": "Matthews A, Haas DM, O'Mathúna DP, Dowswell T, Doyle M",
          "title": "妊娠早期恶心呕吐的干预措施",
          "journal": "考克兰系统评价数据库",
          "year": 2015,
          "grade": "系统评价",
          "locate": "DOI 10.1002/14651858.CD007575.pub4",
          "ref": "R18",
          "cite": "Matthews A, Haas DM, O'Mathúna DP, Dowswell T, Doyle M/妊娠早期恶心呕吐的干预措施/考克兰系统评价数据库/2015"
        }
      ]
    },
    {
      "id": "t02-strategy-ponv",
      "name": "术后恶心呕吐管理策略",
      "type": "ManagementStrategy",
      "graph": "topic-02",
      "tags": [
        "管理策略",
        "围术期",
        "总策略"
      ],
      "aliases": [
        "术后恶心呕吐管理策略",
        "PONV管理策略",
        "PONV management",
        "围术期止吐策略",
        "术后恶心呕吐护理策略"
      ],
      "summary": "术前用 Apfel 简化评分分层风险；因多数患者至少有一个危险因素，第五版共识支持广泛的多模式预防（5-HT3 受体拮抗剂 + 地塞米松，必要时加 NK-1 受体拮抗剂）；配合多模式镇痛、避免一氧化二氮与术中低血压、术后早期活动与阿片节约。",
      "attrs": [
        {
          "k": "四步",
          "v": "术前评估 → 广泛多模式预防 → 多模式镇痛 → 术后早活动"
        },
        {
          "k": "共识版本",
          "v": "第五版（2025）"
        },
        {
          "k": "核心原则",
          "v": "普遍预防 + 多模式联合 + 个体化取舍"
        }
      ],
      "evidence": [
        {
          "type": "共识",
          "author": "Gan TJ, Jin Z, Ayad S, et al.",
          "title": "术后恶心呕吐管理第五版共识指南（摘要）",
          "journal": "麻醉与镇痛",
          "year": 2025,
          "grade": "专家共识（最新版本）",
          "locate": "PMID 41237407 · DOI 10.1213/ANE.0000000000007816",
          "ref": "R05",
          "cite": "Gan TJ, Jin Z, Ayad S, et al./术后恶心呕吐管理第五版共识指南（摘要）/麻醉与镇痛/2025"
        },
        {
          "type": "指南",
          "author": "Hesketh PJ, Kris MG, Basch E, et al.",
          "title": "止吐药物：美国临床肿瘤学会指南更新",
          "journal": "临床肿瘤学杂志",
          "year": 2020,
          "grade": "指南（最新版本）",
          "locate": "PMID 32658626 · DOI 10.1200/JCO.20.01296",
          "ref": "R01",
          "cite": "Hesketh PJ, Kris MG, Basch E, et al./止吐药物：美国临床肿瘤学会指南更新/临床肿瘤学杂志/2020"
        },
        {
          "type": "推荐实践",
          "author": "Han J, Xu Q, Wang W, Zhou Y",
          "title": "护士主导的非药物干预在腹腔镜手术成人患者术后恶心呕吐预防与管理中的证据总结",
          "journal": "BMC 护理",
          "year": 2026,
          "grade": "证据总结（推荐实践）",
          "locate": "DOI 10.1186/s12912-026-05029-5",
          "ref": "R17",
          "cite": "Han J, Xu Q, Wang W, Zhou Y/护士主导的非药物干预在腹腔镜手术成人患者术后恶心呕吐预防与管理中的证据总结/BMC 护理/2026"
        }
      ]
    },
    {
      "id": "t02-strategy-integrated",
      "name": "整合症状管理策略",
      "type": "ManagementStrategy",
      "graph": "topic-02",
      "tags": [
        "管理策略",
        "整合",
        "流程"
      ],
      "aliases": [
        "整合症状管理策略",
        "整合照护",
        "综合护理策略",
        "integrated care",
        "症状群管理",
        "恶心呕吐整合管理路径"
      ],
      "summary": "把评估、药物、非药物措施、健康教育与随访整合成一条路径：治疗前评估 → 制定个体化预防方案 → 治疗中动态评估 → 记录症状日记 → 爆发时换机制救援 → 复盘并调整方案。",
      "attrs": [
        {
          "k": "六步",
          "v": "评估 → 计划 → 动态评估 → 记录 → 救援 → 复盘"
        },
        {
          "k": "适合",
          "v": "门诊到病房再到居家的连续照护"
        },
        {
          "k": "核心原则",
          "v": "预防优先 · 动态评估 · 闭环复盘"
        }
      ],
      "evidence": [
        {
          "type": "最佳证据",
          "author": "Zheng P, Ou Y, Jiang J, Liu H, Mo X, Li J",
          "title": "癌症患者化疗相关恶心呕吐评估与管理的最佳证据总结",
          "journal": "长江医学",
          "year": 2023,
          "grade": "最佳证据总结",
          "locate": "DOI 10.4236/ym.2023.71004",
          "ref": "R16",
          "cite": "Zheng P, Ou Y, Jiang J, Liu H, Mo X, Li J/癌症患者化疗相关恶心呕吐评估与管理的最佳证据总结/长江医学/2023"
        },
        {
          "type": "声明",
          "author": "Vidall C, Dielenseger P, Farrell C, et al.",
          "title": "化疗相关恶心呕吐的循证管理：欧洲肿瘤护理论坛立场声明",
          "journal": "欧洲癌症医学科学",
          "year": 2011,
          "grade": "学会立场声明",
          "locate": "PMID 22276054 · DOI 10.3332/ecancer.2011.211",
          "ref": "R13",
          "cite": "Vidall C, Dielenseger P, Farrell C, et al./化疗相关恶心呕吐的循证管理：欧洲肿瘤护理论坛立场声明/欧洲癌症医学科学/2011"
        },
        {
          "type": "推荐实践",
          "author": "Han J, Xu Q, Wang W, Zhou Y",
          "title": "护士主导的非药物干预在腹腔镜手术成人患者术后恶心呕吐预防与管理中的证据总结",
          "journal": "BMC 护理",
          "year": 2026,
          "grade": "证据总结（推荐实践）",
          "locate": "DOI 10.1186/s12912-026-05029-5",
          "ref": "R17",
          "cite": "Han J, Xu Q, Wang W, Zhou Y/护士主导的非药物干预在腹腔镜手术成人患者术后恶心呕吐预防与管理中的证据总结/BMC 护理/2026"
        }
      ]
    },
    {
      "id": "t02-outcome-incidence",
      "name": "恶心呕吐发生率下降",
      "type": "ManagementOutcome",
      "graph": "topic-02",
      "tags": [
        "管理效果",
        "发生率"
      ],
      "aliases": [
        "恶心呕吐发生率下降",
        "降低恶心呕吐发生率",
        "incidence reduction",
        "预防有效",
        "发生率下降"
      ],
      "summary": "规范预防方案后，化疗相关恶心呕吐的发生率从不预防时的约 70%–80% 明显下降；多模式联合方案的完全缓解比例显著提高。",
      "attrs": [
        {
          "k": "衡量",
          "v": "单位时间内发生例数 / 占比"
        },
        {
          "k": "对比",
          "v": "无预防 vs 规范预防"
        }
      ],
      "evidence": [
        {
          "type": "指南",
          "author": "Hesketh PJ, Kris MG, Basch E, et al.",
          "title": "止吐药物：美国临床肿瘤学会指南更新",
          "journal": "临床肿瘤学杂志",
          "year": 2020,
          "grade": "指南（最新版本）",
          "locate": "PMID 32658626 · DOI 10.1200/JCO.20.01296",
          "ref": "R01",
          "cite": "Hesketh PJ, Kris MG, Basch E, et al./止吐药物：美国临床肿瘤学会指南更新/临床肿瘤学杂志/2020"
        },
        {
          "type": "指南",
          "author": "Herrstedt J, Clark-Snow R, Ruhlmann CH, et al.",
          "title": "2023 年国际癌症支持治疗协会与欧洲肿瘤内科学会指南更新：化疗及放疗相关恶心呕吐的预防",
          "journal": "欧洲肿瘤内科学会开放版",
          "year": 2024,
          "grade": "指南（最新版本）",
          "locate": "PMID 38458657 · DOI 10.1016/j.esmoop.2023.102195",
          "ref": "R02",
          "cite": "Herrstedt J, Clark-Snow R, Ruhlmann CH, et al./2023 年国际癌症支持治疗协会与欧洲肿瘤内科学会指南更新：化疗及放疗相关恶心呕吐的预防/欧洲肿瘤内科学会开放版/2024"
        },
        {
          "type": "推荐",
          "author": "Herrstedt J, Celio L, Hesketh PJ, et al.",
          "title": "2023 年国际癌症支持治疗协会与欧洲肿瘤内科学会共识更新：高致吐风险抗肿瘤药物所致恶心呕吐的预防",
          "journal": "癌症支持治疗",
          "year": 2023,
          "grade": "共识推荐条目",
          "locate": "PMID 38127246 · DOI 10.1007/s00520-023-08221-4",
          "ref": "R12",
          "cite": "Herrstedt J, Celio L, Hesketh PJ, et al./2023 年国际癌症支持治疗协会与欧洲肿瘤内科学会共识更新：高致吐风险抗肿瘤药物所致恶心呕吐的预防/癌症支持治疗/2023"
        }
      ]
    },
    {
      "id": "t02-outcome-complete-response",
      "name": "完全缓解",
      "type": "ManagementOutcome",
      "graph": "topic-02",
      "tags": [
        "管理效果",
        "疗效终点"
      ],
      "aliases": [
        "完全缓解",
        "complete response",
        "完全控制",
        "total control",
        "无呕吐且无需补救药"
      ],
      "summary": "抗肿瘤止吐试验中最常用的疗效终点：观察期内无呕吐、无需使用补救止吐药；完全控制还要求恶心不超过轻度。",
      "attrs": [
        {
          "k": "定义",
          "v": "无呕吐 + 无需补救止吐药"
        },
        {
          "k": "分层",
          "v": "急性期 / 延迟期 / 总体"
        }
      ],
      "evidence": [
        {
          "type": "标准",
          "author": "Molassiotis A, Coventry PA, Stricker CT, et al.",
          "title": "化疗相关恶心呕吐简明临床量表的验证与心理测量学评价：国际癌症支持治疗协会止吐自评工具",
          "journal": "疼痛与症状管理杂志",
          "year": 2007,
          "grade": "标准文本（量表信效度验证）",
          "locate": "PMID 17509816 · DOI 10.1016/j.jpainsymman.2006.10.018",
          "ref": "R10",
          "cite": "Molassiotis A, Coventry PA, Stricker CT, et al./化疗相关恶心呕吐简明临床量表的验证与心理测量学评价：国际癌症支持治疗协会止吐自评工具/疼痛与症状管理杂志/2007"
        },
        {
          "type": "指南",
          "author": "Hesketh PJ, Kris MG, Basch E, et al.",
          "title": "止吐药物：美国临床肿瘤学会指南更新",
          "journal": "临床肿瘤学杂志",
          "year": 2020,
          "grade": "指南（最新版本）",
          "locate": "PMID 32658626 · DOI 10.1200/JCO.20.01296",
          "ref": "R01",
          "cite": "Hesketh PJ, Kris MG, Basch E, et al./止吐药物：美国临床肿瘤学会指南更新/临床肿瘤学杂志/2020"
        },
        {
          "type": "最佳证据",
          "author": "Zheng P, Ou Y, Jiang J, Liu H, Mo X, Li J",
          "title": "癌症患者化疗相关恶心呕吐评估与管理的最佳证据总结",
          "journal": "长江医学",
          "year": 2023,
          "grade": "最佳证据总结",
          "locate": "DOI 10.4236/ym.2023.71004",
          "ref": "R16",
          "cite": "Zheng P, Ou Y, Jiang J, Liu H, Mo X, Li J/癌症患者化疗相关恶心呕吐评估与管理的最佳证据总结/长江医学/2023"
        }
      ]
    },
    {
      "id": "t02-outcome-severity",
      "name": "症状严重程度减轻",
      "type": "ManagementOutcome",
      "graph": "topic-02",
      "tags": [
        "管理效果",
        "症状"
      ],
      "aliases": [
        "症状严重程度减轻",
        "恶心程度下降",
        "severity reduction",
        "症状缓解",
        "严重程度下降"
      ],
      "summary": "恶心与呕吐的强度、频率和困扰程度下降，患者的主观感受改善。",
      "attrs": [
        {
          "k": "衡量",
          "v": "量表评分（MAT / VAS / PUQE）变化"
        },
        {
          "k": "人群",
          "v": "患者自评"
        }
      ],
      "evidence": [
        {
          "type": "Meta分析",
          "author": "Gergő D, Garmaa G, Tóth-Mészáros A, et al.",
          "title": "吸入薄荷精油作为恶心呕吐治疗的辅助疗法：一项有前景的补充治疗",
          "journal": "临床医学杂志",
          "year": 2025,
          "grade": "Meta分析",
          "locate": "PMID 40725767 · DOI 10.3390/jcm14145069",
          "ref": "R20",
          "cite": "Gergő D, Garmaa G, Tóth-Mészáros A, et al./吸入薄荷精油作为恶心呕吐治疗的辅助疗法：一项有前景的补充治疗/临床医学杂志/2025"
        },
        {
          "type": "Meta分析",
          "author": "Xiao C, Qin M, Xia H, Xing Q, Wang D, Qian W",
          "title": "内关穴（PC6）按压对恶性肿瘤患者化疗所致急性与延迟性恶心呕吐的影响：荟萃分析",
          "journal": "癌症支持治疗",
          "year": 2023,
          "grade": "Meta分析",
          "locate": "PMID 37548707 · DOI 10.1007/s00520-023-07976-0",
          "ref": "R19",
          "cite": "Xiao C, Qin M, Xia H, Xing Q, Wang D, Qian W/内关穴（PC6）按压对恶性肿瘤患者化疗所致急性与延迟性恶心呕吐的影响：荟萃分析/癌症支持治疗/2023"
        },
        {
          "type": "Meta分析",
          "author": "张英英, 乔欣, 赵丽丽, 汤媛媛, 刘芳",
          "title": "非药物干预对癌症化疗致恶心呕吐影响的网状Meta分析",
          "journal": "循证护理",
          "year": 2024,
          "grade": "Meta分析（网状）",
          "locate": "DOI 10.12102/j.issn.2095-8668.2024.10.001",
          "ref": "R21",
          "cite": "张英英, 乔欣, 赵丽丽, 汤媛媛, 刘芳/非药物干预对癌症化疗致恶心呕吐影响的网状Meta分析/循证护理/2024"
        }
      ]
    },
    {
      "id": "t02-outcome-eating",
      "name": "进食情况改善",
      "type": "ManagementOutcome",
      "graph": "topic-02",
      "tags": [
        "管理效果",
        "营养"
      ],
      "aliases": [
        "进食情况改善",
        "食欲改善",
        "摄入量增加",
        "improved oral intake",
        "缓解进食困难",
        "进食改善"
      ],
      "summary": "能正常进食、进水量足够，营养摄入改善，减少因进食不足而加重恶心呕吐的恶性循环。",
      "attrs": [
        {
          "k": "衡量",
          "v": "进食次数 · 摄入量 · 食欲评分"
        },
        {
          "k": "意义",
          "v": "切断摄入不足与恶心的循环"
        }
      ],
      "evidence": [
        {
          "type": "最佳证据",
          "author": "Zheng P, Ou Y, Jiang J, Liu H, Mo X, Li J",
          "title": "癌症患者化疗相关恶心呕吐评估与管理的最佳证据总结",
          "journal": "长江医学",
          "year": 2023,
          "grade": "最佳证据总结",
          "locate": "DOI 10.4236/ym.2023.71004",
          "ref": "R16",
          "cite": "Zheng P, Ou Y, Jiang J, Liu H, Mo X, Li J/癌症患者化疗相关恶心呕吐评估与管理的最佳证据总结/长江医学/2023"
        },
        {
          "type": "指南",
          "author": "Nelson-Piercy C, Dean C, Shehmar M, et al.",
          "title": "妊娠期恶心呕吐与妊娠剧吐的管理（英国皇家妇产科医学院绿皮书第 69 号）",
          "journal": "国际妇产科杂志",
          "year": 2024,
          "grade": "指南（最新版本）",
          "locate": "PMID 38311315",
          "ref": "R04",
          "cite": "Nelson-Piercy C, Dean C, Shehmar M, et al./妊娠期恶心呕吐与妊娠剧吐的管理（英国皇家妇产科医学院绿皮书第 69 号）/国际妇产科杂志/2024"
        },
        {
          "type": "声明",
          "author": "Vidall C, Dielenseger P, Farrell C, et al.",
          "title": "化疗相关恶心呕吐的循证管理：欧洲肿瘤护理论坛立场声明",
          "journal": "欧洲癌症医学科学",
          "year": 2011,
          "grade": "学会立场声明",
          "locate": "PMID 22276054 · DOI 10.3332/ecancer.2011.211",
          "ref": "R13",
          "cite": "Vidall C, Dielenseger P, Farrell C, et al./化疗相关恶心呕吐的循证管理：欧洲肿瘤护理论坛立场声明/欧洲癌症医学科学/2011"
        }
      ]
    },
    {
      "id": "t02-outcome-weight",
      "name": "体重维持",
      "type": "ManagementOutcome",
      "graph": "topic-02",
      "tags": [
        "管理效果",
        "营养"
      ],
      "aliases": [
        "体重维持",
        "体重稳定",
        "避免体重下降",
        "weight maintenance",
        "体重维持（稳定）"
      ],
      "summary": "治疗期间体重下降减缓或维持稳定，对妊娠剧吐与长期化疗患者意义重大。",
      "attrs": [
        {
          "k": "衡量",
          "v": "体重变化（kg）"
        },
        {
          "k": "关键阈值",
          "v": "妊娠剧吐下降>5% 提示重症"
        }
      ],
      "evidence": [
        {
          "type": "指南",
          "author": "Nelson-Piercy C, Dean C, Shehmar M, et al.",
          "title": "妊娠期恶心呕吐与妊娠剧吐的管理（英国皇家妇产科医学院绿皮书第 69 号）",
          "journal": "国际妇产科杂志",
          "year": 2024,
          "grade": "指南（最新版本）",
          "locate": "PMID 38311315",
          "ref": "R04",
          "cite": "Nelson-Piercy C, Dean C, Shehmar M, et al./妊娠期恶心呕吐与妊娠剧吐的管理（英国皇家妇产科医学院绿皮书第 69 号）/国际妇产科杂志/2024"
        },
        {
          "type": "最佳证据",
          "author": "Zheng P, Ou Y, Jiang J, Liu H, Mo X, Li J",
          "title": "癌症患者化疗相关恶心呕吐评估与管理的最佳证据总结",
          "journal": "长江医学",
          "year": 2023,
          "grade": "最佳证据总结",
          "locate": "DOI 10.4236/ym.2023.71004",
          "ref": "R16",
          "cite": "Zheng P, Ou Y, Jiang J, Liu H, Mo X, Li J/癌症患者化疗相关恶心呕吐评估与管理的最佳证据总结/长江医学/2023"
        }
      ]
    },
    {
      "id": "t02-outcome-qol",
      "name": "生活质量提升",
      "type": "ManagementOutcome",
      "graph": "topic-02",
      "tags": [
        "管理效果",
        "生活质量"
      ],
      "aliases": [
        "生活质量提升",
        "生活质量改善",
        "quality of life",
        "QOL",
        "生活质量提升（改善）"
      ],
      "summary": "恶心呕吐对进食、体力、情绪与日常活动的影响减轻，整体生活质量评分（EORTC QLQ-C30）改善。",
      "attrs": [
        {
          "k": "工具",
          "v": "EORTC QLQ-C30"
        },
        {
          "k": "维度",
          "v": "恶心 · 呕吐 · 整体健康状况"
        }
      ],
      "evidence": [
        {
          "type": "标准",
          "author": "Fayers PM, Aaronson NK, Bjordal K, Groenvold M, Curran D, Bottomley A",
          "title": "肿瘤患者生活质量问卷（EORTC QLQ-C30）评分手册（第 3 版）",
          "journal": "欧洲癌症研究与治疗组织",
          "year": 2001,
          "grade": "标准文本（量表与评分标准）",
          "locate": "ISBN 2-930064-22-6",
          "ref": "R09",
          "cite": "Fayers PM, Aaronson NK, Bjordal K, Groenvold M, Curran D, Bottomley A/肿瘤患者生活质量问卷（EORTC QLQ-C30）评分手册（第 3 版）/欧洲癌症研究与治疗组织/2001"
        },
        {
          "type": "最佳证据",
          "author": "Zheng P, Ou Y, Jiang J, Liu H, Mo X, Li J",
          "title": "癌症患者化疗相关恶心呕吐评估与管理的最佳证据总结",
          "journal": "长江医学",
          "year": 2023,
          "grade": "最佳证据总结",
          "locate": "DOI 10.4236/ym.2023.71004",
          "ref": "R16",
          "cite": "Zheng P, Ou Y, Jiang J, Liu H, Mo X, Li J/癌症患者化疗相关恶心呕吐评估与管理的最佳证据总结/长江医学/2023"
        },
        {
          "type": "声明",
          "author": "Vidall C, Dielenseger P, Farrell C, et al.",
          "title": "化疗相关恶心呕吐的循证管理：欧洲肿瘤护理论坛立场声明",
          "journal": "欧洲癌症医学科学",
          "year": 2011,
          "grade": "学会立场声明",
          "locate": "PMID 22276054 · DOI 10.3332/ecancer.2011.211",
          "ref": "R13",
          "cite": "Vidall C, Dielenseger P, Farrell C, et al./化疗相关恶心呕吐的循证管理：欧洲肿瘤护理论坛立场声明/欧洲癌症医学科学/2011"
        }
      ]
    },
    {
      "id": "t02-outcome-adherence",
      "name": "用药依从性提升",
      "type": "ManagementOutcome",
      "graph": "topic-02",
      "tags": [
        "管理效果",
        "依从性"
      ],
      "aliases": [
        "用药依从性提升",
        "依从性提升",
        "服药依从性",
        "adherence",
        "治疗依从性"
      ],
      "summary": "患者能按时按量完成预防用药与自我记录，用药依从性提高，方案效果才得以实现。",
      "attrs": [
        {
          "k": "衡量",
          "v": "按时服药比例 · 症状日记完成率"
        },
        {
          "k": "护理抓手",
          "v": "健康教育 + 症状日记"
        }
      ],
      "evidence": [
        {
          "type": "共识",
          "author": "《四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识》编写专家组",
          "title": "四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识2024版",
          "journal": "中国循证医学杂志",
          "year": 2024,
          "grade": "专家共识",
          "locate": "DOI 10.7507/1672-2531.202407066",
          "ref": "R07",
          "cite": "《四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识》编写专家组/四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识2024版/中国循证医学杂志/2024"
        },
        {
          "type": "声明",
          "author": "Vidall C, Dielenseger P, Farrell C, et al.",
          "title": "化疗相关恶心呕吐的循证管理：欧洲肿瘤护理论坛立场声明",
          "journal": "欧洲癌症医学科学",
          "year": 2011,
          "grade": "学会立场声明",
          "locate": "PMID 22276054 · DOI 10.3332/ecancer.2011.211",
          "ref": "R13",
          "cite": "Vidall C, Dielenseger P, Farrell C, et al./化疗相关恶心呕吐的循证管理：欧洲肿瘤护理论坛立场声明/欧洲癌症医学科学/2011"
        },
        {
          "type": "推荐实践",
          "author": "Han J, Xu Q, Wang W, Zhou Y",
          "title": "护士主导的非药物干预在腹腔镜手术成人患者术后恶心呕吐预防与管理中的证据总结",
          "journal": "BMC 护理",
          "year": 2026,
          "grade": "证据总结（推荐实践）",
          "locate": "DOI 10.1186/s12912-026-05029-5",
          "ref": "R17",
          "cite": "Han J, Xu Q, Wang W, Zhou Y/护士主导的非药物干预在腹腔镜手术成人患者术后恶心呕吐预防与管理中的证据总结/BMC 护理/2026"
        }
      ]
    },
    {
      "id": "t02-outcome-hospitalization",
      "name": "住院与急诊减少",
      "type": "ManagementOutcome",
      "graph": "topic-02",
      "tags": [
        "管理效果",
        "医疗资源"
      ],
      "aliases": [
        "住院与急诊减少",
        "住院减少",
        "急诊就诊减少",
        "再入院率下降",
        "hospitalization reduction"
      ],
      "summary": "因严重脱水、电解质紊乱或营养不良导致的住院、急诊就诊与延长住院天数减少。",
      "attrs": [
        {
          "k": "衡量",
          "v": "住院率 · 急诊就诊率 · 住院天数"
        },
        {
          "k": "场景",
          "v": "妊娠剧吐、化疗期并发症"
        }
      ],
      "evidence": [
        {
          "type": "最佳证据",
          "author": "Zheng P, Ou Y, Jiang J, Liu H, Mo X, Li J",
          "title": "癌症患者化疗相关恶心呕吐评估与管理的最佳证据总结",
          "journal": "长江医学",
          "year": 2023,
          "grade": "最佳证据总结",
          "locate": "DOI 10.4236/ym.2023.71004",
          "ref": "R16",
          "cite": "Zheng P, Ou Y, Jiang J, Liu H, Mo X, Li J/癌症患者化疗相关恶心呕吐评估与管理的最佳证据总结/长江医学/2023"
        },
        {
          "type": "共识",
          "author": "《四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识》编写专家组",
          "title": "四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识2024版",
          "journal": "中国循证医学杂志",
          "year": 2024,
          "grade": "专家共识",
          "locate": "DOI 10.7507/1672-2531.202407066",
          "ref": "R07",
          "cite": "《四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识》编写专家组/四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识2024版/中国循证医学杂志/2024"
        },
        {
          "type": "声明",
          "author": "Vidall C, Dielenseger P, Farrell C, et al.",
          "title": "化疗相关恶心呕吐的循证管理：欧洲肿瘤护理论坛立场声明",
          "journal": "欧洲癌症医学科学",
          "year": 2011,
          "grade": "学会立场声明",
          "locate": "PMID 22276054 · DOI 10.3332/ecancer.2011.211",
          "ref": "R13",
          "cite": "Vidall C, Dielenseger P, Farrell C, et al./化疗相关恶心呕吐的循证管理：欧洲肿瘤护理论坛立场声明/欧洲癌症医学科学/2011"
        }
      ]
    },
    {
      "id": "t02-status-cinv-incidence",
      "name": "化疗相关恶心呕吐发生率",
      "type": "SymptomStatus",
      "graph": "topic-02",
      "tags": [
        "症状现状",
        "发生率",
        "化疗"
      ],
      "aliases": [
        "化疗相关恶心呕吐发生率",
        "CINV发生率",
        "CINV incidence",
        "化疗恶心呕吐现状"
      ],
      "summary": "未做规范预防时，约 70%–80% 的化疗患者会出现恶心呕吐；规范的多模式预防可显著降低该比例。",
      "attrs": [
        {
          "k": "无预防基线",
          "v": "约 70%–80%"
        },
        {
          "k": "人群",
          "v": "接受抗肿瘤药物治疗的患者"
        }
      ],
      "evidence": [
        {
          "type": "指南",
          "author": "Hesketh PJ, Kris MG, Basch E, et al.",
          "title": "止吐药物：美国临床肿瘤学会指南更新",
          "journal": "临床肿瘤学杂志",
          "year": 2020,
          "grade": "指南（最新版本）",
          "locate": "PMID 32658626 · DOI 10.1200/JCO.20.01296",
          "ref": "R01",
          "cite": "Hesketh PJ, Kris MG, Basch E, et al./止吐药物：美国临床肿瘤学会指南更新/临床肿瘤学杂志/2020"
        },
        {
          "type": "指南",
          "author": "Herrstedt J, Clark-Snow R, Ruhlmann CH, et al.",
          "title": "2023 年国际癌症支持治疗协会与欧洲肿瘤内科学会指南更新：化疗及放疗相关恶心呕吐的预防",
          "journal": "欧洲肿瘤内科学会开放版",
          "year": 2024,
          "grade": "指南（最新版本）",
          "locate": "PMID 38458657 · DOI 10.1016/j.esmoop.2023.102195",
          "ref": "R02",
          "cite": "Herrstedt J, Clark-Snow R, Ruhlmann CH, et al./2023 年国际癌症支持治疗协会与欧洲肿瘤内科学会指南更新：化疗及放疗相关恶心呕吐的预防/欧洲肿瘤内科学会开放版/2024"
        },
        {
          "type": "共识",
          "author": "《四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识》编写专家组",
          "title": "四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识2024版",
          "journal": "中国循证医学杂志",
          "year": 2024,
          "grade": "专家共识",
          "locate": "DOI 10.7507/1672-2531.202407066",
          "ref": "R07",
          "cite": "《四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识》编写专家组/四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识2024版/中国循证医学杂志/2024"
        }
      ]
    },
    {
      "id": "t02-status-ponv-incidence",
      "name": "术后恶心呕吐发生率",
      "type": "SymptomStatus",
      "graph": "topic-02",
      "tags": [
        "症状现状",
        "发生率",
        "围术期"
      ],
      "aliases": [
        "术后恶心呕吐发生率",
        "PONV发生率",
        "PONV incidence",
        "术后恶心呕吐现状"
      ],
      "summary": "总体发生率约 30%；按 Apfel 简化评分分层，低危约 10%、中危约 20%–40%、高危约 60%–80%。",
      "attrs": [
        {
          "k": "总体",
          "v": "约 30%"
        },
        {
          "k": "分层",
          "v": "低危约10% · 中危20–40% · 高危60–80%"
        }
      ],
      "evidence": [
        {
          "type": "共识",
          "author": "Gan TJ, Jin Z, Ayad S, et al.",
          "title": "术后恶心呕吐管理第五版共识指南（摘要）",
          "journal": "麻醉与镇痛",
          "year": 2025,
          "grade": "专家共识（最新版本）",
          "locate": "PMID 41237407 · DOI 10.1213/ANE.0000000000007816",
          "ref": "R05",
          "cite": "Gan TJ, Jin Z, Ayad S, et al./术后恶心呕吐管理第五版共识指南（摘要）/麻醉与镇痛/2025"
        },
        {
          "type": "指南",
          "author": "Hesketh PJ, Kris MG, Basch E, et al.",
          "title": "止吐药物：美国临床肿瘤学会指南更新",
          "journal": "临床肿瘤学杂志",
          "year": 2020,
          "grade": "指南（最新版本）",
          "locate": "PMID 32658626 · DOI 10.1200/JCO.20.01296",
          "ref": "R01",
          "cite": "Hesketh PJ, Kris MG, Basch E, et al./止吐药物：美国临床肿瘤学会指南更新/临床肿瘤学杂志/2020"
        }
      ]
    },
    {
      "id": "t02-status-nvp-incidence",
      "name": "妊娠期恶心呕吐发生率",
      "type": "SymptomStatus",
      "graph": "topic-02",
      "tags": [
        "症状现状",
        "发生率",
        "妊娠"
      ],
      "aliases": [
        "妊娠期恶心呕吐发生率",
        "孕吐发生率",
        "NVP incidence",
        "妊娠恶心发生率"
      ],
      "summary": "妊娠期恶心呕吐见于约 70%–90% 的孕妇，其中约 0.3%–3% 进展为妊娠剧吐需要治疗。",
      "attrs": [
        {
          "k": "总体",
          "v": "约 70%–90%"
        },
        {
          "k": "重症比例",
          "v": "约 0.3%–3%"
        }
      ],
      "evidence": [
        {
          "type": "指南",
          "author": "Nelson-Piercy C, Dean C, Shehmar M, et al.",
          "title": "妊娠期恶心呕吐与妊娠剧吐的管理（英国皇家妇产科医学院绿皮书第 69 号）",
          "journal": "国际妇产科杂志",
          "year": 2024,
          "grade": "指南（最新版本）",
          "locate": "PMID 38311315",
          "ref": "R04",
          "cite": "Nelson-Piercy C, Dean C, Shehmar M, et al./妊娠期恶心呕吐与妊娠剧吐的管理（英国皇家妇产科医学院绿皮书第 69 号）/国际妇产科杂志/2024"
        },
        {
          "type": "系统评价",
          "author": "Matthews A, Haas DM, O'Mathúna DP, Dowswell T, Doyle M",
          "title": "妊娠早期恶心呕吐的干预措施",
          "journal": "考克兰系统评价数据库",
          "year": 2015,
          "grade": "系统评价",
          "locate": "DOI 10.1002/14651858.CD007575.pub4",
          "ref": "R18",
          "cite": "Matthews A, Haas DM, O'Mathúna DP, Dowswell T, Doyle M/妊娠早期恶心呕吐的干预措施/考克兰系统评价数据库/2015"
        }
      ]
    },
    {
      "id": "t02-status-hg-incidence",
      "name": "妊娠剧吐发生率",
      "type": "SymptomStatus",
      "graph": "topic-02",
      "tags": [
        "症状现状",
        "发生率",
        "妊娠"
      ],
      "aliases": [
        "妊娠剧吐发生率",
        "HG发生率",
        "hyperemesis gravidarum incidence",
        "妊娠剧吐现状"
      ],
      "summary": "妊娠期恶心呕吐中约 0.3%–3% 进展为妊娠剧吐，需要住院静脉补液与药物治疗。",
      "attrs": [
        {
          "k": "占妊娠人群",
          "v": "约 0.3%–3%"
        },
        {
          "k": "处理",
          "v": "多需住院静脉补液"
        }
      ],
      "evidence": [
        {
          "type": "指南",
          "author": "Nelson-Piercy C, Dean C, Shehmar M, et al.",
          "title": "妊娠期恶心呕吐与妊娠剧吐的管理（英国皇家妇产科医学院绿皮书第 69 号）",
          "journal": "国际妇产科杂志",
          "year": 2024,
          "grade": "指南（最新版本）",
          "locate": "PMID 38311315",
          "ref": "R04",
          "cite": "Nelson-Piercy C, Dean C, Shehmar M, et al./妊娠期恶心呕吐与妊娠剧吐的管理（英国皇家妇产科医学院绿皮书第 69 号）/国际妇产科杂志/2024"
        },
        {
          "type": "系统评价",
          "author": "Matthews A, Haas DM, O'Mathúna DP, Dowswell T, Doyle M",
          "title": "妊娠早期恶心呕吐的干预措施",
          "journal": "考克兰系统评价数据库",
          "year": 2015,
          "grade": "系统评价",
          "locate": "DOI 10.1002/14651858.CD007575.pub4",
          "ref": "R18",
          "cite": "Matthews A, Haas DM, O'Mathúna DP, Dowswell T, Doyle M/妊娠早期恶心呕吐的干预措施/考克兰系统评价数据库/2015"
        }
      ]
    },
    {
      "id": "t02-status-anticipatory-incidence",
      "name": "预期性恶心呕吐发生率",
      "type": "SymptomStatus",
      "graph": "topic-02",
      "tags": [
        "症状现状",
        "发生率",
        "心理"
      ],
      "aliases": [
        "预期性恶心呕吐发生率",
        "预期性反应发生率",
        "anticipatory incidence"
      ],
      "summary": "预期性恶心呕吐在反复接受化疗的患者中并不少见，与既往化疗体验的强烈程度和焦虑水平直接相关。",
      "attrs": [
        {
          "k": "人群",
          "v": "反复接受化疗者"
        },
        {
          "k": "驱动因素",
          "v": "既往经历 + 焦虑"
        }
      ],
      "evidence": [
        {
          "type": "共识",
          "author": "中国抗癌协会肿瘤临床化疗专业委员会, 中国抗癌协会肿瘤支持治疗专业委员会",
          "title": "中国肿瘤药物治疗相关恶心呕吐防治专家共识（2022年版）",
          "journal": "中华医学杂志",
          "year": 2022,
          "grade": "专家共识",
          "locate": "DOI 10.3760/cma.j.cn112137-20220810-01724",
          "ref": "R06",
          "cite": "中国抗癌协会肿瘤临床化疗专业委员会, 中国抗癌协会肿瘤支持治疗专业委员会/中国肿瘤药物治疗相关恶心呕吐防治专家共识（2022年版）/中华医学杂志/2022"
        },
        {
          "type": "共识",
          "author": "《四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识》编写专家组",
          "title": "四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识2024版",
          "journal": "中国循证医学杂志",
          "year": 2024,
          "grade": "专家共识",
          "locate": "DOI 10.7507/1672-2531.202407066",
          "ref": "R07",
          "cite": "《四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识》编写专家组/四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识2024版/中国循证医学杂志/2024"
        }
      ]
    },
    {
      "id": "t02-status-control-rate",
      "name": "症状控制率",
      "type": "SymptomStatus",
      "graph": "topic-02",
      "tags": [
        "症状现状",
        "控制率"
      ],
      "aliases": [
        "症状控制率",
        "完全缓解率",
        "控制率",
        "control rate",
        "缓解率"
      ],
      "summary": "用药后恶心呕吐完全缓解（无呕吐、无需补救止吐药）的比例，是评价止吐方案效果的核心指标。",
      "attrs": [
        {
          "k": "定义",
          "v": "无呕吐 + 无需补救止吐药"
        },
        {
          "k": "分层",
          "v": "急性期 / 延迟期 / 总体"
        }
      ],
      "evidence": [
        {
          "type": "标准",
          "author": "Molassiotis A, Coventry PA, Stricker CT, et al.",
          "title": "化疗相关恶心呕吐简明临床量表的验证与心理测量学评价：国际癌症支持治疗协会止吐自评工具",
          "journal": "疼痛与症状管理杂志",
          "year": 2007,
          "grade": "标准文本（量表信效度验证）",
          "locate": "PMID 17509816 · DOI 10.1016/j.jpainsymman.2006.10.018",
          "ref": "R10",
          "cite": "Molassiotis A, Coventry PA, Stricker CT, et al./化疗相关恶心呕吐简明临床量表的验证与心理测量学评价：国际癌症支持治疗协会止吐自评工具/疼痛与症状管理杂志/2007"
        },
        {
          "type": "指南",
          "author": "Hesketh PJ, Kris MG, Basch E, et al.",
          "title": "止吐药物：美国临床肿瘤学会指南更新",
          "journal": "临床肿瘤学杂志",
          "year": 2020,
          "grade": "指南（最新版本）",
          "locate": "PMID 32658626 · DOI 10.1200/JCO.20.01296",
          "ref": "R01",
          "cite": "Hesketh PJ, Kris MG, Basch E, et al./止吐药物：美国临床肿瘤学会指南更新/临床肿瘤学杂志/2020"
        }
      ]
    },
    {
      "id": "t02-status-dehydration",
      "name": "脱水",
      "type": "SymptomStatus",
      "graph": "topic-02",
      "tags": [
        "症状现状",
        "伴随状态",
        "并发症"
      ],
      "aliases": [
        "脱水",
        "dehydration",
        "失水",
        "脱水（症状现状）"
      ],
      "summary": "呕吐导致液体丢失与摄入不足，出现口渴、尿量减少、口唇干燥、皮肤弹性下降等表现，重者可出现休克。",
      "attrs": [
        {
          "k": "表现",
          "v": "口渴 · 尿量减少 · 口唇干燥 · 皮肤弹性下降"
        },
        {
          "k": "高危",
          "v": "妊娠剧吐、术后禁食"
        }
      ],
      "evidence": [
        {
          "type": "指南",
          "author": "Nelson-Piercy C, Dean C, Shehmar M, et al.",
          "title": "妊娠期恶心呕吐与妊娠剧吐的管理（英国皇家妇产科医学院绿皮书第 69 号）",
          "journal": "国际妇产科杂志",
          "year": 2024,
          "grade": "指南（最新版本）",
          "locate": "PMID 38311315",
          "ref": "R04",
          "cite": "Nelson-Piercy C, Dean C, Shehmar M, et al./妊娠期恶心呕吐与妊娠剧吐的管理（英国皇家妇产科医学院绿皮书第 69 号）/国际妇产科杂志/2024"
        },
        {
          "type": "书籍",
          "author": "李小寒, 尚少梅",
          "title": "基础护理学（第7版）",
          "journal": "人民卫生出版社",
          "year": 2022,
          "grade": "本科规划教材",
          "locate": "ISBN 9787117333511",
          "ref": "R15",
          "cite": "李小寒, 尚少梅/基础护理学（第7版）/人民卫生出版社/2022"
        }
      ]
    },
    {
      "id": "t02-status-electrolyte",
      "name": "电解质紊乱",
      "type": "SymptomStatus",
      "graph": "topic-02",
      "tags": [
        "症状现状",
        "伴随状态",
        "并发症"
      ],
      "aliases": [
        "电解质紊乱",
        "低钾血症",
        "electrolyte imbalance",
        "水电解质失衡",
        "电解质紊乱（症状现状）"
      ],
      "summary": "呕吐丢失氢离子、氯离子与钾离子，可出现低钾、低钠与代谢性碱中毒，严重时引起心律失常与肌无力。",
      "attrs": [
        {
          "k": "常见异常",
          "v": "低钾 · 低钠 · 代谢性碱中毒"
        },
        {
          "k": "风险",
          "v": "心律失常 · 肌无力"
        },
        {
          "k": "处理",
          "v": "补液 + 纠正电解质，遵医嘱"
        }
      ],
      "evidence": [
        {
          "type": "指南",
          "author": "Nelson-Piercy C, Dean C, Shehmar M, et al.",
          "title": "妊娠期恶心呕吐与妊娠剧吐的管理（英国皇家妇产科医学院绿皮书第 69 号）",
          "journal": "国际妇产科杂志",
          "year": 2024,
          "grade": "指南（最新版本）",
          "locate": "PMID 38311315",
          "ref": "R04",
          "cite": "Nelson-Piercy C, Dean C, Shehmar M, et al./妊娠期恶心呕吐与妊娠剧吐的管理（英国皇家妇产科医学院绿皮书第 69 号）/国际妇产科杂志/2024"
        },
        {
          "type": "最佳证据",
          "author": "Zheng P, Ou Y, Jiang J, Liu H, Mo X, Li J",
          "title": "癌症患者化疗相关恶心呕吐评估与管理的最佳证据总结",
          "journal": "长江医学",
          "year": 2023,
          "grade": "最佳证据总结",
          "locate": "DOI 10.4236/ym.2023.71004",
          "ref": "R16",
          "cite": "Zheng P, Ou Y, Jiang J, Liu H, Mo X, Li J/癌症患者化疗相关恶心呕吐评估与管理的最佳证据总结/长江医学/2023"
        }
      ]
    },
    {
      "id": "t02-status-retching",
      "name": "干呕",
      "type": "SymptomStatus",
      "graph": "topic-02",
      "tags": [
        "症状现状",
        "伴随表现"
      ],
      "aliases": [
        "干呕",
        "retching",
        "恶心性干呕",
        "干呕（症状现状）"
      ],
      "summary": "强烈恶心但无胃内容物排出，频繁干呕仍会带来体力消耗与口腔黏膜损伤。",
      "attrs": [
        {
          "k": "与呕吐的区别",
          "v": "有强烈恶心与呕吐动作，但无内容物排出"
        },
        {
          "k": "后果",
          "v": "体力消耗 · 口腔黏膜损伤"
        }
      ],
      "evidence": [
        {
          "type": "声明",
          "author": "Vidall C, Dielenseger P, Farrell C, et al.",
          "title": "化疗相关恶心呕吐的循证管理：欧洲肿瘤护理论坛立场声明",
          "journal": "欧洲癌症医学科学",
          "year": 2011,
          "grade": "学会立场声明",
          "locate": "PMID 22276054 · DOI 10.3332/ecancer.2011.211",
          "ref": "R13",
          "cite": "Vidall C, Dielenseger P, Farrell C, et al./化疗相关恶心呕吐的循证管理：欧洲肿瘤护理论坛立场声明/欧洲癌症医学科学/2011"
        },
        {
          "type": "书籍",
          "author": "李小寒, 尚少梅",
          "title": "基础护理学（第7版）",
          "journal": "人民卫生出版社",
          "year": 2022,
          "grade": "本科规划教材",
          "locate": "ISBN 9787117333511",
          "ref": "R15",
          "cite": "李小寒, 尚少梅/基础护理学（第7版）/人民卫生出版社/2022"
        }
      ]
    },
    {
      "id": "t02-func-eating",
      "name": "进食受影响",
      "type": "FunctionalStatus",
      "graph": "topic-02",
      "tags": [
        "功能状况",
        "营养"
      ],
      "aliases": [
        "进食受影响",
        "食欲下降",
        "进食困难",
        "影响进食",
        "appetite loss",
        "anorexia",
        "进食受影响（食欲）"
      ],
      "summary": "恶心导致食欲减退、进食量下降，甚至看到食物就产生恶心反射。",
      "attrs": [
        {
          "k": "表现",
          "v": "食欲差 · 进食量减少 · 进食后不适"
        },
        {
          "k": "相关量表",
          "v": "EORTC QLQ-C30 食欲下降与恶心条目"
        }
      ],
      "evidence": [
        {
          "type": "标准",
          "author": "Fayers PM, Aaronson NK, Bjordal K, Groenvold M, Curran D, Bottomley A",
          "title": "肿瘤患者生活质量问卷（EORTC QLQ-C30）评分手册（第 3 版）",
          "journal": "欧洲癌症研究与治疗组织",
          "year": 2001,
          "grade": "标准文本（量表与评分标准）",
          "locate": "ISBN 2-930064-22-6",
          "ref": "R09",
          "cite": "Fayers PM, Aaronson NK, Bjordal K, Groenvold M, Curran D, Bottomley A/肿瘤患者生活质量问卷（EORTC QLQ-C30）评分手册（第 3 版）/欧洲癌症研究与治疗组织/2001"
        },
        {
          "type": "最佳证据",
          "author": "Zheng P, Ou Y, Jiang J, Liu H, Mo X, Li J",
          "title": "癌症患者化疗相关恶心呕吐评估与管理的最佳证据总结",
          "journal": "长江医学",
          "year": 2023,
          "grade": "最佳证据总结",
          "locate": "DOI 10.4236/ym.2023.71004",
          "ref": "R16",
          "cite": "Zheng P, Ou Y, Jiang J, Liu H, Mo X, Li J/癌症患者化疗相关恶心呕吐评估与管理的最佳证据总结/长江医学/2023"
        },
        {
          "type": "声明",
          "author": "Vidall C, Dielenseger P, Farrell C, et al.",
          "title": "化疗相关恶心呕吐的循证管理：欧洲肿瘤护理论坛立场声明",
          "journal": "欧洲癌症医学科学",
          "year": 2011,
          "grade": "学会立场声明",
          "locate": "PMID 22276054 · DOI 10.3332/ecancer.2011.211",
          "ref": "R13",
          "cite": "Vidall C, Dielenseger P, Farrell C, et al./化疗相关恶心呕吐的循证管理：欧洲肿瘤护理论坛立场声明/欧洲癌症医学科学/2011"
        }
      ]
    },
    {
      "id": "t02-func-weight",
      "name": "体重下降",
      "type": "FunctionalStatus",
      "graph": "topic-02",
      "tags": [
        "功能状况",
        "营养"
      ],
      "aliases": [
        "体重下降",
        "体重减轻",
        "weight loss",
        "体重下降（营养）"
      ],
      "summary": "因呕吐与进食不足导致体重下降；妊娠剧吐者体重下降超过 5% 是判断严重程度的重要指标。",
      "attrs": [
        {
          "k": "关键阈值",
          "v": "妊娠剧吐 >5%"
        },
        {
          "k": "监测",
          "v": "固定条件称重"
        }
      ],
      "evidence": [
        {
          "type": "指南",
          "author": "Nelson-Piercy C, Dean C, Shehmar M, et al.",
          "title": "妊娠期恶心呕吐与妊娠剧吐的管理（英国皇家妇产科医学院绿皮书第 69 号）",
          "journal": "国际妇产科杂志",
          "year": 2024,
          "grade": "指南（最新版本）",
          "locate": "PMID 38311315",
          "ref": "R04",
          "cite": "Nelson-Piercy C, Dean C, Shehmar M, et al./妊娠期恶心呕吐与妊娠剧吐的管理（英国皇家妇产科医学院绿皮书第 69 号）/国际妇产科杂志/2024"
        },
        {
          "type": "最佳证据",
          "author": "Zheng P, Ou Y, Jiang J, Liu H, Mo X, Li J",
          "title": "癌症患者化疗相关恶心呕吐评估与管理的最佳证据总结",
          "journal": "长江医学",
          "year": 2023,
          "grade": "最佳证据总结",
          "locate": "DOI 10.4236/ym.2023.71004",
          "ref": "R16",
          "cite": "Zheng P, Ou Y, Jiang J, Liu H, Mo X, Li J/癌症患者化疗相关恶心呕吐评估与管理的最佳证据总结/长江医学/2023"
        }
      ]
    },
    {
      "id": "t02-func-qol",
      "name": "生活质量下降",
      "type": "FunctionalStatus",
      "graph": "topic-02",
      "tags": [
        "功能状况",
        "生活质量"
      ],
      "aliases": [
        "生活质量下降",
        "生活质量受损",
        "quality of life impairment",
        "生活质量下降（受损）"
      ],
      "summary": "症状影响体力、睡眠、情绪与社交活动，EORTC QLQ-C30 的恶心、呕吐与整体健康状况评分下降。",
      "attrs": [
        {
          "k": "工具",
          "v": "EORTC QLQ-C30"
        },
        {
          "k": "受影响维度",
          "v": "恶心 · 呕吐 · 整体健康状况"
        }
      ],
      "evidence": [
        {
          "type": "标准",
          "author": "Fayers PM, Aaronson NK, Bjordal K, Groenvold M, Curran D, Bottomley A",
          "title": "肿瘤患者生活质量问卷（EORTC QLQ-C30）评分手册（第 3 版）",
          "journal": "欧洲癌症研究与治疗组织",
          "year": 2001,
          "grade": "标准文本（量表与评分标准）",
          "locate": "ISBN 2-930064-22-6",
          "ref": "R09",
          "cite": "Fayers PM, Aaronson NK, Bjordal K, Groenvold M, Curran D, Bottomley A/肿瘤患者生活质量问卷（EORTC QLQ-C30）评分手册（第 3 版）/欧洲癌症研究与治疗组织/2001"
        },
        {
          "type": "最佳证据",
          "author": "Zheng P, Ou Y, Jiang J, Liu H, Mo X, Li J",
          "title": "癌症患者化疗相关恶心呕吐评估与管理的最佳证据总结",
          "journal": "长江医学",
          "year": 2023,
          "grade": "最佳证据总结",
          "locate": "DOI 10.4236/ym.2023.71004",
          "ref": "R16",
          "cite": "Zheng P, Ou Y, Jiang J, Liu H, Mo X, Li J/癌症患者化疗相关恶心呕吐评估与管理的最佳证据总结/长江医学/2023"
        }
      ]
    },
    {
      "id": "t02-func-self-care",
      "name": "自我照护能力下降",
      "type": "FunctionalStatus",
      "graph": "topic-02",
      "tags": [
        "功能状况",
        "日常"
      ],
      "aliases": [
        "自我照护能力下降",
        "自理能力下降",
        "ADL受限",
        "日常生活活动受限",
        "impaired self-care",
        "自我照护能力下降（自理）"
      ],
      "summary": "反复呕吐与进食不足使患者在洗漱、进食、服药与活动等日常自理环节能力下降，需要家人和护士协助。",
      "attrs": [
        {
          "k": "受影响环节",
          "v": "洗漱 · 进食 · 服药 · 活动"
        },
        {
          "k": "护理抓手",
          "v": "健康教育 + 家属参与"
        }
      ],
      "evidence": [
        {
          "type": "声明",
          "author": "Vidall C, Dielenseger P, Farrell C, et al.",
          "title": "化疗相关恶心呕吐的循证管理：欧洲肿瘤护理论坛立场声明",
          "journal": "欧洲癌症医学科学",
          "year": 2011,
          "grade": "学会立场声明",
          "locate": "PMID 22276054 · DOI 10.3332/ecancer.2011.211",
          "ref": "R13",
          "cite": "Vidall C, Dielenseger P, Farrell C, et al./化疗相关恶心呕吐的循证管理：欧洲肿瘤护理论坛立场声明/欧洲癌症医学科学/2011"
        },
        {
          "type": "最佳证据",
          "author": "Zheng P, Ou Y, Jiang J, Liu H, Mo X, Li J",
          "title": "癌症患者化疗相关恶心呕吐评估与管理的最佳证据总结",
          "journal": "长江医学",
          "year": 2023,
          "grade": "最佳证据总结",
          "locate": "DOI 10.4236/ym.2023.71004",
          "ref": "R16",
          "cite": "Zheng P, Ou Y, Jiang J, Liu H, Mo X, Li J/癌症患者化疗相关恶心呕吐评估与管理的最佳证据总结/长江医学/2023"
        },
        {
          "type": "推荐实践",
          "author": "Han J, Xu Q, Wang W, Zhou Y",
          "title": "护士主导的非药物干预在腹腔镜手术成人患者术后恶心呕吐预防与管理中的证据总结",
          "journal": "BMC 护理",
          "year": 2026,
          "grade": "证据总结（推荐实践）",
          "locate": "DOI 10.1186/s12912-026-05029-5",
          "ref": "R17",
          "cite": "Han J, Xu Q, Wang W, Zhou Y/护士主导的非药物干预在腹腔镜手术成人患者术后恶心呕吐预防与管理中的证据总结/BMC 护理/2026"
        }
      ]
    },
    {
      "id": "t02-func-activity",
      "name": "活动耐力下降",
      "type": "FunctionalStatus",
      "graph": "topic-02",
      "tags": [
        "功能状况",
        "活动"
      ],
      "aliases": [
        "活动耐力下降",
        "体力下降",
        "乏力",
        "fatigue",
        "活动受限",
        "活动耐力下降（乏力）"
      ],
      "summary": "反复呕吐导致的体液与营养消耗使患者体力下降、活动耐量降低，术后与化疗期间影响早期康复。",
      "attrs": [
        {
          "k": "表现",
          "v": "乏力 · 活动耐量下降"
        },
        {
          "k": "场景",
          "v": "术后早期与化疗周期内"
        }
      ],
      "evidence": [
        {
          "type": "共识",
          "author": "Gan TJ, Jin Z, Ayad S, et al.",
          "title": "术后恶心呕吐管理第五版共识指南（摘要）",
          "journal": "麻醉与镇痛",
          "year": 2025,
          "grade": "专家共识（最新版本）",
          "locate": "PMID 41237407 · DOI 10.1213/ANE.0000000000007816",
          "ref": "R05",
          "cite": "Gan TJ, Jin Z, Ayad S, et al./术后恶心呕吐管理第五版共识指南（摘要）/麻醉与镇痛/2025"
        },
        {
          "type": "最佳证据",
          "author": "Zheng P, Ou Y, Jiang J, Liu H, Mo X, Li J",
          "title": "癌症患者化疗相关恶心呕吐评估与管理的最佳证据总结",
          "journal": "长江医学",
          "year": 2023,
          "grade": "最佳证据总结",
          "locate": "DOI 10.4236/ym.2023.71004",
          "ref": "R16",
          "cite": "Zheng P, Ou Y, Jiang J, Liu H, Mo X, Li J/癌症患者化疗相关恶心呕吐评估与管理的最佳证据总结/长江医学/2023"
        },
        {
          "type": "推荐实践",
          "author": "Han J, Xu Q, Wang W, Zhou Y",
          "title": "护士主导的非药物干预在腹腔镜手术成人患者术后恶心呕吐预防与管理中的证据总结",
          "journal": "BMC 护理",
          "year": 2026,
          "grade": "证据总结（推荐实践）",
          "locate": "DOI 10.1186/s12912-026-05029-5",
          "ref": "R17",
          "cite": "Han J, Xu Q, Wang W, Zhou Y/护士主导的非药物干预在腹腔镜手术成人患者术后恶心呕吐预防与管理中的证据总结/BMC 护理/2026"
        }
      ]
    },
    {
      "id": "t02-func-aspiration-risk",
      "name": "误吸风险",
      "type": "FunctionalStatus",
      "graph": "topic-02",
      "tags": [
        "功能状况",
        "安全"
      ],
      "aliases": [
        "误吸",
        "误吸风险",
        "aspiration risk",
        "吸入性肺炎风险",
        "误吸风险（功能状态）"
      ],
      "summary": "呕吐伴意识障碍、饱腹或胃排空延迟时，呕吐物可被吸入气道，引发吸入性肺炎甚至窒息，是围术期与重症患者的重要安全风险。",
      "attrs": [
        {
          "k": "高危人群",
          "v": "术后麻醉未醒 · 意识障碍 · 胃排空延迟"
        },
        {
          "k": "后果",
          "v": "吸入性肺炎 · 窒息"
        },
        {
          "k": "护理",
          "v": "体位管理 + 口腔护理"
        }
      ],
      "evidence": [
        {
          "type": "共识",
          "author": "Gan TJ, Jin Z, Ayad S, et al.",
          "title": "术后恶心呕吐管理第五版共识指南（摘要）",
          "journal": "麻醉与镇痛",
          "year": 2025,
          "grade": "专家共识（最新版本）",
          "locate": "PMID 41237407 · DOI 10.1213/ANE.0000000000007816",
          "ref": "R05",
          "cite": "Gan TJ, Jin Z, Ayad S, et al./术后恶心呕吐管理第五版共识指南（摘要）/麻醉与镇痛/2025"
        },
        {
          "type": "指南",
          "author": "Nelson-Piercy C, Dean C, Shehmar M, et al.",
          "title": "妊娠期恶心呕吐与妊娠剧吐的管理（英国皇家妇产科医学院绿皮书第 69 号）",
          "journal": "国际妇产科杂志",
          "year": 2024,
          "grade": "指南（最新版本）",
          "locate": "PMID 38311315",
          "ref": "R04",
          "cite": "Nelson-Piercy C, Dean C, Shehmar M, et al./妊娠期恶心呕吐与妊娠剧吐的管理（英国皇家妇产科医学院绿皮书第 69 号）/国际妇产科杂志/2024"
        }
      ]
    },
    {
      "id": "t02-ref-01",
      "name": "止吐药物：美国临床肿瘤学会指南更新",
      "type": "Reference",
      "graph": "topic-02",
      "tags": [
        "文献",
        "出处",
        "指南"
      ],
      "aliases": [
        "指南",
        "guidelines",
        "guideline",
        "临床指南",
        "循证指南",
        "R01"
      ],
      "summary": "止吐药物：美国临床肿瘤学会指南更新（临床肿瘤学杂志，指南，2020）—— 本图谱的一条文献出处。核验标识：PMID 32658626 · DOI 10.1200/JCO.20.01296。",
      "attrs": [
        {
          "k": "文献类型",
          "v": "指南"
        },
        {
          "k": "作者",
          "v": "Hesketh PJ, Kris MG, Basch E, et al."
        },
        {
          "k": "期刊/出处",
          "v": "临床肿瘤学杂志"
        },
        {
          "k": "年份",
          "v": "2020"
        },
        {
          "k": "核验标识",
          "v": "PMID 32658626 · DOI 10.1200/JCO.20.01296"
        },
        {
          "k": "证据等级",
          "v": "指南（最新版本）"
        },
        {
          "k": "证据类型",
          "v": "指南"
        }
      ],
      "evidence": [
        {
          "type": "指南",
          "author": "Hesketh PJ, Kris MG, Basch E, et al.",
          "title": "止吐药物：美国临床肿瘤学会指南更新",
          "journal": "临床肿瘤学杂志",
          "year": 2020,
          "grade": "指南（最新版本）",
          "locate": "PMID 32658626 · DOI 10.1200/JCO.20.01296",
          "ref": "R01",
          "cite": "Hesketh PJ, Kris MG, Basch E, et al./止吐药物：美国临床肿瘤学会指南更新/临床肿瘤学杂志/2020"
        }
      ]
    },
    {
      "id": "t02-ref-02",
      "name": "2023 年国际癌症支持治疗协会与欧洲肿瘤内科学会指南更新：化疗及放疗相关恶心呕吐的预防",
      "type": "Reference",
      "graph": "topic-02",
      "tags": [
        "文献",
        "出处",
        "指南"
      ],
      "aliases": [
        "指南",
        "guidelines",
        "guideline",
        "临床指南",
        "循证指南",
        "R02"
      ],
      "summary": "2023 年国际癌症支持治疗协会与欧洲肿瘤内科学会指南更新：化疗及放疗相关恶心呕吐的预防（欧洲肿瘤内科学会开放版，指南，2024）—— 本图谱的一条文献出处。核验标识：PMID 38458657 · DOI 10.1016/j.esmoop.2023.102195。",
      "attrs": [
        {
          "k": "文献类型",
          "v": "指南"
        },
        {
          "k": "作者",
          "v": "Herrstedt J, Clark-Snow R, Ruhlmann CH, et al."
        },
        {
          "k": "期刊/出处",
          "v": "欧洲肿瘤内科学会开放版"
        },
        {
          "k": "年份",
          "v": "2024"
        },
        {
          "k": "核验标识",
          "v": "PMID 38458657 · DOI 10.1016/j.esmoop.2023.102195"
        },
        {
          "k": "证据等级",
          "v": "指南（最新版本）"
        },
        {
          "k": "证据类型",
          "v": "指南"
        }
      ],
      "evidence": [
        {
          "type": "指南",
          "author": "Herrstedt J, Clark-Snow R, Ruhlmann CH, et al.",
          "title": "2023 年国际癌症支持治疗协会与欧洲肿瘤内科学会指南更新：化疗及放疗相关恶心呕吐的预防",
          "journal": "欧洲肿瘤内科学会开放版",
          "year": 2024,
          "grade": "指南（最新版本）",
          "locate": "PMID 38458657 · DOI 10.1016/j.esmoop.2023.102195",
          "ref": "R02",
          "cite": "Herrstedt J, Clark-Snow R, Ruhlmann CH, et al./2023 年国际癌症支持治疗协会与欧洲肿瘤内科学会指南更新：化疗及放疗相关恶心呕吐的预防/欧洲肿瘤内科学会开放版/2024"
        }
      ]
    },
    {
      "id": "t02-ref-03",
      "name": "美国国家综合癌症网络肿瘤临床实践指南：止吐（2025 年第 2 版）",
      "type": "Reference",
      "graph": "topic-02",
      "tags": [
        "文献",
        "出处",
        "指南"
      ],
      "aliases": [
        "指南",
        "guidelines",
        "guideline",
        "临床指南",
        "循证指南",
        "R03"
      ],
      "summary": "美国国家综合癌症网络肿瘤临床实践指南：止吐（2025 年第 2 版）（美国国家综合癌症网络，指南，2025）—— 本图谱的一条文献出处。核验标识：https://www.nccn.org/guidelines/guidelines-detail?category=3&id=1415。",
      "attrs": [
        {
          "k": "文献类型",
          "v": "指南"
        },
        {
          "k": "作者",
          "v": "美国国家综合癌症网络"
        },
        {
          "k": "期刊/出处",
          "v": "美国国家综合癌症网络"
        },
        {
          "k": "年份",
          "v": "2025"
        },
        {
          "k": "核验标识",
          "v": "https://www.nccn.org/guidelines/guidelines-detail?category=3&id=1415"
        },
        {
          "k": "证据等级",
          "v": "指南（最新版本）"
        },
        {
          "k": "证据类型",
          "v": "指南"
        }
      ],
      "evidence": [
        {
          "type": "指南",
          "author": "美国国家综合癌症网络",
          "title": "美国国家综合癌症网络肿瘤临床实践指南：止吐（2025 年第 2 版）",
          "journal": "美国国家综合癌症网络",
          "year": 2025,
          "grade": "指南（最新版本）",
          "locate": "https://www.nccn.org/guidelines/guidelines-detail?category=3&id=1415",
          "ref": "R03",
          "cite": "美国国家综合癌症网络/美国国家综合癌症网络肿瘤临床实践指南：止吐（2025 年第 2 版）/美国国家综合癌症网络/2025"
        }
      ]
    },
    {
      "id": "t02-ref-04",
      "name": "妊娠期恶心呕吐与妊娠剧吐的管理（英国皇家妇产科医学院绿皮书第 69 号）",
      "type": "Reference",
      "graph": "topic-02",
      "tags": [
        "文献",
        "出处",
        "指南"
      ],
      "aliases": [
        "指南",
        "guidelines",
        "guideline",
        "临床指南",
        "循证指南",
        "R04"
      ],
      "summary": "妊娠期恶心呕吐与妊娠剧吐的管理（英国皇家妇产科医学院绿皮书第 69 号）（国际妇产科杂志，指南，2024）—— 本图谱的一条文献出处。核验标识：PMID 38311315。",
      "attrs": [
        {
          "k": "文献类型",
          "v": "指南"
        },
        {
          "k": "作者",
          "v": "Nelson-Piercy C, Dean C, Shehmar M, et al."
        },
        {
          "k": "期刊/出处",
          "v": "国际妇产科杂志"
        },
        {
          "k": "年份",
          "v": "2024"
        },
        {
          "k": "核验标识",
          "v": "PMID 38311315"
        },
        {
          "k": "证据等级",
          "v": "指南（最新版本）"
        },
        {
          "k": "证据类型",
          "v": "指南"
        }
      ],
      "evidence": [
        {
          "type": "指南",
          "author": "Nelson-Piercy C, Dean C, Shehmar M, et al.",
          "title": "妊娠期恶心呕吐与妊娠剧吐的管理（英国皇家妇产科医学院绿皮书第 69 号）",
          "journal": "国际妇产科杂志",
          "year": 2024,
          "grade": "指南（最新版本）",
          "locate": "PMID 38311315",
          "ref": "R04",
          "cite": "Nelson-Piercy C, Dean C, Shehmar M, et al./妊娠期恶心呕吐与妊娠剧吐的管理（英国皇家妇产科医学院绿皮书第 69 号）/国际妇产科杂志/2024"
        }
      ]
    },
    {
      "id": "t02-ref-05",
      "name": "术后恶心呕吐管理第五版共识指南（摘要）",
      "type": "Reference",
      "graph": "topic-02",
      "tags": [
        "文献",
        "出处",
        "共识"
      ],
      "aliases": [
        "共识",
        "consensus",
        "专家共识",
        "R05"
      ],
      "summary": "术后恶心呕吐管理第五版共识指南（摘要）（麻醉与镇痛，共识，2025）—— 本图谱的一条文献出处。核验标识：PMID 41237407 · DOI 10.1213/ANE.0000000000007816。",
      "attrs": [
        {
          "k": "文献类型",
          "v": "共识"
        },
        {
          "k": "作者",
          "v": "Gan TJ, Jin Z, Ayad S, et al."
        },
        {
          "k": "期刊/出处",
          "v": "麻醉与镇痛"
        },
        {
          "k": "年份",
          "v": "2025"
        },
        {
          "k": "核验标识",
          "v": "PMID 41237407 · DOI 10.1213/ANE.0000000000007816"
        },
        {
          "k": "证据等级",
          "v": "专家共识（最新版本）"
        },
        {
          "k": "证据类型",
          "v": "共识"
        }
      ],
      "evidence": [
        {
          "type": "共识",
          "author": "Gan TJ, Jin Z, Ayad S, et al.",
          "title": "术后恶心呕吐管理第五版共识指南（摘要）",
          "journal": "麻醉与镇痛",
          "year": 2025,
          "grade": "专家共识（最新版本）",
          "locate": "PMID 41237407 · DOI 10.1213/ANE.0000000000007816",
          "ref": "R05",
          "cite": "Gan TJ, Jin Z, Ayad S, et al./术后恶心呕吐管理第五版共识指南（摘要）/麻醉与镇痛/2025"
        }
      ]
    },
    {
      "id": "t02-ref-06",
      "name": "中国肿瘤药物治疗相关恶心呕吐防治专家共识（2022年版）",
      "type": "Reference",
      "graph": "topic-02",
      "tags": [
        "文献",
        "出处",
        "共识"
      ],
      "aliases": [
        "共识",
        "consensus",
        "专家共识",
        "R06"
      ],
      "summary": "中国肿瘤药物治疗相关恶心呕吐防治专家共识（2022年版）（中华医学杂志，共识，2022）—— 本图谱的一条文献出处。核验标识：DOI 10.3760/cma.j.cn112137-20220810-01724。",
      "attrs": [
        {
          "k": "文献类型",
          "v": "共识"
        },
        {
          "k": "作者",
          "v": "中国抗癌协会肿瘤临床化疗专业委员会, 中国抗癌协会肿瘤支持治疗专业委员会"
        },
        {
          "k": "期刊/出处",
          "v": "中华医学杂志"
        },
        {
          "k": "年份",
          "v": "2022"
        },
        {
          "k": "核验标识",
          "v": "DOI 10.3760/cma.j.cn112137-20220810-01724"
        },
        {
          "k": "证据等级",
          "v": "专家共识"
        },
        {
          "k": "证据类型",
          "v": "共识"
        }
      ],
      "evidence": [
        {
          "type": "共识",
          "author": "中国抗癌协会肿瘤临床化疗专业委员会, 中国抗癌协会肿瘤支持治疗专业委员会",
          "title": "中国肿瘤药物治疗相关恶心呕吐防治专家共识（2022年版）",
          "journal": "中华医学杂志",
          "year": 2022,
          "grade": "专家共识",
          "locate": "DOI 10.3760/cma.j.cn112137-20220810-01724",
          "ref": "R06",
          "cite": "中国抗癌协会肿瘤临床化疗专业委员会, 中国抗癌协会肿瘤支持治疗专业委员会/中国肿瘤药物治疗相关恶心呕吐防治专家共识（2022年版）/中华医学杂志/2022"
        }
      ]
    },
    {
      "id": "t02-ref-07",
      "name": "四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识2024版",
      "type": "Reference",
      "graph": "topic-02",
      "tags": [
        "文献",
        "出处",
        "共识"
      ],
      "aliases": [
        "共识",
        "consensus",
        "专家共识",
        "R07"
      ],
      "summary": "四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识2024版（中国循证医学杂志，共识，2024）—— 本图谱的一条文献出处。核验标识：DOI 10.7507/1672-2531.202407066。",
      "attrs": [
        {
          "k": "文献类型",
          "v": "共识"
        },
        {
          "k": "作者",
          "v": "《四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识》编写专家组"
        },
        {
          "k": "期刊/出处",
          "v": "中国循证医学杂志"
        },
        {
          "k": "年份",
          "v": "2024"
        },
        {
          "k": "核验标识",
          "v": "DOI 10.7507/1672-2531.202407066"
        },
        {
          "k": "证据等级",
          "v": "专家共识"
        },
        {
          "k": "证据类型",
          "v": "共识"
        }
      ],
      "evidence": [
        {
          "type": "共识",
          "author": "《四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识》编写专家组",
          "title": "四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识2024版",
          "journal": "中国循证医学杂志",
          "year": 2024,
          "grade": "专家共识",
          "locate": "DOI 10.7507/1672-2531.202407066",
          "ref": "R07",
          "cite": "《四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识》编写专家组/四川省防控抗肿瘤药物治疗相关恶心呕吐专家共识2024版/中国循证医学杂志/2024"
        }
      ]
    },
    {
      "id": "t02-ref-08",
      "name": "不良事件通用术语标准（CTCAE 第 5.0 版）",
      "type": "Reference",
      "graph": "topic-02",
      "tags": [
        "文献",
        "出处",
        "标准"
      ],
      "aliases": [
        "标准",
        "standards",
        "standard",
        "评价标准",
        "行业标准",
        "R08"
      ],
      "summary": "不良事件通用术语标准（CTCAE 第 5.0 版）（美国国家癌症研究所，标准，2017）—— 本图谱的一条文献出处。核验标识：https://ctep.cancer.gov/protocoldevelopment/electronic_applications/ctc.htm。",
      "attrs": [
        {
          "k": "文献类型",
          "v": "标准"
        },
        {
          "k": "作者",
          "v": "美国国立卫生研究院·国家癌症研究所"
        },
        {
          "k": "期刊/出处",
          "v": "美国国家癌症研究所"
        },
        {
          "k": "年份",
          "v": "2017"
        },
        {
          "k": "核验标识",
          "v": "https://ctep.cancer.gov/protocoldevelopment/electronic_applications/ctc.htm"
        },
        {
          "k": "证据等级",
          "v": "标准文本"
        },
        {
          "k": "证据类型",
          "v": "标准"
        }
      ],
      "evidence": [
        {
          "type": "标准",
          "author": "美国国立卫生研究院·国家癌症研究所",
          "title": "不良事件通用术语标准（CTCAE 第 5.0 版）",
          "journal": "美国国家癌症研究所",
          "year": 2017,
          "grade": "标准文本",
          "locate": "https://ctep.cancer.gov/protocoldevelopment/electronic_applications/ctc.htm",
          "ref": "R08",
          "cite": "美国国立卫生研究院, 美国国家癌症研究所/不良事件通用术语标准（CTCAE 第 5.0 版）/美国国家癌症研究所/2017"
        }
      ]
    },
    {
      "id": "t02-ref-09",
      "name": "肿瘤患者生活质量问卷（EORTC QLQ-C30）评分手册（第 3 版）",
      "type": "Reference",
      "graph": "topic-02",
      "tags": [
        "文献",
        "出处",
        "标准"
      ],
      "aliases": [
        "标准",
        "standards",
        "standard",
        "评价标准",
        "行业标准",
        "R09"
      ],
      "summary": "肿瘤患者生活质量问卷（EORTC QLQ-C30）评分手册（第 3 版）（欧洲癌症研究与治疗组织，标准，2001）—— 本图谱的一条文献出处。核验标识：ISBN 2-930064-22-6。",
      "attrs": [
        {
          "k": "文献类型",
          "v": "标准"
        },
        {
          "k": "作者",
          "v": "Fayers PM, Aaronson NK, Bjordal K, Groenvold M, Curran D, Bottomley A"
        },
        {
          "k": "期刊/出处",
          "v": "欧洲癌症研究与治疗组织"
        },
        {
          "k": "年份",
          "v": "2001"
        },
        {
          "k": "核验标识",
          "v": "ISBN 2-930064-22-6"
        },
        {
          "k": "证据等级",
          "v": "标准文本（量表与评分标准）"
        },
        {
          "k": "证据类型",
          "v": "标准"
        }
      ],
      "evidence": [
        {
          "type": "标准",
          "author": "Fayers PM, Aaronson NK, Bjordal K, Groenvold M, Curran D, Bottomley A",
          "title": "肿瘤患者生活质量问卷（EORTC QLQ-C30）评分手册（第 3 版）",
          "journal": "欧洲癌症研究与治疗组织",
          "year": 2001,
          "grade": "标准文本（量表与评分标准）",
          "locate": "ISBN 2-930064-22-6",
          "ref": "R09",
          "cite": "Fayers PM, Aaronson NK, Bjordal K, Groenvold M, Curran D, Bottomley A/肿瘤患者生活质量问卷（EORTC QLQ-C30）评分手册（第 3 版）/欧洲癌症研究与治疗组织/2001"
        }
      ]
    },
    {
      "id": "t02-ref-10",
      "name": "化疗相关恶心呕吐简明临床量表的验证与心理测量学评价：国际癌症支持治疗协会止吐自评工具",
      "type": "Reference",
      "graph": "topic-02",
      "tags": [
        "文献",
        "出处",
        "标准"
      ],
      "aliases": [
        "标准",
        "standards",
        "standard",
        "评价标准",
        "行业标准",
        "R10"
      ],
      "summary": "化疗相关恶心呕吐简明临床量表的验证与心理测量学评价：国际癌症支持治疗协会止吐自评工具（疼痛与症状管理杂志，标准，2007）—— 本图谱的一条文献出处。核验标识：PMID 17509816 · DOI 10.1016/j.jpainsymman.2006.10.018。",
      "attrs": [
        {
          "k": "文献类型",
          "v": "标准"
        },
        {
          "k": "作者",
          "v": "Molassiotis A, Coventry PA, Stricker CT, et al."
        },
        {
          "k": "期刊/出处",
          "v": "疼痛与症状管理杂志"
        },
        {
          "k": "年份",
          "v": "2007"
        },
        {
          "k": "核验标识",
          "v": "PMID 17509816 · DOI 10.1016/j.jpainsymman.2006.10.018"
        },
        {
          "k": "证据等级",
          "v": "标准文本（量表信效度验证）"
        },
        {
          "k": "证据类型",
          "v": "标准"
        }
      ],
      "evidence": [
        {
          "type": "标准",
          "author": "Molassiotis A, Coventry PA, Stricker CT, et al.",
          "title": "化疗相关恶心呕吐简明临床量表的验证与心理测量学评价：国际癌症支持治疗协会止吐自评工具",
          "journal": "疼痛与症状管理杂志",
          "year": 2007,
          "grade": "标准文本（量表信效度验证）",
          "locate": "PMID 17509816 · DOI 10.1016/j.jpainsymman.2006.10.018",
          "ref": "R10",
          "cite": "Molassiotis A, Coventry PA, Stricker CT, et al./化疗相关恶心呕吐简明临床量表的验证与心理测量学评价：国际癌症支持治疗协会止吐自评工具/疼痛与症状管理杂志/2007"
        }
      ]
    },
    {
      "id": "t02-ref-11",
      "name": "世界卫生组织关于产前保健促进积极妊娠体验的建议",
      "type": "Reference",
      "graph": "topic-02",
      "tags": [
        "文献",
        "出处",
        "建议"
      ],
      "aliases": [
        "建议",
        "recommendations",
        "recommendation",
        "推荐建议",
        "R11"
      ],
      "summary": "世界卫生组织关于产前保健促进积极妊娠体验的建议（世界卫生组织，建议，2016）—— 本图谱的一条文献出处。核验标识：ISBN 9789241549912 · 推荐条目 D.1。",
      "attrs": [
        {
          "k": "文献类型",
          "v": "建议"
        },
        {
          "k": "作者",
          "v": "世界卫生组织"
        },
        {
          "k": "期刊/出处",
          "v": "世界卫生组织"
        },
        {
          "k": "年份",
          "v": "2016"
        },
        {
          "k": "核验标识",
          "v": "ISBN 9789241549912 · 推荐条目 D.1"
        },
        {
          "k": "证据等级",
          "v": "指南推荐条目"
        },
        {
          "k": "证据类型",
          "v": "建议"
        }
      ],
      "evidence": [
        {
          "type": "建议",
          "author": "世界卫生组织",
          "title": "世界卫生组织关于产前保健促进积极妊娠体验的建议",
          "journal": "世界卫生组织",
          "year": 2016,
          "grade": "指南推荐条目",
          "locate": "ISBN 9789241549912 · 推荐条目 D.1",
          "ref": "R11",
          "cite": "世界卫生组织/世界卫生组织关于产前保健促进积极妊娠体验的建议/世界卫生组织/2016"
        }
      ]
    },
    {
      "id": "t02-ref-12",
      "name": "2023 年国际癌症支持治疗协会与欧洲肿瘤内科学会共识更新：高致吐风险抗肿瘤药物所致恶心呕吐的预防",
      "type": "Reference",
      "graph": "topic-02",
      "tags": [
        "文献",
        "出处",
        "推荐"
      ],
      "aliases": [
        "推荐",
        "recommendations",
        "recommended practice",
        "共识推荐",
        "R12"
      ],
      "summary": "2023 年国际癌症支持治疗协会与欧洲肿瘤内科学会共识更新：高致吐风险抗肿瘤药物所致恶心呕吐的预防（癌症支持治疗，推荐，2023）—— 本图谱的一条文献出处。核验标识：PMID 38127246 · DOI 10.1007/s00520-023-08221-4。",
      "attrs": [
        {
          "k": "文献类型",
          "v": "推荐"
        },
        {
          "k": "作者",
          "v": "Herrstedt J, Celio L, Hesketh PJ, et al."
        },
        {
          "k": "期刊/出处",
          "v": "癌症支持治疗"
        },
        {
          "k": "年份",
          "v": "2023"
        },
        {
          "k": "核验标识",
          "v": "PMID 38127246 · DOI 10.1007/s00520-023-08221-4"
        },
        {
          "k": "证据等级",
          "v": "共识推荐条目"
        },
        {
          "k": "证据类型",
          "v": "推荐"
        }
      ],
      "evidence": [
        {
          "type": "推荐",
          "author": "Herrstedt J, Celio L, Hesketh PJ, et al.",
          "title": "2023 年国际癌症支持治疗协会与欧洲肿瘤内科学会共识更新：高致吐风险抗肿瘤药物所致恶心呕吐的预防",
          "journal": "癌症支持治疗",
          "year": 2023,
          "grade": "共识推荐条目",
          "locate": "PMID 38127246 · DOI 10.1007/s00520-023-08221-4",
          "ref": "R12",
          "cite": "Herrstedt J, Celio L, Hesketh PJ, et al./2023 年国际癌症支持治疗协会与欧洲肿瘤内科学会共识更新：高致吐风险抗肿瘤药物所致恶心呕吐的预防/癌症支持治疗/2023"
        }
      ]
    },
    {
      "id": "t02-ref-13",
      "name": "化疗相关恶心呕吐的循证管理：欧洲肿瘤护理论坛立场声明",
      "type": "Reference",
      "graph": "topic-02",
      "tags": [
        "文献",
        "出处",
        "声明"
      ],
      "aliases": [
        "声明",
        "position statement",
        "立场声明",
        "学会声明",
        "R13"
      ],
      "summary": "化疗相关恶心呕吐的循证管理：欧洲肿瘤护理论坛立场声明（欧洲癌症医学科学，声明，2011）—— 本图谱的一条文献出处。核验标识：PMID 22276054 · DOI 10.3332/ecancer.2011.211。",
      "attrs": [
        {
          "k": "文献类型",
          "v": "声明"
        },
        {
          "k": "作者",
          "v": "Vidall C, Dielenseger P, Farrell C, et al."
        },
        {
          "k": "期刊/出处",
          "v": "欧洲癌症医学科学"
        },
        {
          "k": "年份",
          "v": "2011"
        },
        {
          "k": "核验标识",
          "v": "PMID 22276054 · DOI 10.3332/ecancer.2011.211"
        },
        {
          "k": "证据等级",
          "v": "学会立场声明"
        },
        {
          "k": "证据类型",
          "v": "声明"
        }
      ],
      "evidence": [
        {
          "type": "声明",
          "author": "Vidall C, Dielenseger P, Farrell C, et al.",
          "title": "化疗相关恶心呕吐的循证管理：欧洲肿瘤护理论坛立场声明",
          "journal": "欧洲癌症医学科学",
          "year": 2011,
          "grade": "学会立场声明",
          "locate": "PMID 22276054 · DOI 10.3332/ecancer.2011.211",
          "ref": "R13",
          "cite": "Vidall C, Dielenseger P, Farrell C, et al./化疗相关恶心呕吐的循证管理：欧洲肿瘤护理论坛立场声明/欧洲癌症医学科学/2011"
        }
      ]
    },
    {
      "id": "t02-ref-14",
      "name": "成人肠内营养支持的护理",
      "type": "Reference",
      "graph": "topic-02",
      "tags": [
        "文献",
        "出处",
        "规范"
      ],
      "aliases": [
        "规范",
        "practice guideline",
        "护理规范",
        "操作规范",
        "团体标准",
        "R14"
      ],
      "summary": "成人肠内营养支持的护理（中华护理学会，规范，2021）—— 本图谱的一条文献出处。核验标识：T/CNAS 19—2020（编号年 2020 · 发布 2021-02-01 · 实施 2021-05-01）· https://www.ttbz.org.cn/standardDetail.html?id=s6s3qhpso8xyf3jot0eth1xlyxizyls。",
      "attrs": [
        {
          "k": "文献类型",
          "v": "规范"
        },
        {
          "k": "作者",
          "v": "中华护理学会"
        },
        {
          "k": "期刊/出处",
          "v": "中华护理学会"
        },
        {
          "k": "年份",
          "v": "2021"
        },
        {
          "k": "核验标识",
          "v": "T/CNAS 19—2020（编号年 2020 · 发布 2021-02-01 · 实施 2021-05-01）· https://www.ttbz.org.cn/standardDetail.html?id=s6s3qhpso8xyf3jot0eth1xlyxizyls"
        },
        {
          "k": "证据等级",
          "v": "团体标准（护理规范）"
        },
        {
          "k": "证据类型",
          "v": "规范"
        }
      ],
      "evidence": [
        {
          "type": "规范",
          "author": "中华护理学会",
          "title": "成人肠内营养支持的护理",
          "journal": "中华护理学会",
          "year": 2021,
          "grade": "团体标准（护理规范）",
          "locate": "T/CNAS 19—2020（编号年 2020 · 发布 2021-02-01 · 实施 2021-05-01）· https://www.ttbz.org.cn/standardDetail.html?id=s6s3qhpso8xyf3jot0eth1xlyxizyls",
          "ref": "R14",
          "cite": "中华护理学会/成人肠内营养支持的护理/中华护理学会/2021"
        }
      ]
    },
    {
      "id": "t02-ref-15",
      "name": "基础护理学（第7版）",
      "type": "Reference",
      "graph": "topic-02",
      "tags": [
        "文献",
        "出处",
        "书籍"
      ],
      "aliases": [
        "书籍",
        "books",
        "book",
        "教材",
        "教科书",
        "R15"
      ],
      "summary": "基础护理学（第7版）（人民卫生出版社，书籍，2022）—— 本图谱的一条文献出处。核验标识：ISBN 9787117333511。",
      "attrs": [
        {
          "k": "文献类型",
          "v": "书籍"
        },
        {
          "k": "作者",
          "v": "李小寒, 尚少梅"
        },
        {
          "k": "期刊/出处",
          "v": "人民卫生出版社"
        },
        {
          "k": "年份",
          "v": "2022"
        },
        {
          "k": "核验标识",
          "v": "ISBN 9787117333511"
        },
        {
          "k": "证据等级",
          "v": "本科规划教材"
        },
        {
          "k": "证据类型",
          "v": "书籍"
        }
      ],
      "evidence": [
        {
          "type": "书籍",
          "author": "李小寒, 尚少梅",
          "title": "基础护理学（第7版）",
          "journal": "人民卫生出版社",
          "year": 2022,
          "grade": "本科规划教材",
          "locate": "ISBN 9787117333511",
          "ref": "R15",
          "cite": "李小寒, 尚少梅/基础护理学（第7版）/人民卫生出版社/2022"
        }
      ]
    },
    {
      "id": "t02-ref-16",
      "name": "癌症患者化疗相关恶心呕吐评估与管理的最佳证据总结",
      "type": "Reference",
      "graph": "topic-02",
      "tags": [
        "文献",
        "出处",
        "最佳证据"
      ],
      "aliases": [
        "最佳证据",
        "best evidence",
        "最佳证据总结",
        "证据总结",
        "R16"
      ],
      "summary": "癌症患者化疗相关恶心呕吐评估与管理的最佳证据总结（长江医学，最佳证据，2023）—— 本图谱的一条文献出处。核验标识：DOI 10.4236/ym.2023.71004。",
      "attrs": [
        {
          "k": "文献类型",
          "v": "最佳证据"
        },
        {
          "k": "作者",
          "v": "Zheng P, Ou Y, Jiang J, Liu H, Mo X, Li J"
        },
        {
          "k": "期刊/出处",
          "v": "长江医学"
        },
        {
          "k": "年份",
          "v": "2023"
        },
        {
          "k": "核验标识",
          "v": "DOI 10.4236/ym.2023.71004"
        },
        {
          "k": "证据等级",
          "v": "最佳证据总结"
        },
        {
          "k": "证据类型",
          "v": "最佳证据"
        }
      ],
      "evidence": [
        {
          "type": "最佳证据",
          "author": "Zheng P, Ou Y, Jiang J, Liu H, Mo X, Li J",
          "title": "癌症患者化疗相关恶心呕吐评估与管理的最佳证据总结",
          "journal": "长江医学",
          "year": 2023,
          "grade": "最佳证据总结",
          "locate": "DOI 10.4236/ym.2023.71004",
          "ref": "R16",
          "cite": "Zheng P, Ou Y, Jiang J, Liu H, Mo X, Li J/癌症患者化疗相关恶心呕吐评估与管理的最佳证据总结/长江医学/2023"
        }
      ]
    },
    {
      "id": "t02-ref-17",
      "name": "护士主导的非药物干预在腹腔镜手术成人患者术后恶心呕吐预防与管理中的证据总结",
      "type": "Reference",
      "graph": "topic-02",
      "tags": [
        "文献",
        "出处",
        "推荐实践"
      ],
      "aliases": [
        "推荐实践",
        "recommended practice",
        "最佳实践",
        "实践推荐",
        "evidence summary",
        "R17"
      ],
      "summary": "护士主导的非药物干预在腹腔镜手术成人患者术后恶心呕吐预防与管理中的证据总结（BMC 护理，推荐实践，2026）—— 本图谱的一条文献出处。核验标识：DOI 10.1186/s12912-026-05029-5。",
      "attrs": [
        {
          "k": "文献类型",
          "v": "推荐实践"
        },
        {
          "k": "作者",
          "v": "Han J, Xu Q, Wang W, Zhou Y"
        },
        {
          "k": "期刊/出处",
          "v": "BMC 护理"
        },
        {
          "k": "年份",
          "v": "2026"
        },
        {
          "k": "核验标识",
          "v": "DOI 10.1186/s12912-026-05029-5"
        },
        {
          "k": "证据等级",
          "v": "证据总结（推荐实践）"
        },
        {
          "k": "证据类型",
          "v": "推荐实践"
        }
      ],
      "evidence": [
        {
          "type": "推荐实践",
          "author": "Han J, Xu Q, Wang W, Zhou Y",
          "title": "护士主导的非药物干预在腹腔镜手术成人患者术后恶心呕吐预防与管理中的证据总结",
          "journal": "BMC 护理",
          "year": 2026,
          "grade": "证据总结（推荐实践）",
          "locate": "DOI 10.1186/s12912-026-05029-5",
          "ref": "R17",
          "cite": "Han J, Xu Q, Wang W, Zhou Y/护士主导的非药物干预在腹腔镜手术成人患者术后恶心呕吐预防与管理中的证据总结/BMC 护理/2026"
        }
      ]
    },
    {
      "id": "t02-ref-18",
      "name": "妊娠早期恶心呕吐的干预措施",
      "type": "Reference",
      "graph": "topic-02",
      "tags": [
        "文献",
        "出处",
        "系统评价"
      ],
      "aliases": [
        "系统评价",
        "systematic reviews",
        "systematic review",
        "系统综述",
        "R18"
      ],
      "summary": "妊娠早期恶心呕吐的干预措施（考克兰系统评价数据库，系统评价，2015）—— 本图谱的一条文献出处。核验标识：DOI 10.1002/14651858.CD007575.pub4。",
      "attrs": [
        {
          "k": "文献类型",
          "v": "系统评价"
        },
        {
          "k": "作者",
          "v": "Matthews A, Haas DM, O'Mathúna DP, Dowswell T, Doyle M"
        },
        {
          "k": "期刊/出处",
          "v": "考克兰系统评价数据库"
        },
        {
          "k": "年份",
          "v": "2015"
        },
        {
          "k": "核验标识",
          "v": "DOI 10.1002/14651858.CD007575.pub4"
        },
        {
          "k": "证据等级",
          "v": "系统评价"
        },
        {
          "k": "证据类型",
          "v": "系统评价"
        }
      ],
      "evidence": [
        {
          "type": "系统评价",
          "author": "Matthews A, Haas DM, O'Mathúna DP, Dowswell T, Doyle M",
          "title": "妊娠早期恶心呕吐的干预措施",
          "journal": "考克兰系统评价数据库",
          "year": 2015,
          "grade": "系统评价",
          "locate": "DOI 10.1002/14651858.CD007575.pub4",
          "ref": "R18",
          "cite": "Matthews A, Haas DM, O'Mathúna DP, Dowswell T, Doyle M/妊娠早期恶心呕吐的干预措施/考克兰系统评价数据库/2015"
        }
      ]
    },
    {
      "id": "t02-ref-19",
      "name": "内关穴（PC6）按压对恶性肿瘤患者化疗所致急性与延迟性恶心呕吐的影响：荟萃分析",
      "type": "Reference",
      "graph": "topic-02",
      "tags": [
        "文献",
        "出处",
        "Meta分析"
      ],
      "aliases": [
        "Meta分析",
        "meta analysis",
        "meta-analysis",
        "meta analyses",
        "荟萃分析",
        "R19"
      ],
      "summary": "内关穴（PC6）按压对恶性肿瘤患者化疗所致急性与延迟性恶心呕吐的影响：荟萃分析（癌症支持治疗，Meta分析，2023）—— 本图谱的一条文献出处。核验标识：PMID 37548707 · DOI 10.1007/s00520-023-07976-0。",
      "attrs": [
        {
          "k": "文献类型",
          "v": "Meta分析"
        },
        {
          "k": "作者",
          "v": "Xiao C, Qin M, Xia H, Xing Q, Wang D, Qian W"
        },
        {
          "k": "期刊/出处",
          "v": "癌症支持治疗"
        },
        {
          "k": "年份",
          "v": "2023"
        },
        {
          "k": "核验标识",
          "v": "PMID 37548707 · DOI 10.1007/s00520-023-07976-0"
        },
        {
          "k": "证据等级",
          "v": "Meta分析"
        },
        {
          "k": "证据类型",
          "v": "Meta分析"
        }
      ],
      "evidence": [
        {
          "type": "Meta分析",
          "author": "Xiao C, Qin M, Xia H, Xing Q, Wang D, Qian W",
          "title": "内关穴（PC6）按压对恶性肿瘤患者化疗所致急性与延迟性恶心呕吐的影响：荟萃分析",
          "journal": "癌症支持治疗",
          "year": 2023,
          "grade": "Meta分析",
          "locate": "PMID 37548707 · DOI 10.1007/s00520-023-07976-0",
          "ref": "R19",
          "cite": "Xiao C, Qin M, Xia H, Xing Q, Wang D, Qian W/内关穴（PC6）按压对恶性肿瘤患者化疗所致急性与延迟性恶心呕吐的影响：荟萃分析/癌症支持治疗/2023"
        }
      ]
    },
    {
      "id": "t02-ref-20",
      "name": "吸入薄荷精油作为恶心呕吐治疗的辅助疗法：一项有前景的补充治疗",
      "type": "Reference",
      "graph": "topic-02",
      "tags": [
        "文献",
        "出处",
        "Meta分析"
      ],
      "aliases": [
        "Meta分析",
        "meta analysis",
        "meta-analysis",
        "meta analyses",
        "荟萃分析",
        "R20"
      ],
      "summary": "吸入薄荷精油作为恶心呕吐治疗的辅助疗法：一项有前景的补充治疗（临床医学杂志，Meta分析，2025）—— 本图谱的一条文献出处。核验标识：PMID 40725767 · DOI 10.3390/jcm14145069。",
      "attrs": [
        {
          "k": "文献类型",
          "v": "Meta分析"
        },
        {
          "k": "作者",
          "v": "Gergő D, Garmaa G, Tóth-Mészáros A, et al."
        },
        {
          "k": "期刊/出处",
          "v": "临床医学杂志"
        },
        {
          "k": "年份",
          "v": "2025"
        },
        {
          "k": "核验标识",
          "v": "PMID 40725767 · DOI 10.3390/jcm14145069"
        },
        {
          "k": "证据等级",
          "v": "Meta分析"
        },
        {
          "k": "证据类型",
          "v": "Meta分析"
        }
      ],
      "evidence": [
        {
          "type": "Meta分析",
          "author": "Gergő D, Garmaa G, Tóth-Mészáros A, et al.",
          "title": "吸入薄荷精油作为恶心呕吐治疗的辅助疗法：一项有前景的补充治疗",
          "journal": "临床医学杂志",
          "year": 2025,
          "grade": "Meta分析",
          "locate": "PMID 40725767 · DOI 10.3390/jcm14145069",
          "ref": "R20",
          "cite": "Gergő D, Garmaa G, Tóth-Mészáros A, et al./吸入薄荷精油作为恶心呕吐治疗的辅助疗法：一项有前景的补充治疗/临床医学杂志/2025"
        }
      ]
    },
    {
      "id": "t02-ref-21",
      "name": "非药物干预对癌症化疗致恶心呕吐影响的网状Meta分析",
      "type": "Reference",
      "graph": "topic-02",
      "tags": [
        "文献",
        "出处",
        "Meta分析"
      ],
      "aliases": [
        "Meta分析",
        "meta analysis",
        "meta-analysis",
        "meta analyses",
        "荟萃分析",
        "R21"
      ],
      "summary": "非药物干预对癌症化疗致恶心呕吐影响的网状Meta分析（循证护理，Meta分析，2024）—— 本图谱的一条文献出处。核验标识：DOI 10.12102/j.issn.2095-8668.2024.10.001。",
      "attrs": [
        {
          "k": "文献类型",
          "v": "Meta分析"
        },
        {
          "k": "作者",
          "v": "张英英, 乔欣, 赵丽丽, 汤媛媛, 刘芳"
        },
        {
          "k": "期刊/出处",
          "v": "循证护理"
        },
        {
          "k": "年份",
          "v": "2024"
        },
        {
          "k": "核验标识",
          "v": "DOI 10.12102/j.issn.2095-8668.2024.10.001"
        },
        {
          "k": "证据等级",
          "v": "Meta分析（网状）"
        },
        {
          "k": "证据类型",
          "v": "Meta分析"
        }
      ],
      "evidence": [
        {
          "type": "Meta分析",
          "author": "张英英, 乔欣, 赵丽丽, 汤媛媛, 刘芳",
          "title": "非药物干预对癌症化疗致恶心呕吐影响的网状Meta分析",
          "journal": "循证护理",
          "year": 2024,
          "grade": "Meta分析（网状）",
          "locate": "DOI 10.12102/j.issn.2095-8668.2024.10.001",
          "ref": "R21",
          "cite": "张英英, 乔欣, 赵丽丽, 汤媛媛, 刘芳/非药物干预对癌症化疗致恶心呕吐影响的网状Meta分析/循证护理/2024"
        }
      ]
    }
  ],
  "edges": [
    {
      "source": "t02-cat-cinv",
      "target": "t02-exp-nausea",
      "type": "EXPERIENCED_AS",
      "label": "表现为"
    },
    {
      "source": "t02-cat-cinv",
      "target": "t02-exp-vomiting",
      "type": "EXPERIENCED_AS",
      "label": "表现为"
    },
    {
      "source": "t02-cat-rinv",
      "target": "t02-exp-nausea",
      "type": "EXPERIENCED_AS",
      "label": "表现为"
    },
    {
      "source": "t02-cat-rinv",
      "target": "t02-exp-vomiting",
      "type": "EXPERIENCED_AS",
      "label": "表现为"
    },
    {
      "source": "t02-cat-nvp",
      "target": "t02-exp-nausea",
      "type": "EXPERIENCED_AS",
      "label": "表现为"
    },
    {
      "source": "t02-cat-nvp",
      "target": "t02-exp-vomiting",
      "type": "EXPERIENCED_AS",
      "label": "表现为"
    },
    {
      "source": "t02-cat-hg",
      "target": "t02-exp-nausea",
      "type": "EXPERIENCED_AS",
      "label": "表现为"
    },
    {
      "source": "t02-cat-hg",
      "target": "t02-exp-vomiting",
      "type": "EXPERIENCED_AS",
      "label": "表现为"
    },
    {
      "source": "t02-cat-ponv",
      "target": "t02-exp-nausea",
      "type": "EXPERIENCED_AS",
      "label": "表现为"
    },
    {
      "source": "t02-cat-ponv",
      "target": "t02-exp-vomiting",
      "type": "EXPERIENCED_AS",
      "label": "表现为"
    },
    {
      "source": "t02-cat-acute",
      "target": "t02-exp-nausea",
      "type": "EXPERIENCED_AS",
      "label": "表现为"
    },
    {
      "source": "t02-cat-acute",
      "target": "t02-exp-vomiting",
      "type": "EXPERIENCED_AS",
      "label": "表现为"
    },
    {
      "source": "t02-cat-delayed",
      "target": "t02-exp-nausea",
      "type": "EXPERIENCED_AS",
      "label": "表现为"
    },
    {
      "source": "t02-cat-delayed",
      "target": "t02-exp-vomiting",
      "type": "EXPERIENCED_AS",
      "label": "表现为"
    },
    {
      "source": "t02-cat-anticipatory",
      "target": "t02-exp-nausea",
      "type": "EXPERIENCED_AS",
      "label": "表现为"
    },
    {
      "source": "t02-cat-anticipatory",
      "target": "t02-exp-vomiting",
      "type": "EXPERIENCED_AS",
      "label": "表现为"
    },
    {
      "source": "t02-cat-breakthrough",
      "target": "t02-exp-nausea",
      "type": "EXPERIENCED_AS",
      "label": "表现为"
    },
    {
      "source": "t02-cat-breakthrough",
      "target": "t02-exp-vomiting",
      "type": "EXPERIENCED_AS",
      "label": "表现为"
    },
    {
      "source": "t02-cat-hg",
      "target": "t02-cat-nvp",
      "type": "BELONGS_TO",
      "label": "属于"
    },
    {
      "source": "t02-cat-acute",
      "target": "t02-cat-cinv",
      "type": "BELONGS_TO",
      "label": "属于"
    },
    {
      "source": "t02-cat-delayed",
      "target": "t02-cat-cinv",
      "type": "BELONGS_TO",
      "label": "属于"
    },
    {
      "source": "t02-cat-anticipatory",
      "target": "t02-cat-cinv",
      "type": "BELONGS_TO",
      "label": "属于"
    },
    {
      "source": "t02-cat-breakthrough",
      "target": "t02-cat-cinv",
      "type": "BELONGS_TO",
      "label": "属于"
    },
    {
      "source": "t02-status-cinv-incidence",
      "target": "t02-cat-cinv",
      "type": "BELONGS_TO",
      "label": "属于"
    },
    {
      "source": "t02-status-ponv-incidence",
      "target": "t02-cat-ponv",
      "type": "BELONGS_TO",
      "label": "属于"
    },
    {
      "source": "t02-status-nvp-incidence",
      "target": "t02-cat-nvp",
      "type": "BELONGS_TO",
      "label": "属于"
    },
    {
      "source": "t02-status-hg-incidence",
      "target": "t02-cat-hg",
      "type": "BELONGS_TO",
      "label": "属于"
    },
    {
      "source": "t02-status-anticipatory-incidence",
      "target": "t02-cat-anticipatory",
      "type": "BELONGS_TO",
      "label": "属于"
    },
    {
      "source": "t02-exp-nausea",
      "target": "t02-tool-ctca",
      "type": "ASSESSED_BY",
      "label": "由……评估"
    },
    {
      "source": "t02-exp-nausea",
      "target": "t02-tool-mascc-mat",
      "type": "ASSESSED_BY",
      "label": "由……评估"
    },
    {
      "source": "t02-exp-nausea",
      "target": "t02-tool-eortc-qlq-c30",
      "type": "ASSESSED_BY",
      "label": "由……评估"
    },
    {
      "source": "t02-exp-vomiting",
      "target": "t02-tool-ctca",
      "type": "ASSESSED_BY",
      "label": "由……评估"
    },
    {
      "source": "t02-exp-vomiting",
      "target": "t02-tool-mascc-mat",
      "type": "ASSESSED_BY",
      "label": "由……评估"
    },
    {
      "source": "t02-exp-vomiting",
      "target": "t02-tool-eortc-qlq-c30",
      "type": "ASSESSED_BY",
      "label": "由……评估"
    },
    {
      "source": "t02-cat-cinv",
      "target": "t02-tool-mascc-mat",
      "type": "ASSESSED_BY",
      "label": "由……评估"
    },
    {
      "source": "t02-cat-cinv",
      "target": "t02-tool-ctca",
      "type": "ASSESSED_BY",
      "label": "由……评估"
    },
    {
      "source": "t02-cat-nvp",
      "target": "t02-tool-puqe",
      "type": "ASSESSED_BY",
      "label": "由……评估"
    },
    {
      "source": "t02-cat-hg",
      "target": "t02-tool-puqe",
      "type": "ASSESSED_BY",
      "label": "由……评估"
    },
    {
      "source": "t02-cat-ponv",
      "target": "t02-tool-apfel",
      "type": "ASSESSED_BY",
      "label": "由……评估"
    },
    {
      "source": "t02-cat-anticipatory",
      "target": "t02-tool-mascc-mat",
      "type": "ASSESSED_BY",
      "label": "由……评估"
    },
    {
      "source": "t02-exp-nausea",
      "target": "t02-risk-female",
      "type": "AT_RISK_BY",
      "label": "风险来自"
    },
    {
      "source": "t02-exp-nausea",
      "target": "t02-risk-young-age",
      "type": "AT_RISK_BY",
      "label": "风险来自"
    },
    {
      "source": "t02-exp-nausea",
      "target": "t02-risk-anxiety",
      "type": "AT_RISK_BY",
      "label": "风险来自"
    },
    {
      "source": "t02-exp-nausea",
      "target": "t02-risk-prior-nv",
      "type": "AT_RISK_BY",
      "label": "风险来自"
    },
    {
      "source": "t02-exp-nausea",
      "target": "t02-risk-sleep-disturbance",
      "type": "AT_RISK_BY",
      "label": "风险来自"
    },
    {
      "source": "t02-exp-vomiting",
      "target": "t02-risk-female",
      "type": "AT_RISK_BY",
      "label": "风险来自"
    },
    {
      "source": "t02-exp-vomiting",
      "target": "t02-risk-non-smoker",
      "type": "AT_RISK_BY",
      "label": "风险来自"
    },
    {
      "source": "t02-exp-vomiting",
      "target": "t02-risk-motion-sickness",
      "type": "AT_RISK_BY",
      "label": "风险来自"
    },
    {
      "source": "t02-exp-vomiting",
      "target": "t02-risk-opioid",
      "type": "AT_RISK_BY",
      "label": "风险来自"
    },
    {
      "source": "t02-exp-vomiting",
      "target": "t02-risk-prior-nv",
      "type": "AT_RISK_BY",
      "label": "风险来自"
    },
    {
      "source": "t02-exp-vomiting",
      "target": "t02-risk-low-alcohol",
      "type": "AT_RISK_BY",
      "label": "风险来自"
    },
    {
      "source": "t02-cat-cinv",
      "target": "t02-risk-female",
      "type": "AT_RISK_BY",
      "label": "风险来自"
    },
    {
      "source": "t02-cat-cinv",
      "target": "t02-risk-young-age",
      "type": "AT_RISK_BY",
      "label": "风险来自"
    },
    {
      "source": "t02-cat-cinv",
      "target": "t02-risk-prior-nv",
      "type": "AT_RISK_BY",
      "label": "风险来自"
    },
    {
      "source": "t02-cat-cinv",
      "target": "t02-risk-anxiety",
      "type": "AT_RISK_BY",
      "label": "风险来自"
    },
    {
      "source": "t02-cat-cinv",
      "target": "t02-risk-no-prior-meal",
      "type": "AT_RISK_BY",
      "label": "风险来自"
    },
    {
      "source": "t02-cat-rinv",
      "target": "t02-risk-female",
      "type": "AT_RISK_BY",
      "label": "风险来自"
    },
    {
      "source": "t02-cat-rinv",
      "target": "t02-risk-prior-nv",
      "type": "AT_RISK_BY",
      "label": "风险来自"
    },
    {
      "source": "t02-cat-nvp",
      "target": "t02-risk-prior-nv",
      "type": "AT_RISK_BY",
      "label": "风险来自"
    },
    {
      "source": "t02-cat-hg",
      "target": "t02-risk-prior-nv",
      "type": "AT_RISK_BY",
      "label": "风险来自"
    },
    {
      "source": "t02-cat-hg",
      "target": "t02-risk-anxiety",
      "type": "AT_RISK_BY",
      "label": "风险来自"
    },
    {
      "source": "t02-cat-ponv",
      "target": "t02-risk-female",
      "type": "AT_RISK_BY",
      "label": "风险来自"
    },
    {
      "source": "t02-cat-ponv",
      "target": "t02-risk-non-smoker",
      "type": "AT_RISK_BY",
      "label": "风险来自"
    },
    {
      "source": "t02-cat-ponv",
      "target": "t02-risk-motion-sickness",
      "type": "AT_RISK_BY",
      "label": "风险来自"
    },
    {
      "source": "t02-cat-ponv",
      "target": "t02-risk-opioid",
      "type": "AT_RISK_BY",
      "label": "风险来自"
    },
    {
      "source": "t02-cat-ponv",
      "target": "t02-risk-low-alcohol",
      "type": "AT_RISK_BY",
      "label": "风险来自"
    },
    {
      "source": "t02-cat-anticipatory",
      "target": "t02-risk-anxiety",
      "type": "AT_RISK_BY",
      "label": "风险来自"
    },
    {
      "source": "t02-cat-anticipatory",
      "target": "t02-risk-prior-nv",
      "type": "AT_RISK_BY",
      "label": "风险来自"
    },
    {
      "source": "t02-exp-nausea",
      "target": "t02-pharm-5ht3-ra",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-exp-nausea",
      "target": "t02-pharm-dexamethasone",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-exp-nausea",
      "target": "t02-pharm-nk1-ra",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-exp-nausea",
      "target": "t02-pharm-olanzapine",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-exp-nausea",
      "target": "t02-pharm-metoclopramide",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-exp-nausea",
      "target": "t02-pharm-antihistamine",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-exp-nausea",
      "target": "t02-pharm-vitamin-b6",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-exp-nausea",
      "target": "t02-nonpharm-lifestyle",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-exp-nausea",
      "target": "t02-nonpharm-aromatherapy",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-exp-nausea",
      "target": "t02-nonpharm-ginger",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-exp-nausea",
      "target": "t02-nonpharm-oral-care",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-exp-nausea",
      "target": "t02-nonpharm-fluid",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-exp-nausea",
      "target": "t02-nonpharm-health-education",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-exp-vomiting",
      "target": "t02-pharm-5ht3-ra",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-exp-vomiting",
      "target": "t02-pharm-dexamethasone",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-exp-vomiting",
      "target": "t02-pharm-nk1-ra",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-exp-vomiting",
      "target": "t02-pharm-olanzapine",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-exp-vomiting",
      "target": "t02-pharm-metoclopramide",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-exp-vomiting",
      "target": "t02-pharm-dopamine-antagonist",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-exp-vomiting",
      "target": "t02-pharm-enteral-nutrition",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-exp-vomiting",
      "target": "t02-nonpharm-lifestyle",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-exp-vomiting",
      "target": "t02-nonpharm-acupoint",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-exp-vomiting",
      "target": "t02-nonpharm-aromatherapy",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-exp-vomiting",
      "target": "t02-nonpharm-oral-care",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-exp-vomiting",
      "target": "t02-nonpharm-fluid",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-exp-vomiting",
      "target": "t02-nonpharm-health-education",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-cat-cinv",
      "target": "t02-pharm-5ht3-ra",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-cat-cinv",
      "target": "t02-pharm-dexamethasone",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-cat-cinv",
      "target": "t02-pharm-nk1-ra",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-cat-cinv",
      "target": "t02-pharm-olanzapine",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-cat-cinv",
      "target": "t02-nonpharm-acupoint",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-cat-cinv",
      "target": "t02-nonpharm-aromatherapy",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-cat-cinv",
      "target": "t02-nonpharm-health-education",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-cat-cinv",
      "target": "t02-nonpharm-lifestyle",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-cat-rinv",
      "target": "t02-pharm-5ht3-ra",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-cat-rinv",
      "target": "t02-pharm-dexamethasone",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-cat-rinv",
      "target": "t02-pharm-antihistamine",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-cat-rinv",
      "target": "t02-nonpharm-lifestyle",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-cat-nvp",
      "target": "t02-pharm-vitamin-b6",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-cat-nvp",
      "target": "t02-pharm-antihistamine",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-cat-nvp",
      "target": "t02-pharm-metoclopramide",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-cat-nvp",
      "target": "t02-nonpharm-ginger",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-cat-nvp",
      "target": "t02-nonpharm-health-education",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-cat-nvp",
      "target": "t02-nonpharm-lifestyle",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-cat-nvp",
      "target": "t02-nonpharm-fluid",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-cat-hg",
      "target": "t02-pharm-thiamine",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-cat-hg",
      "target": "t02-pharm-metoclopramide",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-cat-hg",
      "target": "t02-nonpharm-fluid",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-cat-hg",
      "target": "t02-nonpharm-health-education",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-cat-ponv",
      "target": "t02-pharm-5ht3-ra",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-cat-ponv",
      "target": "t02-pharm-dexamethasone",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-cat-ponv",
      "target": "t02-pharm-nk1-ra",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-cat-ponv",
      "target": "t02-pharm-metoclopramide",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-cat-ponv",
      "target": "t02-nonpharm-acupoint",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-cat-ponv",
      "target": "t02-nonpharm-aromatherapy",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-cat-ponv",
      "target": "t02-nonpharm-lifestyle",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-cat-anticipatory",
      "target": "t02-nonpharm-behavioral",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-cat-anticipatory",
      "target": "t02-nonpharm-acupoint",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-cat-anticipatory",
      "target": "t02-nonpharm-health-education",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-cat-breakthrough",
      "target": "t02-pharm-dopamine-antagonist",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-cat-breakthrough",
      "target": "t02-pharm-5ht3-ra",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-cat-breakthrough",
      "target": "t02-pharm-metoclopramide",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-cat-breakthrough",
      "target": "t02-nonpharm-health-education",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-cat-acute",
      "target": "t02-pharm-5ht3-ra",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-cat-acute",
      "target": "t02-pharm-dexamethasone",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-cat-delayed",
      "target": "t02-pharm-5ht3-ra",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-cat-delayed",
      "target": "t02-pharm-nk1-ra",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-cat-delayed",
      "target": "t02-pharm-olanzapine",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "t02-cat-cinv",
      "target": "t02-strategy-cinv",
      "type": "MANAGED_BY",
      "label": "由……处置"
    },
    {
      "source": "t02-cat-rinv",
      "target": "t02-strategy-cinv",
      "type": "MANAGED_BY",
      "label": "由……处置"
    },
    {
      "source": "t02-cat-nvp",
      "target": "t02-strategy-nvp",
      "type": "MANAGED_BY",
      "label": "由……处置"
    },
    {
      "source": "t02-cat-hg",
      "target": "t02-strategy-nvp",
      "type": "MANAGED_BY",
      "label": "由……处置"
    },
    {
      "source": "t02-cat-ponv",
      "target": "t02-strategy-ponv",
      "type": "MANAGED_BY",
      "label": "由……处置"
    },
    {
      "source": "t02-cat-anticipatory",
      "target": "t02-strategy-integrated",
      "type": "MANAGED_BY",
      "label": "由……处置"
    },
    {
      "source": "t02-cat-breakthrough",
      "target": "t02-strategy-integrated",
      "type": "MANAGED_BY",
      "label": "由……处置"
    },
    {
      "source": "t02-cat-acute",
      "target": "t02-strategy-cinv",
      "type": "MANAGED_BY",
      "label": "由……处置"
    },
    {
      "source": "t02-cat-delayed",
      "target": "t02-strategy-cinv",
      "type": "MANAGED_BY",
      "label": "由……处置"
    },
    {
      "source": "t02-exp-nausea",
      "target": "t02-strategy-integrated",
      "type": "MANAGED_BY",
      "label": "由……处置"
    },
    {
      "source": "t02-exp-vomiting",
      "target": "t02-strategy-integrated",
      "type": "MANAGED_BY",
      "label": "由……处置"
    },
    {
      "source": "t02-strategy-cinv",
      "target": "t02-outcome-incidence",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-strategy-cinv",
      "target": "t02-outcome-complete-response",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-strategy-cinv",
      "target": "t02-outcome-severity",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-strategy-cinv",
      "target": "t02-outcome-eating",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-strategy-cinv",
      "target": "t02-outcome-qol",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-strategy-cinv",
      "target": "t02-outcome-adherence",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-strategy-nvp",
      "target": "t02-outcome-severity",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-strategy-nvp",
      "target": "t02-outcome-eating",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-strategy-nvp",
      "target": "t02-outcome-weight",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-strategy-nvp",
      "target": "t02-outcome-hospitalization",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-strategy-nvp",
      "target": "t02-outcome-adherence",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-strategy-ponv",
      "target": "t02-outcome-incidence",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-strategy-ponv",
      "target": "t02-outcome-severity",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-strategy-ponv",
      "target": "t02-outcome-qol",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-strategy-ponv",
      "target": "t02-outcome-hospitalization",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-strategy-integrated",
      "target": "t02-outcome-incidence",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-strategy-integrated",
      "target": "t02-outcome-complete-response",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-strategy-integrated",
      "target": "t02-outcome-eating",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-strategy-integrated",
      "target": "t02-outcome-qol",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-strategy-integrated",
      "target": "t02-outcome-adherence",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-strategy-integrated",
      "target": "t02-outcome-hospitalization",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-strategy-cinv",
      "target": "t02-status-cinv-incidence",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-strategy-cinv",
      "target": "t02-status-control-rate",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-strategy-nvp",
      "target": "t02-status-nvp-incidence",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-strategy-nvp",
      "target": "t02-status-hg-incidence",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-strategy-ponv",
      "target": "t02-status-ponv-incidence",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-strategy-integrated",
      "target": "t02-status-cinv-incidence",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-strategy-integrated",
      "target": "t02-status-control-rate",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-strategy-integrated",
      "target": "t02-status-anticipatory-incidence",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-strategy-cinv",
      "target": "t02-func-eating",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-strategy-cinv",
      "target": "t02-func-weight",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-strategy-cinv",
      "target": "t02-func-qol",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-strategy-cinv",
      "target": "t02-func-activity",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-strategy-nvp",
      "target": "t02-func-eating",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-strategy-nvp",
      "target": "t02-func-weight",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-strategy-nvp",
      "target": "t02-func-activity",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-strategy-ponv",
      "target": "t02-func-qol",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-strategy-ponv",
      "target": "t02-func-activity",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-strategy-integrated",
      "target": "t02-func-eating",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-strategy-integrated",
      "target": "t02-func-weight",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-strategy-integrated",
      "target": "t02-func-qol",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-strategy-integrated",
      "target": "t02-func-self-care",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-strategy-integrated",
      "target": "t02-func-activity",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-strategy-cinv",
      "target": "t02-status-dehydration",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-strategy-cinv",
      "target": "t02-status-electrolyte",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-strategy-cinv",
      "target": "t02-status-retching",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-strategy-nvp",
      "target": "t02-status-dehydration",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-strategy-nvp",
      "target": "t02-status-electrolyte",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-strategy-nvp",
      "target": "t02-status-retching",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-strategy-ponv",
      "target": "t02-func-aspiration-risk",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-strategy-ponv",
      "target": "t02-status-retching",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-strategy-integrated",
      "target": "t02-status-dehydration",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-strategy-integrated",
      "target": "t02-status-electrolyte",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-strategy-integrated",
      "target": "t02-status-retching",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-strategy-integrated",
      "target": "t02-func-aspiration-risk",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-nonpharm-lifestyle",
      "target": "t02-outcome-severity",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-nonpharm-lifestyle",
      "target": "t02-outcome-eating",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-nonpharm-acupoint",
      "target": "t02-outcome-severity",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-nonpharm-acupoint",
      "target": "t02-outcome-incidence",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-nonpharm-fluid",
      "target": "t02-outcome-eating",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-nonpharm-fluid",
      "target": "t02-outcome-hospitalization",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-nonpharm-aromatherapy",
      "target": "t02-outcome-severity",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-nonpharm-ginger",
      "target": "t02-outcome-severity",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-nonpharm-ginger",
      "target": "t02-outcome-eating",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-nonpharm-health-education",
      "target": "t02-outcome-adherence",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-nonpharm-health-education",
      "target": "t02-outcome-eating",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-nonpharm-health-education",
      "target": "t02-outcome-severity",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-nonpharm-oral-care",
      "target": "t02-outcome-eating",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-nonpharm-oral-care",
      "target": "t02-outcome-severity",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-nonpharm-behavioral",
      "target": "t02-outcome-severity",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-nonpharm-behavioral",
      "target": "t02-outcome-qol",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-pharm-5ht3-ra",
      "target": "t02-outcome-incidence",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-pharm-5ht3-ra",
      "target": "t02-outcome-complete-response",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-pharm-dexamethasone",
      "target": "t02-outcome-incidence",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-pharm-nk1-ra",
      "target": "t02-outcome-incidence",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-pharm-olanzapine",
      "target": "t02-outcome-severity",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-pharm-metoclopramide",
      "target": "t02-outcome-severity",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-pharm-dopamine-antagonist",
      "target": "t02-outcome-severity",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-pharm-antihistamine",
      "target": "t02-outcome-severity",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-pharm-vitamin-b6",
      "target": "t02-outcome-severity",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-pharm-enteral-nutrition",
      "target": "t02-outcome-eating",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-pharm-enteral-nutrition",
      "target": "t02-outcome-weight",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-pharm-thiamine",
      "target": "t02-outcome-hospitalization",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "t02-exp-nausea",
      "target": "t02-ref-16",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-exp-nausea",
      "target": "t02-ref-13",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-exp-nausea",
      "target": "t02-ref-02",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-exp-vomiting",
      "target": "t02-ref-16",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-exp-vomiting",
      "target": "t02-ref-13",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-exp-vomiting",
      "target": "t02-ref-18",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-cat-cinv",
      "target": "t02-ref-01",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-cat-cinv",
      "target": "t02-ref-02",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-cat-cinv",
      "target": "t02-ref-12",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-cat-cinv",
      "target": "t02-ref-06",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-cat-cinv",
      "target": "t02-ref-03",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-cat-rinv",
      "target": "t02-ref-02",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-cat-rinv",
      "target": "t02-ref-01",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-cat-nvp",
      "target": "t02-ref-04",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-cat-nvp",
      "target": "t02-ref-18",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-cat-nvp",
      "target": "t02-ref-11",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-cat-hg",
      "target": "t02-ref-04",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-cat-hg",
      "target": "t02-ref-18",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-cat-hg",
      "target": "t02-ref-16",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-cat-ponv",
      "target": "t02-ref-05",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-cat-ponv",
      "target": "t02-ref-01",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-cat-acute",
      "target": "t02-ref-02",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-cat-acute",
      "target": "t02-ref-12",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-cat-acute",
      "target": "t02-ref-06",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-cat-delayed",
      "target": "t02-ref-02",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-cat-delayed",
      "target": "t02-ref-12",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-cat-delayed",
      "target": "t02-ref-06",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-cat-anticipatory",
      "target": "t02-ref-06",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-cat-anticipatory",
      "target": "t02-ref-07",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-cat-anticipatory",
      "target": "t02-ref-02",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-cat-breakthrough",
      "target": "t02-ref-02",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-cat-breakthrough",
      "target": "t02-ref-12",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-cat-breakthrough",
      "target": "t02-ref-01",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-tool-ctca",
      "target": "t02-ref-08",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-tool-eortc-qlq-c30",
      "target": "t02-ref-09",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-tool-eortc-qlq-c30",
      "target": "t02-ref-16",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-tool-mascc-mat",
      "target": "t02-ref-10",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-tool-mascc-mat",
      "target": "t02-ref-16",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-tool-apfel",
      "target": "t02-ref-05",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-tool-apfel",
      "target": "t02-ref-01",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-tool-puqe",
      "target": "t02-ref-04",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-tool-puqe",
      "target": "t02-ref-18",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-risk-female",
      "target": "t02-ref-01",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-risk-female",
      "target": "t02-ref-02",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-risk-female",
      "target": "t02-ref-05",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-risk-young-age",
      "target": "t02-ref-07",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-risk-young-age",
      "target": "t02-ref-02",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-risk-young-age",
      "target": "t02-ref-06",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-risk-non-smoker",
      "target": "t02-ref-05",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-risk-non-smoker",
      "target": "t02-ref-01",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-risk-motion-sickness",
      "target": "t02-ref-05",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-risk-motion-sickness",
      "target": "t02-ref-01",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-risk-prior-nv",
      "target": "t02-ref-02",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-risk-prior-nv",
      "target": "t02-ref-05",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-risk-prior-nv",
      "target": "t02-ref-06",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-risk-anxiety",
      "target": "t02-ref-07",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-risk-anxiety",
      "target": "t02-ref-06",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-risk-anxiety",
      "target": "t02-ref-13",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-risk-opioid",
      "target": "t02-ref-05",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-risk-opioid",
      "target": "t02-ref-01",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-risk-sleep-disturbance",
      "target": "t02-ref-07",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-risk-sleep-disturbance",
      "target": "t02-ref-13",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-risk-low-alcohol",
      "target": "t02-ref-07",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-risk-low-alcohol",
      "target": "t02-ref-05",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-risk-no-prior-meal",
      "target": "t02-ref-07",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-risk-no-prior-meal",
      "target": "t02-ref-06",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-pharm-5ht3-ra",
      "target": "t02-ref-01",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-pharm-5ht3-ra",
      "target": "t02-ref-02",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-pharm-5ht3-ra",
      "target": "t02-ref-12",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-pharm-dexamethasone",
      "target": "t02-ref-01",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-pharm-dexamethasone",
      "target": "t02-ref-02",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-pharm-dexamethasone",
      "target": "t02-ref-06",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-pharm-nk1-ra",
      "target": "t02-ref-01",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-pharm-nk1-ra",
      "target": "t02-ref-02",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-pharm-nk1-ra",
      "target": "t02-ref-12",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-pharm-nk1-ra",
      "target": "t02-ref-06",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-pharm-olanzapine",
      "target": "t02-ref-01",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-pharm-olanzapine",
      "target": "t02-ref-02",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-pharm-olanzapine",
      "target": "t02-ref-12",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-pharm-metoclopramide",
      "target": "t02-ref-04",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-pharm-metoclopramide",
      "target": "t02-ref-02",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-pharm-metoclopramide",
      "target": "t02-ref-06",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-pharm-dopamine-antagonist",
      "target": "t02-ref-01",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-pharm-dopamine-antagonist",
      "target": "t02-ref-02",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-pharm-dopamine-antagonist",
      "target": "t02-ref-06",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-pharm-antihistamine",
      "target": "t02-ref-04",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-pharm-antihistamine",
      "target": "t02-ref-11",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-pharm-antihistamine",
      "target": "t02-ref-18",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-pharm-vitamin-b6",
      "target": "t02-ref-11",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-pharm-vitamin-b6",
      "target": "t02-ref-04",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-pharm-vitamin-b6",
      "target": "t02-ref-18",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-pharm-enteral-nutrition",
      "target": "t02-ref-14",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-pharm-enteral-nutrition",
      "target": "t02-ref-15",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-pharm-enteral-nutrition",
      "target": "t02-ref-16",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-pharm-thiamine",
      "target": "t02-ref-04",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-nonpharm-lifestyle",
      "target": "t02-ref-07",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-nonpharm-lifestyle",
      "target": "t02-ref-15",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-nonpharm-lifestyle",
      "target": "t02-ref-05",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-nonpharm-acupoint",
      "target": "t02-ref-19",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-nonpharm-acupoint",
      "target": "t02-ref-21",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-nonpharm-acupoint",
      "target": "t02-ref-11",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-nonpharm-acupoint",
      "target": "t02-ref-17",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-nonpharm-fluid",
      "target": "t02-ref-04",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-nonpharm-fluid",
      "target": "t02-ref-15",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-nonpharm-fluid",
      "target": "t02-ref-07",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-nonpharm-aromatherapy",
      "target": "t02-ref-20",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-nonpharm-aromatherapy",
      "target": "t02-ref-21",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-nonpharm-aromatherapy",
      "target": "t02-ref-17",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-nonpharm-ginger",
      "target": "t02-ref-11",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-nonpharm-ginger",
      "target": "t02-ref-18",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-nonpharm-ginger",
      "target": "t02-ref-21",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-nonpharm-health-education",
      "target": "t02-ref-07",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-nonpharm-health-education",
      "target": "t02-ref-13",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-nonpharm-health-education",
      "target": "t02-ref-17",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-nonpharm-oral-care",
      "target": "t02-ref-15",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-nonpharm-oral-care",
      "target": "t02-ref-07",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-nonpharm-oral-care",
      "target": "t02-ref-13",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-nonpharm-behavioral",
      "target": "t02-ref-17",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-nonpharm-behavioral",
      "target": "t02-ref-07",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-nonpharm-behavioral",
      "target": "t02-ref-06",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-strategy-cinv",
      "target": "t02-ref-01",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-strategy-cinv",
      "target": "t02-ref-02",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-strategy-cinv",
      "target": "t02-ref-12",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-strategy-cinv",
      "target": "t02-ref-06",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-strategy-cinv",
      "target": "t02-ref-07",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-strategy-cinv",
      "target": "t02-ref-03",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-strategy-nvp",
      "target": "t02-ref-04",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-strategy-nvp",
      "target": "t02-ref-11",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-strategy-nvp",
      "target": "t02-ref-18",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-strategy-ponv",
      "target": "t02-ref-05",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-strategy-ponv",
      "target": "t02-ref-01",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-strategy-ponv",
      "target": "t02-ref-17",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-strategy-integrated",
      "target": "t02-ref-16",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-strategy-integrated",
      "target": "t02-ref-13",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-strategy-integrated",
      "target": "t02-ref-17",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-outcome-incidence",
      "target": "t02-ref-01",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-outcome-incidence",
      "target": "t02-ref-02",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-outcome-incidence",
      "target": "t02-ref-12",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-outcome-complete-response",
      "target": "t02-ref-10",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-outcome-complete-response",
      "target": "t02-ref-01",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-outcome-complete-response",
      "target": "t02-ref-16",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-outcome-severity",
      "target": "t02-ref-20",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-outcome-severity",
      "target": "t02-ref-19",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-outcome-severity",
      "target": "t02-ref-21",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-outcome-eating",
      "target": "t02-ref-16",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-outcome-eating",
      "target": "t02-ref-04",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-outcome-eating",
      "target": "t02-ref-13",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-outcome-weight",
      "target": "t02-ref-04",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-outcome-weight",
      "target": "t02-ref-16",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-outcome-qol",
      "target": "t02-ref-09",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-outcome-qol",
      "target": "t02-ref-16",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-outcome-qol",
      "target": "t02-ref-13",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-outcome-adherence",
      "target": "t02-ref-07",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-outcome-adherence",
      "target": "t02-ref-13",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-outcome-adherence",
      "target": "t02-ref-17",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-outcome-hospitalization",
      "target": "t02-ref-16",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-outcome-hospitalization",
      "target": "t02-ref-07",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-outcome-hospitalization",
      "target": "t02-ref-13",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-status-cinv-incidence",
      "target": "t02-ref-01",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-status-cinv-incidence",
      "target": "t02-ref-02",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-status-cinv-incidence",
      "target": "t02-ref-07",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-status-ponv-incidence",
      "target": "t02-ref-05",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-status-ponv-incidence",
      "target": "t02-ref-01",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-status-nvp-incidence",
      "target": "t02-ref-04",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-status-nvp-incidence",
      "target": "t02-ref-18",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-status-hg-incidence",
      "target": "t02-ref-04",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-status-hg-incidence",
      "target": "t02-ref-18",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-status-anticipatory-incidence",
      "target": "t02-ref-06",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-status-anticipatory-incidence",
      "target": "t02-ref-07",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-status-control-rate",
      "target": "t02-ref-10",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-status-control-rate",
      "target": "t02-ref-01",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-status-dehydration",
      "target": "t02-ref-04",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-status-dehydration",
      "target": "t02-ref-15",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-status-electrolyte",
      "target": "t02-ref-04",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-status-electrolyte",
      "target": "t02-ref-16",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-status-retching",
      "target": "t02-ref-13",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-status-retching",
      "target": "t02-ref-15",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-func-eating",
      "target": "t02-ref-09",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-func-eating",
      "target": "t02-ref-16",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-func-eating",
      "target": "t02-ref-13",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-func-weight",
      "target": "t02-ref-04",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-func-weight",
      "target": "t02-ref-16",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-func-qol",
      "target": "t02-ref-09",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-func-qol",
      "target": "t02-ref-16",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-func-self-care",
      "target": "t02-ref-13",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-func-self-care",
      "target": "t02-ref-16",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-func-self-care",
      "target": "t02-ref-17",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-func-activity",
      "target": "t02-ref-05",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-func-activity",
      "target": "t02-ref-16",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-func-activity",
      "target": "t02-ref-17",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-func-aspiration-risk",
      "target": "t02-ref-05",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "t02-func-aspiration-risk",
      "target": "t02-ref-04",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    }
  ]
}
;

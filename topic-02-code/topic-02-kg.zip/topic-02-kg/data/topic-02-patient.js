window.KG_PATIENT = {
  "topicKey": "topic-02",
  "intro": "这是一份关于恶心呕吐的知识地图。先看下面「需要及时就医」的几条，再按分类逐层展开。",
  "disclaimer": "本页内容整理自公开文献，用于护理与健康科普，不能替代医生的诊断和治疗。身体不适请及时就医。",
  "urgentTitle": "出现这些情况，请及时就医",
  "urgent": [
    {
      "nodeId": "t02-cat-hg",
      "plain": "持续呕吐，吃不下也喝不下，体重下降超过 5%，出现脱水、电解质紊乱和酮症",
      "action": "尽快就医 —— 这类情况需要住院静脉补液和药物治疗"
    },
    {
      "nodeId": "t02-status-dehydration",
      "plain": "口渴、尿量减少、口唇干燥、皮肤弹性下降",
      "action": "尽快就医补液；重者可出现休克"
    },
    {
      "nodeId": "t02-status-electrolyte",
      "plain": "低钾、低钠、代谢性碱中毒，严重时引起心律失常与肌无力",
      "action": "尽快就医查电解质，按医嘱补液纠正"
    },
    {
      "nodeId": "t02-func-aspiration-risk",
      "plain": "呕吐伴意识障碍、饱腹或胃排空延迟时，呕吐物可能被吸入气道，引发吸入性肺炎甚至窒息",
      "action": "立刻叫医护人员；体位管理与口腔护理由医护处理"
    },
    {
      "nodeId": "t02-cat-breakthrough",
      "plain": "已经按预防方案用药，仍然发生恶心呕吐",
      "action": "尽快就医 —— 需要换用作用机制不同的药物并重新评估"
    }
  ]
};

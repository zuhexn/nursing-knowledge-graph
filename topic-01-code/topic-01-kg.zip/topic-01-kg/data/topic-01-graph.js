window.KG_GRAPH = {
  "meta": {
    "topicKey": "topic-01",
    "topicName": "CT增强扫描后过敏反应与外渗",
    "subtitle": "碘对比剂过敏反应 · 碘对比剂外渗 · 护理预防与处置",
    "generatedAt": "2026-11-04"
  },
  "nodeTypes": [
    {
      "key": "DiseaseCategory",
      "label": "疾病分类",
      "color": "#5B7C99",
      "shape": "round",
      "size": 22,
      "desc": "疾病大类"
    },
    {
      "key": "SymptomSign",
      "label": "症状体征",
      "color": "#C0563F",
      "shape": "diamond",
      "size": 18,
      "desc": "可观察到的体征"
    },
    {
      "key": "Exam",
      "label": "检查项目",
      "color": "#2F855A",
      "shape": "round",
      "size": 20,
      "desc": "检查 / 检验 / 用药"
    },
    {
      "key": "ManagementPrinciple",
      "label": "处置原则",
      "color": "#6B46C1",
      "shape": "round",
      "size": 18,
      "desc": "护理处置原则"
    },
    {
      "key": "NursingTheory",
      "label": "护理理论",
      "color": "#975A16",
      "shape": "triangle",
      "size": 20,
      "desc": "护理理论框架"
    },
    {
      "key": "DiseaseEducation",
      "label": "疾病教育",
      "color": "#2B6CB0",
      "shape": "round",
      "size": 18,
      "desc": "健康宣教内容"
    },
    {
      "key": "SymptomExperience",
      "label": "症状体验",
      "color": "#B83280",
      "shape": "diamond",
      "size": 18,
      "desc": "患者主观症状体验"
    },
    {
      "key": "ManagementStrategy",
      "label": "管理策略",
      "color": "#2C7A7B",
      "shape": "round",
      "size": 18,
      "desc": "症状管理策略"
    },
    {
      "key": "ManagementOutcome",
      "label": "管理效果",
      "color": "#38A169",
      "shape": "round",
      "size": 18,
      "desc": "症状管理结果"
    },
    {
      "key": "SymptomCategory",
      "label": "症状分类",
      "color": "#B7791F",
      "shape": "triangle",
      "size": 20,
      "desc": "症状大类"
    },
    {
      "key": "AssessmentTool",
      "label": "评估工具",
      "color": "#4A5568",
      "shape": "round",
      "size": 18,
      "desc": "评估量表 / 工具"
    },
    {
      "key": "RiskFactor",
      "label": "危险因素",
      "color": "#9B2C2C",
      "shape": "triangle",
      "size": 20,
      "desc": "风险因素"
    },
    {
      "key": "PharmacologicalManagement",
      "label": "药物治疗",
      "color": "#276749",
      "shape": "round",
      "size": 18,
      "desc": "用药处置"
    },
    {
      "key": "NonPharmacologicalManagement",
      "label": "非药物管理",
      "color": "#285E61",
      "shape": "round",
      "size": 18,
      "desc": "非药物处置"
    },
    {
      "key": "SymptomStatus",
      "label": "症状状态",
      "color": "#5A67D8",
      "shape": "round",
      "size": 16,
      "desc": "症状当前状态"
    },
    {
      "key": "FunctionalStatus",
      "label": "功能状态",
      "color": "#6B46C1",
      "shape": "round",
      "size": 16,
      "desc": "功能受影响程度"
    },
    {
      "key": "Reference",
      "label": "文献",
      "color": "#718096",
      "shape": "round",
      "size": 16,
      "desc": "文献出处节点"
    },
    {
      "key": "CaseReport",
      "label": "个案",
      "color": "#A0AEC0",
      "shape": "round",
      "size": 16,
      "desc": "个案（本期零节点）"
    }
  ],
  "relationTypes": [
    {
      "key": "BELONGS_TO",
      "label": "属于",
      "desc": "属于"
    },
    {
      "key": "HAS_SYMPTOM",
      "label": "存在症状",
      "desc": "存在症状"
    },
    {
      "key": "DETECTED_BY",
      "label": "通过检查发现",
      "desc": "通过检查发现"
    },
    {
      "key": "MANAGED_BY",
      "label": "由……处置",
      "desc": "由……处置"
    },
    {
      "key": "EDUCATED_BY",
      "label": "由……教育",
      "desc": "由……教育"
    },
    {
      "key": "EXPERIENCED_AS",
      "label": "表现为",
      "desc": "表现为"
    },
    {
      "key": "ASSESSED_BY",
      "label": "由……评估",
      "desc": "由……评估"
    },
    {
      "key": "AT_RISK_BY",
      "label": "风险来自",
      "desc": "风险来自"
    },
    {
      "key": "TREATED_BY",
      "label": "由……治疗",
      "desc": "由……治疗"
    },
    {
      "key": "EFFECT_ON",
      "label": "影响",
      "desc": "影响"
    },
    {
      "key": "PART_OF_CASE",
      "label": "属于个案",
      "desc": "属于个案"
    },
    {
      "key": "SUPPORTED_BY",
      "label": "有文献支持",
      "desc": "有文献支持"
    }
  ],
  "nodes": [
    {
      "id": "DC_CTEnhancedRisk",
      "name": "CT增强扫描后碘对比剂过敏反应与外渗",
      "type": "DiseaseCategory",
      "tags": [
        "题目",
        "CT增强",
        "碘对比剂"
      ],
      "aliases": [
        "CT增强检查护理风险",
        "CT增强扫描护理风险",
        "碘对比剂过敏反应",
        "碘对比剂外渗"
      ],
      "summary": "做 CT 增强扫描时使用碘对比剂后，最需要盯住的两类护理风险：碘对比剂过敏反应和碘对比剂外渗。",
      "attrs": [
        {
          "k": "覆盖范围",
          "v": "碘对比剂不良反应 · 静脉外渗 · 肾功能保护"
        }
      ],
      "evidence": [
        {
          "type": "指南",
          "author": "美国放射学会药物与对比剂委员会",
          "title": "美国放射学会对比剂手册",
          "journal": "美国放射学会",
          "year": 2024,
          "cite": "美国放射学会药物与对比剂委员会 / 美国放射学会对比剂手册 / 美国放射学会 / 2024",
          "grade": "指南与共识",
          "ref": "R01"
        },
        {
          "type": "指南",
          "author": "中华医学会放射学分会对比剂安全使用工作组",
          "title": "碘对比剂使用指南（第2版）",
          "journal": "中华放射学杂志",
          "year": 2013,
          "cite": "中华医学会放射学分会对比剂安全使用工作组 / 碘对比剂使用指南（第2版） / 中华放射学杂志 / 2013",
          "grade": "指南与共识",
          "ref": "R03"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "E_CTEnhancedScan",
      "name": "CT增强扫描",
      "type": "Exam",
      "tags": [
        "辅助检查"
      ],
      "aliases": [
        "CT enhanced scan",
        "增强CT",
        "CT增强"
      ],
      "summary": "先静脉注射碘对比剂、再做断层成像的检查方法；关注的是打药后出现的过敏反应和碘对比剂外渗。",
      "attrs": [],
      "evidence": [
        {
          "type": "指南",
          "author": "美国放射学会药物与对比剂委员会",
          "title": "美国放射学会对比剂手册",
          "journal": "美国放射学会",
          "year": 2024,
          "cite": "美国放射学会药物与对比剂委员会 / 美国放射学会对比剂手册 / 美国放射学会 / 2024",
          "grade": "指南与共识",
          "ref": "R01"
        },
        {
          "type": "指南",
          "author": "中华医学会放射学分会对比剂安全使用工作组",
          "title": "碘对比剂使用指南（第2版）",
          "journal": "中华放射学杂志",
          "year": 2013,
          "cite": "中华医学会放射学分会对比剂安全使用工作组 / 碘对比剂使用指南（第2版） / 中华放射学杂志 / 2013",
          "grade": "指南与共识",
          "ref": "R03"
        },
        {
          "type": "规范",
          "author": "广西壮族自治区市场监督管理局",
          "title": "DB45/T 2935—2024 CT增强扫描碘对比剂外渗预防与护理规范",
          "journal": "广西壮族自治区市场监督管理局（地方标准）",
          "year": 2024,
          "cite": "广西壮族自治区市场监督管理局 / DB45/T 2935—2024 CT增强扫描碘对比剂外渗预防与护理规范 / 广西壮族自治区市场监督管理局（地方标准） / 2024",
          "grade": "标准与规范",
          "ref": "R10"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "E_ContrastInjection",
      "name": "碘对比剂",
      "type": "Exam",
      "tags": [
        "辅助检查",
        "对比剂"
      ],
      "aliases": [
        "碘对比剂静脉输注",
        "含碘造影剂",
        "造影剂",
        "iodine contrast agent"
      ],
      "summary": "CT 增强扫描时打进血管的含碘对比剂，是过敏反应和外渗这两类风险的来源。",
      "attrs": [
        {
          "k": "给药方式",
          "v": "经静脉注射（高压注射器）"
        },
        {
          "k": "检查前皮试",
          "v": "常规不需要做碘对比剂过敏试验"
        }
      ],
      "evidence": [
        {
          "type": "指南",
          "author": "美国放射学会药物与对比剂委员会",
          "title": "美国放射学会对比剂手册",
          "journal": "美国放射学会",
          "year": 2024,
          "cite": "美国放射学会药物与对比剂委员会 / 美国放射学会对比剂手册 / 美国放射学会 / 2024",
          "grade": "指南与共识",
          "ref": "R01"
        },
        {
          "type": "指南",
          "author": "中华医学会放射学分会对比剂安全使用工作组",
          "title": "碘对比剂使用指南（第2版）",
          "journal": "中华放射学杂志",
          "year": 2013,
          "cite": "中华医学会放射学分会对比剂安全使用工作组 / 碘对比剂使用指南（第2版） / 中华放射学杂志 / 2013",
          "grade": "指南与共识",
          "ref": "R03"
        },
        {
          "type": "共识",
          "author": "中华医学会放射学分会放射护理专业委员会放射诊断护理学组（执笔：李雪、郑淑梅、屈梅香）",
          "title": "影像科碘对比剂输注安全专家共识",
          "journal": "介入放射学杂志",
          "year": 2018,
          "cite": "中华医学会放射学分会放射护理专业委员会放射诊断护理学组（执笔：李雪、郑淑梅、屈梅香） / 影像科碘对比剂输注安全专家共识 / 介入放射学杂志 / 2018",
          "grade": "指南与共识",
          "ref": "R07"
        },
        {
          "type": "推荐",
          "author": "de Laforcade L, Bobot M, Bellin MF, et al.",
          "title": "欧洲泌尿生殖放射学会对比剂使用建议：法国肾脏病学会、法语放射学会与法语肾脏病医师学会的实践调查与述评",
          "journal": "肾脏病与治疗",
          "year": 2021,
          "cite": "de Laforcade L, Bobot M, Bellin MF, et al. / 欧洲泌尿生殖放射学会对比剂使用建议：法国肾脏病学会、法语放射学会与法语肾脏病医师学会的实践调查与述评 / 肾脏病与治疗 / 2021",
          "grade": "推荐意见",
          "ref": "R15"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "S_AdverseReaction",
      "name": "不良反应",
      "type": "SymptomSign",
      "tags": [
        "症状体征"
      ],
      "aliases": [
        "adverse reaction",
        "对比剂不良反应",
        "药物不良反应"
      ],
      "summary": "使用碘对比剂后出现的非预期身体反应。",
      "attrs": [],
      "evidence": [
        {
          "type": "指南",
          "author": "美国放射学会药物与对比剂委员会",
          "title": "美国放射学会对比剂手册",
          "journal": "美国放射学会",
          "year": 2024,
          "cite": "美国放射学会药物与对比剂委员会 / 美国放射学会对比剂手册 / 美国放射学会 / 2024",
          "grade": "指南与共识",
          "ref": "R01"
        },
        {
          "type": "声明",
          "author": "Wang C, Ramsey A, Lang D, et al.",
          "title": "放射性对比剂超敏反应的管理与预防：美国放射学会与美国变态反应、哮喘与免疫学会共识声明",
          "journal": "放射学",
          "year": 2025,
          "cite": "Wang C, Ramsey A, Lang D, et al. / 放射性对比剂超敏反应的管理与预防：美国放射学会与美国变态反应、哮喘与免疫学会共识声明 / 放射学 / 2025",
          "grade": "学会声明",
          "ref": "R12"
        },
        {
          "type": "建议",
          "author": "Byrne A, Macdonald DB, Kirkpatrick IDC, et al.",
          "title": "对比剂超敏反应实践指南（加拿大放射医师协会与加拿大过敏与临床免疫学会）",
          "journal": "加拿大放射医师协会杂志",
          "year": 2025,
          "cite": "Byrne A, Macdonald DB, Kirkpatrick IDC, et al. / 对比剂超敏反应实践指南（加拿大放射医师协会与加拿大过敏与临床免疫学会） / 加拿大放射医师协会杂志 / 2025",
          "grade": "推荐意见",
          "ref": "R14"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "S_Rash",
      "name": "皮疹",
      "type": "SymptomSign",
      "tags": [
        "症状体征"
      ],
      "aliases": [
        "rash",
        "皮肤",
        "皮肤反应",
        "皮疹"
      ],
      "summary": "身上出现的红斑或丘疹样皮损。",
      "attrs": [],
      "evidence": [
        {
          "type": "声明",
          "author": "Wang C, Ramsey A, Lang D, et al.",
          "title": "放射性对比剂超敏反应的管理与预防：美国放射学会与美国变态反应、哮喘与免疫学会共识声明",
          "journal": "放射学",
          "year": 2025,
          "cite": "Wang C, Ramsey A, Lang D, et al. / 放射性对比剂超敏反应的管理与预防：美国放射学会与美国变态反应、哮喘与免疫学会共识声明 / 放射学 / 2025",
          "grade": "学会声明",
          "ref": "R12"
        },
        {
          "type": "建议",
          "author": "Brockow K",
          "title": "放射性对比剂超敏反应处理流程（2024 年更新）",
          "journal": "变态反应",
          "year": 2024,
          "cite": "Brockow K / 放射性对比剂超敏反应处理流程（2024 年更新） / 变态反应 / 2024",
          "grade": "推荐意见",
          "ref": "R13"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "S_AllergicReaction",
      "name": "过敏反应",
      "type": "SymptomSign",
      "tags": [
        "症状体征"
      ],
      "aliases": [
        "allergic reaction",
        "碘过敏反应",
        "碘对比剂过敏反应"
      ],
      "summary": "对碘对比剂发生的变态反应，可以累及呼吸道、循环系统和全身。",
      "attrs": [],
      "evidence": [
        {
          "type": "声明",
          "author": "Wang C, Ramsey A, Lang D, et al.",
          "title": "放射性对比剂超敏反应的管理与预防：美国放射学会与美国变态反应、哮喘与免疫学会共识声明",
          "journal": "放射学",
          "year": 2025,
          "cite": "Wang C, Ramsey A, Lang D, et al. / 放射性对比剂超敏反应的管理与预防：美国放射学会与美国变态反应、哮喘与免疫学会共识声明 / 放射学 / 2025",
          "grade": "学会声明",
          "ref": "R12"
        },
        {
          "type": "建议",
          "author": "Brockow K",
          "title": "放射性对比剂超敏反应处理流程（2024 年更新）",
          "journal": "变态反应",
          "year": 2024,
          "cite": "Brockow K / 放射性对比剂超敏反应处理流程（2024 年更新） / 变态反应 / 2024",
          "grade": "推荐意见",
          "ref": "R13"
        },
        {
          "type": "建议",
          "author": "Byrne A, Macdonald DB, Kirkpatrick IDC, et al.",
          "title": "对比剂超敏反应实践指南（加拿大放射医师协会与加拿大过敏与临床免疫学会）",
          "journal": "加拿大放射医师协会杂志",
          "year": 2025,
          "cite": "Byrne A, Macdonald DB, Kirkpatrick IDC, et al. / 对比剂超敏反应实践指南（加拿大放射医师协会与加拿大过敏与临床免疫学会） / 加拿大放射医师协会杂志 / 2025",
          "grade": "推荐意见",
          "ref": "R14"
        },
        {
          "type": "Meta分析",
          "author": "Nawras M, Alyousif Z, Beran A, Elsamaloty H",
          "title": "碘对比剂温度与不良反应的关系：307,329 次注射的 Meta 分析",
          "journal": "临床影像学",
          "year": 2023,
          "cite": "Nawras M, Alyousif Z, Beran A, Elsamaloty H / 碘对比剂温度与不良反应的关系：307,329 次注射的 Meta 分析 / 临床影像学 / 2023 · DOI 10.1016/j.clinimag.2023.05.006 · PMID 37216743"
        },
        {
          "type": "Meta分析",
          "author": "Huang W, He C, Chen Y, Xu H, Yao J, Zhao L",
          "title": "对比剂即刻超敏反应危险因素的系统评价与 Meta 分析",
          "journal": "欧洲放射学杂志",
          "year": 2026,
          "cite": "Huang W, He C, Chen Y, Xu H, Yao J, Zhao L / 对比剂即刻超敏反应危险因素的系统评价与 Meta 分析 / 欧洲放射学杂志 / 2026 · DOI 10.1016/j.ejrad.2025.112472 · PMID 41175815"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "S_Urticaria",
      "name": "荨麻疹",
      "type": "SymptomSign",
      "tags": [
        "症状体征"
      ],
      "aliases": [
        "寻麻疹",
        "urticaria",
        "风团",
        "hives"
      ],
      "summary": "接触碘对比剂后成片出现的红色风团样皮损。",
      "attrs": [],
      "evidence": [
        {
          "type": "声明",
          "author": "Wang C, Ramsey A, Lang D, et al.",
          "title": "放射性对比剂超敏反应的管理与预防：美国放射学会与美国变态反应、哮喘与免疫学会共识声明",
          "journal": "放射学",
          "year": 2025,
          "cite": "Wang C, Ramsey A, Lang D, et al. / 放射性对比剂超敏反应的管理与预防：美国放射学会与美国变态反应、哮喘与免疫学会共识声明 / 放射学 / 2025",
          "grade": "学会声明",
          "ref": "R12"
        },
        {
          "type": "建议",
          "author": "Brockow K",
          "title": "放射性对比剂超敏反应处理流程（2024 年更新）",
          "journal": "变态反应",
          "year": 2024,
          "cite": "Brockow K / 放射性对比剂超敏反应处理流程（2024 年更新） / 变态反应 / 2024",
          "grade": "推荐意见",
          "ref": "R13"
        },
        {
          "type": "推荐实践",
          "author": "Golden DBK, Wang J, Waserman S, et al.",
          "title": "过敏反应：2023 年实践参数更新",
          "journal": "变态反应、哮喘与免疫学年鉴",
          "year": 2024,
          "cite": "Golden DBK, Wang J, Waserman S, et al. / 过敏反应：2023 年实践参数更新 / 变态反应、哮喘与免疫学年鉴 / 2024",
          "grade": "推荐意见",
          "ref": "R16"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "S_Pruritus",
      "name": "瘙痒",
      "type": "SymptomSign",
      "tags": [
        "症状体征"
      ],
      "aliases": [
        "pruritus",
        "皮肤瘙痒"
      ],
      "summary": "主观上难以忍受的痒感。",
      "attrs": [],
      "evidence": [
        {
          "type": "声明",
          "author": "Wang C, Ramsey A, Lang D, et al.",
          "title": "放射性对比剂超敏反应的管理与预防：美国放射学会与美国变态反应、哮喘与免疫学会共识声明",
          "journal": "放射学",
          "year": 2025,
          "cite": "Wang C, Ramsey A, Lang D, et al. / 放射性对比剂超敏反应的管理与预防：美国放射学会与美国变态反应、哮喘与免疫学会共识声明 / 放射学 / 2025",
          "grade": "学会声明",
          "ref": "R12"
        },
        {
          "type": "推荐实践",
          "author": "Golden DBK, Wang J, Waserman S, et al.",
          "title": "过敏反应：2023 年实践参数更新",
          "journal": "变态反应、哮喘与免疫学年鉴",
          "year": 2024,
          "cite": "Golden DBK, Wang J, Waserman S, et al. / 过敏反应：2023 年实践参数更新 / 变态反应、哮喘与免疫学年鉴 / 2024",
          "grade": "推荐意见",
          "ref": "R16"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "S_FacialEdema",
      "name": "颜面部水肿",
      "type": "SymptomSign",
      "tags": [
        "症状体征"
      ],
      "aliases": [
        "facial edema",
        "面部水肿",
        "颜面水肿"
      ],
      "summary": "面部和眼睑肿起来，提示反应正在加重。",
      "attrs": [],
      "evidence": [
        {
          "type": "声明",
          "author": "Wang C, Ramsey A, Lang D, et al.",
          "title": "放射性对比剂超敏反应的管理与预防：美国放射学会与美国变态反应、哮喘与免疫学会共识声明",
          "journal": "放射学",
          "year": 2025,
          "cite": "Wang C, Ramsey A, Lang D, et al. / 放射性对比剂超敏反应的管理与预防：美国放射学会与美国变态反应、哮喘与免疫学会共识声明 / 放射学 / 2025",
          "grade": "学会声明",
          "ref": "R12"
        },
        {
          "type": "建议",
          "author": "Brockow K",
          "title": "放射性对比剂超敏反应处理流程（2024 年更新）",
          "journal": "变态反应",
          "year": 2024,
          "cite": "Brockow K / 放射性对比剂超敏反应处理流程（2024 年更新） / 变态反应 / 2024",
          "grade": "推荐意见",
          "ref": "R13"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "S_ThroatDiscomfort",
      "name": "咽喉部不适",
      "type": "SymptomSign",
      "tags": [
        "症状体征"
      ],
      "aliases": [
        "throat discomfort",
        "咽部不适",
        "咽喉不适"
      ],
      "summary": "嗓子发紧、像有东西卡住，是需要立刻处理的危险信号。",
      "attrs": [],
      "evidence": [
        {
          "type": "声明",
          "author": "Wang C, Ramsey A, Lang D, et al.",
          "title": "放射性对比剂超敏反应的管理与预防：美国放射学会与美国变态反应、哮喘与免疫学会共识声明",
          "journal": "放射学",
          "year": 2025,
          "cite": "Wang C, Ramsey A, Lang D, et al. / 放射性对比剂超敏反应的管理与预防：美国放射学会与美国变态反应、哮喘与免疫学会共识声明 / 放射学 / 2025",
          "grade": "学会声明",
          "ref": "R12"
        },
        {
          "type": "推荐实践",
          "author": "Golden DBK, Wang J, Waserman S, et al.",
          "title": "过敏反应：2023 年实践参数更新",
          "journal": "变态反应、哮喘与免疫学年鉴",
          "year": 2024,
          "cite": "Golden DBK, Wang J, Waserman S, et al. / 过敏反应：2023 年实践参数更新 / 变态反应、哮喘与免疫学年鉴 / 2024",
          "grade": "推荐意见",
          "ref": "R16"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "S_ChestTightness",
      "name": "胸闷",
      "type": "SymptomSign",
      "tags": [
        "症状体征"
      ],
      "aliases": [
        "chest tightness",
        "胸部闷"
      ],
      "summary": "胸口发闷、觉得透不过气的主诉。",
      "attrs": [],
      "evidence": [
        {
          "type": "声明",
          "author": "Wang C, Ramsey A, Lang D, et al.",
          "title": "放射性对比剂超敏反应的管理与预防：美国放射学会与美国变态反应、哮喘与免疫学会共识声明",
          "journal": "放射学",
          "year": 2025,
          "cite": "Wang C, Ramsey A, Lang D, et al. / 放射性对比剂超敏反应的管理与预防：美国放射学会与美国变态反应、哮喘与免疫学会共识声明 / 放射学 / 2025",
          "grade": "学会声明",
          "ref": "R12"
        },
        {
          "type": "建议",
          "author": "Brockow K",
          "title": "放射性对比剂超敏反应处理流程（2024 年更新）",
          "journal": "变态反应",
          "year": 2024,
          "cite": "Brockow K / 放射性对比剂超敏反应处理流程（2024 年更新） / 变态反应 / 2024",
          "grade": "推荐意见",
          "ref": "R13"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "S_GeneralizedWeakness",
      "name": "全身无力",
      "type": "SymptomSign",
      "tags": [
        "症状体征"
      ],
      "aliases": [
        "generalized weakness",
        "乏力",
        "全身乏力"
      ],
      "summary": "浑身没劲、站不稳的感觉。",
      "attrs": [],
      "evidence": [
        {
          "type": "声明",
          "author": "Wang C, Ramsey A, Lang D, et al.",
          "title": "放射性对比剂超敏反应的管理与预防：美国放射学会与美国变态反应、哮喘与免疫学会共识声明",
          "journal": "放射学",
          "year": 2025,
          "cite": "Wang C, Ramsey A, Lang D, et al. / 放射性对比剂超敏反应的管理与预防：美国放射学会与美国变态反应、哮喘与免疫学会共识声明 / 放射学 / 2025",
          "grade": "学会声明",
          "ref": "R12"
        },
        {
          "type": "推荐实践",
          "author": "Golden DBK, Wang J, Waserman S, et al.",
          "title": "过敏反应：2023 年实践参数更新",
          "journal": "变态反应、哮喘与免疫学年鉴",
          "year": 2024,
          "cite": "Golden DBK, Wang J, Waserman S, et al. / 过敏反应：2023 年实践参数更新 / 变态反应、哮喘与免疫学年鉴 / 2024",
          "grade": "推荐意见",
          "ref": "R16"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "S_AnaphylacticShock",
      "name": "过敏性休克",
      "type": "SymptomSign",
      "tags": [
        "症状体征"
      ],
      "aliases": [
        "anaphylactic shock",
        "过敏性休克表现",
        "休克"
      ],
      "summary": "最重的一类过敏反应，会危及生命，必须马上抢救。",
      "attrs": [],
      "evidence": [
        {
          "type": "推荐实践",
          "author": "Golden DBK, Wang J, Waserman S, et al.",
          "title": "过敏反应：2023 年实践参数更新",
          "journal": "变态反应、哮喘与免疫学年鉴",
          "year": 2024,
          "cite": "Golden DBK, Wang J, Waserman S, et al. / 过敏反应：2023 年实践参数更新 / 变态反应、哮喘与免疫学年鉴 / 2024",
          "grade": "推荐意见",
          "ref": "R16"
        },
        {
          "type": "声明",
          "author": "Wang C, Ramsey A, Lang D, et al.",
          "title": "放射性对比剂超敏反应的管理与预防：美国放射学会与美国变态反应、哮喘与免疫学会共识声明",
          "journal": "放射学",
          "year": 2025,
          "cite": "Wang C, Ramsey A, Lang D, et al. / 放射性对比剂超敏反应的管理与预防：美国放射学会与美国变态反应、哮喘与免疫学会共识声明 / 放射学 / 2025",
          "grade": "学会声明",
          "ref": "R12"
        },
        {
          "type": "建议",
          "author": "Brockow K",
          "title": "放射性对比剂超敏反应处理流程（2024 年更新）",
          "journal": "变态反应",
          "year": 2024,
          "cite": "Brockow K / 放射性对比剂超敏反应处理流程（2024 年更新） / 变态反应 / 2024",
          "grade": "推荐意见",
          "ref": "R13"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "S_Extravasation",
      "name": "碘对比剂外渗",
      "type": "SymptomSign",
      "tags": [
        "症状体征"
      ],
      "aliases": [
        "extravasation of iodine contrast agent",
        "对比剂外渗",
        "静脉外渗",
        "外渗"
      ],
      "summary": "造影剂没进血管、漏到皮下，轻则肿痛，重则组织坏死。",
      "attrs": [
        {
          "k": "发生率",
          "v": "文献报道约 0.1%～0.9%"
        },
        {
          "k": "处置要点",
          "v": "停止注射 · 保留留置针 · 禁止揉搓 · 抬高患肢"
        }
      ],
      "evidence": [
        {
          "type": "指南",
          "author": "Roditi G, Khan N, van der Molen AJ, et al.",
          "title": "静脉对比剂外渗：系统评价及欧洲泌尿生殖放射学会对比剂安全委员会指南更新",
          "journal": "欧洲放射学杂志",
          "year": 2022,
          "cite": "Roditi G, Khan N, van der Molen AJ, et al. / 静脉对比剂外渗：系统评价及欧洲泌尿生殖放射学会对比剂安全委员会指南更新 / 欧洲放射学杂志 / 2022",
          "grade": "指南与共识",
          "ref": "R02"
        },
        {
          "type": "指南",
          "author": "中华护理学会放射介入护理专业委员会（执笔：张红梅、张素、刘宇）",
          "title": "含碘对比剂静脉外渗护理管理实践指南（2026年更新版）",
          "journal": "中华护理杂志",
          "year": 2026,
          "cite": "中华护理学会放射介入护理专业委员会（执笔：张红梅、张素、刘宇） / 含碘对比剂静脉外渗护理管理实践指南（2026年更新版） / 中华护理杂志 / 2026",
          "grade": "指南与共识",
          "ref": "R04"
        },
        {
          "type": "系统评价",
          "author": "姚金秀、杨丽娜、梅申聪、董芳辉",
          "title": "放射科碘对比剂外渗影响因素的系统评价",
          "journal": "上海护理",
          "year": 2023,
          "cite": "姚金秀、杨丽娜、梅申聪、董芳辉 / 放射科碘对比剂外渗影响因素的系统评价 / 上海护理 / 2023",
          "grade": "汇总证据",
          "ref": "R17"
        },
        {
          "type": "规范",
          "author": "江西省市场监督管理局",
          "title": "DB36/T 2299—2026 含碘对比剂静脉外渗预防与护理规范",
          "journal": "江西省市场监督管理局（地方标准）",
          "year": 2026,
          "cite": "江西省市场监督管理局 / DB36/T 2299—2026 含碘对比剂静脉外渗预防与护理规范 / 江西省市场监督管理局（地方标准） / 2026",
          "grade": "标准与规范",
          "ref": "R09"
        },
        {
          "type": "规范",
          "author": "广西壮族自治区市场监督管理局",
          "title": "DB45/T 2935—2024 CT增强扫描碘对比剂外渗预防与护理规范",
          "journal": "广西壮族自治区市场监督管理局（地方标准）",
          "year": 2024,
          "cite": "广西壮族自治区市场监督管理局 / DB45/T 2935—2024 CT增强扫描碘对比剂外渗预防与护理规范 / 广西壮族自治区市场监督管理局（地方标准） / 2024",
          "grade": "标准与规范",
          "ref": "R10"
        },
        {
          "type": "Meta分析",
          "author": "Nawras M, Alyousif Z, Beran A, Elsamaloty H",
          "title": "碘对比剂温度与不良反应的关系：307,329 次注射的 Meta 分析",
          "journal": "临床影像学",
          "year": 2023,
          "cite": "Nawras M, Alyousif Z, Beran A, Elsamaloty H / 碘对比剂温度与不良反应的关系：307,329 次注射的 Meta 分析 / 临床影像学 / 2023 · DOI 10.1016/j.clinimag.2023.05.006 · PMID 37216743"
        },
        {
          "type": "Meta分析",
          "author": "Ding S, Meystre NR, Campeanu C, Gullo G",
          "title": "CT 扫描患者对比剂外渗：危险因素与干预的系统评价和 Meta 分析",
          "journal": "JBI 系统评价与实施报告",
          "year": 2018,
          "cite": "Ding S, Meystre NR, Campeanu C, Gullo G / CT 扫描患者对比剂外渗：危险因素与干预的系统评价和 Meta 分析 / JBI 系统评价与实施报告 / 2018 · DOI 10.11124/JBISRIR-2017-003348 · PMID 29324560"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "SC_AdverseSpectrum",
      "name": "碘对比剂不良反应谱",
      "type": "SymptomCategory",
      "tags": [
        "症状分类"
      ],
      "aliases": [
        "不良反应谱",
        "不良反应谱系"
      ],
      "summary": "把打造影剂之后可能出的各类反应归到一起的分类。",
      "attrs": [],
      "evidence": [
        {
          "type": "指南",
          "author": "美国放射学会药物与对比剂委员会",
          "title": "美国放射学会对比剂手册",
          "journal": "美国放射学会",
          "year": 2024,
          "cite": "美国放射学会药物与对比剂委员会 / 美国放射学会对比剂手册 / 美国放射学会 / 2024",
          "grade": "指南与共识",
          "ref": "R01"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "SC_Hypersensitivity",
      "name": "过敏反应谱",
      "type": "SymptomCategory",
      "tags": [
        "症状分类"
      ],
      "aliases": [
        "过敏反应谱"
      ],
      "summary": "过敏这一类反应从轻到重的分层。",
      "attrs": [],
      "evidence": [
        {
          "type": "声明",
          "author": "Wang C, Ramsey A, Lang D, et al.",
          "title": "放射性对比剂超敏反应的管理与预防：美国放射学会与美国变态反应、哮喘与免疫学会共识声明",
          "journal": "放射学",
          "year": 2025,
          "cite": "Wang C, Ramsey A, Lang D, et al. / 放射性对比剂超敏反应的管理与预防：美国放射学会与美国变态反应、哮喘与免疫学会共识声明 / 放射学 / 2025",
          "grade": "学会声明",
          "ref": "R12"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "SC_ExtravasationSpectrum",
      "name": "静脉外渗反应谱",
      "type": "SymptomCategory",
      "tags": [
        "症状分类"
      ],
      "aliases": [
        "外渗反应谱"
      ],
      "summary": "外渗发生后从轻到重的表现分层：局部肿胀、疼痛、发红、皮肤发凉与发白发紧；疼痛加重、感觉改变、活动受限、出现水疱或组织坏死，都是需要立即升级处理的信号。",
      "attrs": [],
      "evidence": [
        {
          "type": "指南",
          "author": "Roditi G, Khan N, van der Molen AJ, et al.",
          "title": "静脉对比剂外渗：系统评价及欧洲泌尿生殖放射学会对比剂安全委员会指南更新",
          "journal": "欧洲放射学杂志",
          "year": 2022,
          "cite": "Roditi G, Khan N, van der Molen AJ, et al. / 静脉对比剂外渗：系统评价及欧洲泌尿生殖放射学会对比剂安全委员会指南更新 / 欧洲放射学杂志 / 2022",
          "grade": "指南与共识",
          "ref": "R02"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "AT_AllergyHistory",
      "name": "过敏史询问",
      "type": "AssessmentTool",
      "tags": [
        "评估工具"
      ],
      "aliases": [
        "allergy history inquiry",
        "既往过敏史询问",
        "过敏史筛查"
      ],
      "summary": "检查前一项一项问清楚以前有没有过敏反应的评估动作。",
      "attrs": [],
      "evidence": [
        {
          "type": "指南",
          "author": "中华医学会放射学分会对比剂安全使用工作组",
          "title": "碘对比剂使用指南（第2版）",
          "journal": "中华放射学杂志",
          "year": 2013,
          "cite": "中华医学会放射学分会对比剂安全使用工作组 / 碘对比剂使用指南（第2版） / 中华放射学杂志 / 2013",
          "grade": "指南与共识",
          "ref": "R03"
        },
        {
          "type": "声明",
          "author": "Wang C, Ramsey A, Lang D, et al.",
          "title": "放射性对比剂超敏反应的管理与预防：美国放射学会与美国变态反应、哮喘与免疫学会共识声明",
          "journal": "放射学",
          "year": 2025,
          "cite": "Wang C, Ramsey A, Lang D, et al. / 放射性对比剂超敏反应的管理与预防：美国放射学会与美国变态反应、哮喘与免疫学会共识声明 / 放射学 / 2025",
          "grade": "学会声明",
          "ref": "R12"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "AT_ExtravasationAssessment",
      "name": "外渗风险评估",
      "type": "AssessmentTool",
      "tags": [
        "评估工具"
      ],
      "aliases": [
        "extravasation risk assessment",
        "外渗风险评估表"
      ],
      "summary": "检查前先把外渗高危的人挑出来的评估方法。",
      "attrs": [],
      "evidence": [
        {
          "type": "指南",
          "author": "中华护理学会放射介入护理专业委员会（执笔：张红梅、张素、刘宇）",
          "title": "含碘对比剂静脉外渗护理管理实践指南（2026年更新版）",
          "journal": "中华护理杂志",
          "year": 2026,
          "cite": "中华护理学会放射介入护理专业委员会（执笔：张红梅、张素、刘宇） / 含碘对比剂静脉外渗护理管理实践指南（2026年更新版） / 中华护理杂志 / 2026",
          "grade": "指南与共识",
          "ref": "R04"
        },
        {
          "type": "系统评价",
          "author": "姚金秀、杨丽娜、梅申聪、董芳辉",
          "title": "放射科碘对比剂外渗影响因素的系统评价",
          "journal": "上海护理",
          "year": 2023,
          "cite": "姚金秀、杨丽娜、梅申聪、董芳辉 / 放射科碘对比剂外渗影响因素的系统评价 / 上海护理 / 2023",
          "grade": "汇总证据",
          "ref": "R17"
        },
        {
          "type": "Meta分析",
          "author": "Ding S, Meystre NR, Campeanu C, Gullo G",
          "title": "CT 扫描患者对比剂外渗：危险因素与干预的系统评价和 Meta 分析",
          "journal": "JBI 系统评价与实施报告",
          "year": 2018,
          "cite": "Ding S, Meystre NR, Campeanu C, Gullo G / CT 扫描患者对比剂外渗：危险因素与干预的系统评价和 Meta 分析 / JBI 系统评价与实施报告 / 2018 · DOI 10.11124/JBISRIR-2017-003348 · PMID 29324560"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "AT_VascularAssessment",
      "name": "血管条件评估",
      "type": "AssessmentTool",
      "tags": [
        "评估工具"
      ],
      "aliases": [
        "vascular assessment",
        "静脉条件评估",
        "血管可视化评估"
      ],
      "summary": "扎针之前评估血管粗细、弹性和位置的方法。",
      "attrs": [],
      "evidence": [
        {
          "type": "标准",
          "author": "国家卫生健康委员会",
          "title": "WS/T 433—2023 静脉治疗护理技术操作标准",
          "journal": "国家卫生健康委员会（卫生行业标准）",
          "year": 2023,
          "cite": "国家卫生健康委员会 / WS/T 433—2023 静脉治疗护理技术操作标准 / 国家卫生健康委员会（卫生行业标准） / 2023",
          "grade": "标准与规范",
          "ref": "R08"
        },
        {
          "type": "规范",
          "author": "江西省市场监督管理局",
          "title": "DB36/T 2299—2026 含碘对比剂静脉外渗预防与护理规范",
          "journal": "江西省市场监督管理局（地方标准）",
          "year": 2026,
          "cite": "江西省市场监督管理局 / DB36/T 2299—2026 含碘对比剂静脉外渗预防与护理规范 / 江西省市场监督管理局（地方标准） / 2026",
          "grade": "标准与规范",
          "ref": "R09"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "RF_ContrastAllergyHistory",
      "name": "既往碘对比剂过敏史",
      "type": "RiskFactor",
      "tags": [
        "高危因素"
      ],
      "aliases": [
        "contrast allergy history",
        "碘对比剂过敏史",
        "既往过敏反应史"
      ],
      "summary": "以前打造影剂出过事，是最重要的一条风险提示。",
      "attrs": [],
      "evidence": [
        {
          "type": "声明",
          "author": "Wang C, Ramsey A, Lang D, et al.",
          "title": "放射性对比剂超敏反应的管理与预防：美国放射学会与美国变态反应、哮喘与免疫学会共识声明",
          "journal": "放射学",
          "year": 2025,
          "cite": "Wang C, Ramsey A, Lang D, et al. / 放射性对比剂超敏反应的管理与预防：美国放射学会与美国变态反应、哮喘与免疫学会共识声明 / 放射学 / 2025",
          "grade": "学会声明",
          "ref": "R12"
        },
        {
          "type": "建议",
          "author": "Brockow K",
          "title": "放射性对比剂超敏反应处理流程（2024 年更新）",
          "journal": "变态反应",
          "year": 2024,
          "cite": "Brockow K / 放射性对比剂超敏反应处理流程（2024 年更新） / 变态反应 / 2024",
          "grade": "推荐意见",
          "ref": "R13"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "RF_UncontrolledAsthma",
      "name": "未控制的哮喘",
      "type": "RiskFactor",
      "tags": [
        "高危因素"
      ],
      "aliases": [
        "uncontrolled asthma",
        "哮喘未控制"
      ],
      "summary": "哮喘没控制好时，指南仍列为需要关注的风险因素；2026 年 Meta 分析未显示显著关联，证据不一致。",
      "attrs": [],
      "evidence": [
        {
          "type": "声明",
          "author": "Wang C, Ramsey A, Lang D, et al.",
          "title": "放射性对比剂超敏反应的管理与预防：美国放射学会与美国变态反应、哮喘与免疫学会共识声明",
          "journal": "放射学",
          "year": 2025,
          "cite": "Wang C, Ramsey A, Lang D, et al. / 放射性对比剂超敏反应的管理与预防：美国放射学会与美国变态反应、哮喘与免疫学会共识声明 / 放射学 / 2025",
          "grade": "学会声明",
          "ref": "R12"
        },
        {
          "type": "建议",
          "author": "Brockow K",
          "title": "放射性对比剂超敏反应处理流程（2024 年更新）",
          "journal": "变态反应",
          "year": 2024,
          "cite": "Brockow K / 放射性对比剂超敏反应处理流程（2024 年更新） / 变态反应 / 2024",
          "grade": "推荐意见",
          "ref": "R13"
        },
        {
          "type": "Meta分析",
          "author": "Huang W, He C, Chen Y, Xu H, Yao J, Zhao L",
          "title": "对比剂即刻超敏反应危险因素的系统评价与 Meta 分析",
          "journal": "欧洲放射学杂志",
          "year": 2026,
          "cite": "Huang W, He C, Chen Y, Xu H, Yao J, Zhao L / 对比剂即刻超敏反应危险因素的系统评价与 Meta 分析 / 欧洲放射学杂志 / 2026 · DOI 10.1016/j.ejrad.2025.112472 · PMID 41175815"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "RF_AgeExtremes",
      "name": "高龄或低龄",
      "type": "RiskFactor",
      "tags": [
        "高危因素"
      ],
      "aliases": [
        "extremes of age",
        "高龄",
        "婴幼儿"
      ],
      "summary": "年纪特别大或者特别小的患者，血管条件通常更差。",
      "attrs": [],
      "evidence": [
        {
          "type": "指南",
          "author": "中华护理学会放射介入护理专业委员会（执笔：张红梅、张素、刘宇）",
          "title": "含碘对比剂静脉外渗护理管理实践指南（2026年更新版）",
          "journal": "中华护理杂志",
          "year": 2026,
          "cite": "中华护理学会放射介入护理专业委员会（执笔：张红梅、张素、刘宇） / 含碘对比剂静脉外渗护理管理实践指南（2026年更新版） / 中华护理杂志 / 2026",
          "grade": "指南与共识",
          "ref": "R04"
        },
        {
          "type": "系统评价",
          "author": "姚金秀、杨丽娜、梅申聪、董芳辉",
          "title": "放射科碘对比剂外渗影响因素的系统评价",
          "journal": "上海护理",
          "year": 2023,
          "cite": "姚金秀、杨丽娜、梅申聪、董芳辉 / 放射科碘对比剂外渗影响因素的系统评价 / 上海护理 / 2023",
          "grade": "汇总证据",
          "ref": "R17"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "RF_FragileVein",
      "name": "静脉条件差",
      "type": "RiskFactor",
      "tags": [
        "高危因素"
      ],
      "aliases": [
        "fragile vein",
        "外周静脉硬化",
        "血管脆弱"
      ],
      "summary": "血管细、脆、硬化，容易发生外渗。",
      "attrs": [],
      "evidence": [
        {
          "type": "指南",
          "author": "中华护理学会放射介入护理专业委员会（执笔：张红梅、张素、刘宇）",
          "title": "含碘对比剂静脉外渗护理管理实践指南（2026年更新版）",
          "journal": "中华护理杂志",
          "year": 2026,
          "cite": "中华护理学会放射介入护理专业委员会（执笔：张红梅、张素、刘宇） / 含碘对比剂静脉外渗护理管理实践指南（2026年更新版） / 中华护理杂志 / 2026",
          "grade": "指南与共识",
          "ref": "R04"
        },
        {
          "type": "系统评价",
          "author": "姚金秀、杨丽娜、梅申聪、董芳辉",
          "title": "放射科碘对比剂外渗影响因素的系统评价",
          "journal": "上海护理",
          "year": 2023,
          "cite": "姚金秀、杨丽娜、梅申聪、董芳辉 / 放射科碘对比剂外渗影响因素的系统评价 / 上海护理 / 2023",
          "grade": "汇总证据",
          "ref": "R17"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "RF_HighPressureInjection",
      "name": "高压注射",
      "type": "RiskFactor",
      "tags": [
        "高危因素"
      ],
      "aliases": [
        "high pressure injection",
        "高压注射器推注"
      ],
      "summary": "用高压注射器快速推药，会明显增加外渗风险。",
      "attrs": [],
      "evidence": [
        {
          "type": "指南",
          "author": "Roditi G, Khan N, van der Molen AJ, et al.",
          "title": "静脉对比剂外渗：系统评价及欧洲泌尿生殖放射学会对比剂安全委员会指南更新",
          "journal": "欧洲放射学杂志",
          "year": 2022,
          "cite": "Roditi G, Khan N, van der Molen AJ, et al. / 静脉对比剂外渗：系统评价及欧洲泌尿生殖放射学会对比剂安全委员会指南更新 / 欧洲放射学杂志 / 2022",
          "grade": "指南与共识",
          "ref": "R02"
        },
        {
          "type": "指南",
          "author": "中华护理学会放射介入护理专业委员会（执笔：张红梅、张素、刘宇）",
          "title": "含碘对比剂静脉外渗护理管理实践指南（2026年更新版）",
          "journal": "中华护理杂志",
          "year": 2026,
          "cite": "中华护理学会放射介入护理专业委员会（执笔：张红梅、张素、刘宇） / 含碘对比剂静脉外渗护理管理实践指南（2026年更新版） / 中华护理杂志 / 2026",
          "grade": "指南与共识",
          "ref": "R04"
        },
        {
          "type": "系统评价",
          "author": "姚金秀、杨丽娜、梅申聪、董芳辉",
          "title": "放射科碘对比剂外渗影响因素的系统评价",
          "journal": "上海护理",
          "year": 2023,
          "cite": "姚金秀、杨丽娜、梅申聪、董芳辉 / 放射科碘对比剂外渗影响因素的系统评价 / 上海护理 / 2023",
          "grade": "汇总证据",
          "ref": "R17"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "RF_NoSalineFlush",
      "name": "未做生理盐水试推",
      "type": "RiskFactor",
      "tags": [
        "高危因素"
      ],
      "aliases": [
        "no saline flush check",
        "未试推生理盐水"
      ],
      "summary": "推药之前不先试推生理盐水，就难发现血管通不通。",
      "attrs": [],
      "evidence": [
        {
          "type": "指南",
          "author": "中华护理学会放射介入护理专业委员会（执笔：张红梅、张素、刘宇）",
          "title": "含碘对比剂静脉外渗护理管理实践指南（2026年更新版）",
          "journal": "中华护理杂志",
          "year": 2026,
          "cite": "中华护理学会放射介入护理专业委员会（执笔：张红梅、张素、刘宇） / 含碘对比剂静脉外渗护理管理实践指南（2026年更新版） / 中华护理杂志 / 2026",
          "grade": "指南与共识",
          "ref": "R04"
        },
        {
          "type": "规范",
          "author": "江西省市场监督管理局",
          "title": "DB36/T 2299—2026 含碘对比剂静脉外渗预防与护理规范",
          "journal": "江西省市场监督管理局（地方标准）",
          "year": 2026,
          "cite": "江西省市场监督管理局 / DB36/T 2299—2026 含碘对比剂静脉外渗预防与护理规范 / 江西省市场监督管理局（地方标准） / 2026",
          "grade": "标准与规范",
          "ref": "R09"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "PM_AdrenalineIM",
      "name": "肌内注射肾上腺素",
      "type": "PharmacologicalManagement",
      "tags": [
        "药物治疗"
      ],
      "aliases": [
        "intramuscular adrenaline",
        "IM adrenaline",
        "肾上腺素肌注"
      ],
      "summary": "抢救过敏性休克的第一线用药，打在大腿外侧中部。",
      "attrs": [
        {
          "k": "给药部位",
          "v": "大腿外侧中部肌内注射"
        },
        {
          "k": "重复给药",
          "v": "必要时每 5～15 分钟重复"
        }
      ],
      "evidence": [
        {
          "type": "推荐实践",
          "author": "Golden DBK, Wang J, Waserman S, et al.",
          "title": "过敏反应：2023 年实践参数更新",
          "journal": "变态反应、哮喘与免疫学年鉴",
          "year": 2024,
          "cite": "Golden DBK, Wang J, Waserman S, et al. / 过敏反应：2023 年实践参数更新 / 变态反应、哮喘与免疫学年鉴 / 2024",
          "grade": "推荐意见",
          "ref": "R16"
        },
        {
          "type": "声明",
          "author": "Wang C, Ramsey A, Lang D, et al.",
          "title": "放射性对比剂超敏反应的管理与预防：美国放射学会与美国变态反应、哮喘与免疫学会共识声明",
          "journal": "放射学",
          "year": 2025,
          "cite": "Wang C, Ramsey A, Lang D, et al. / 放射性对比剂超敏反应的管理与预防：美国放射学会与美国变态反应、哮喘与免疫学会共识声明 / 放射学 / 2025",
          "grade": "学会声明",
          "ref": "R12"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "PM_Corticosteroid",
      "name": "糖皮质激素",
      "type": "PharmacologicalManagement",
      "tags": [
        "药物治疗"
      ],
      "aliases": [
        "corticosteroid",
        "激素治疗",
        "地塞米松"
      ],
      "summary": "配合抗组胺药控制过敏反应的辅助用药。",
      "attrs": [],
      "evidence": [
        {
          "type": "声明",
          "author": "Wang C, Ramsey A, Lang D, et al.",
          "title": "放射性对比剂超敏反应的管理与预防：美国放射学会与美国变态反应、哮喘与免疫学会共识声明",
          "journal": "放射学",
          "year": 2025,
          "cite": "Wang C, Ramsey A, Lang D, et al. / 放射性对比剂超敏反应的管理与预防：美国放射学会与美国变态反应、哮喘与免疫学会共识声明 / 放射学 / 2025",
          "grade": "学会声明",
          "ref": "R12"
        },
        {
          "type": "建议",
          "author": "Brockow K",
          "title": "放射性对比剂超敏反应处理流程（2024 年更新）",
          "journal": "变态反应",
          "year": 2024,
          "cite": "Brockow K / 放射性对比剂超敏反应处理流程（2024 年更新） / 变态反应 / 2024",
          "grade": "推荐意见",
          "ref": "R13"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "PM_Antihistamine",
      "name": "抗组胺药",
      "type": "PharmacologicalManagement",
      "tags": [
        "药物治疗"
      ],
      "aliases": [
        "antihistamine",
        "苯海拉明",
        "异丙嗪"
      ],
      "summary": "止痒、减轻风团样皮损的常用药。",
      "attrs": [],
      "evidence": [
        {
          "type": "声明",
          "author": "Wang C, Ramsey A, Lang D, et al.",
          "title": "放射性对比剂超敏反应的管理与预防：美国放射学会与美国变态反应、哮喘与免疫学会共识声明",
          "journal": "放射学",
          "year": 2025,
          "cite": "Wang C, Ramsey A, Lang D, et al. / 放射性对比剂超敏反应的管理与预防：美国放射学会与美国变态反应、哮喘与免疫学会共识声明 / 放射学 / 2025",
          "grade": "学会声明",
          "ref": "R12"
        },
        {
          "type": "建议",
          "author": "Brockow K",
          "title": "放射性对比剂超敏反应处理流程（2024 年更新）",
          "journal": "变态反应",
          "year": 2024,
          "cite": "Brockow K / 放射性对比剂超敏反应处理流程（2024 年更新） / 变态反应 / 2024",
          "grade": "推荐意见",
          "ref": "R13"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "PM_MagnesiumSulfate",
      "name": "50%硫酸镁湿敷",
      "type": "PharmacologicalManagement",
      "tags": [
        "药物治疗"
      ],
      "aliases": [
        "magnesium sulfate wet compress",
        "硫酸镁湿敷"
      ],
      "summary": "外渗后局部湿敷用的药，可以减轻肿胀和疼痛。",
      "attrs": [],
      "evidence": [
        {
          "type": "共识",
          "author": "中华医学会放射学分会放射护理专业委员会放射诊断护理学组（执笔：李雪、郑淑梅、屈梅香）",
          "title": "影像科碘对比剂输注安全专家共识",
          "journal": "介入放射学杂志",
          "year": 2018,
          "cite": "中华医学会放射学分会放射护理专业委员会放射诊断护理学组（执笔：李雪、郑淑梅、屈梅香） / 影像科碘对比剂输注安全专家共识 / 介入放射学杂志 / 2018",
          "grade": "指南与共识",
          "ref": "R07"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "PM_DexamethasoneWetCompress",
      "name": "0.05%地塞米松湿敷",
      "type": "PharmacologicalManagement",
      "tags": [
        "药物治疗"
      ],
      "aliases": [
        "dexamethasone wet compress",
        "地塞米松湿敷"
      ],
      "summary": "外渗后局部湿敷的另一种选择。",
      "attrs": [],
      "evidence": [
        {
          "type": "共识",
          "author": "中华医学会放射学分会放射护理专业委员会放射诊断护理学组（执笔：李雪、郑淑梅、屈梅香）",
          "title": "影像科碘对比剂输注安全专家共识",
          "journal": "介入放射学杂志",
          "year": 2018,
          "cite": "中华医学会放射学分会放射护理专业委员会放射诊断护理学组（执笔：李雪、郑淑梅、屈梅香） / 影像科碘对比剂输注安全专家共识 / 介入放射学杂志 / 2018",
          "grade": "指南与共识",
          "ref": "R07"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "NPM_StopInjection",
      "name": "立即停止注射",
      "type": "NonPharmacologicalManagement",
      "tags": [
        "非药物管理"
      ],
      "aliases": [
        "stop injection",
        "停止输注",
        "停止推注"
      ],
      "summary": "怀疑外渗时，第一时间停下推药。",
      "attrs": [],
      "evidence": [
        {
          "type": "指南",
          "author": "Roditi G, Khan N, van der Molen AJ, et al.",
          "title": "静脉对比剂外渗：系统评价及欧洲泌尿生殖放射学会对比剂安全委员会指南更新",
          "journal": "欧洲放射学杂志",
          "year": 2022,
          "cite": "Roditi G, Khan N, van der Molen AJ, et al. / 静脉对比剂外渗：系统评价及欧洲泌尿生殖放射学会对比剂安全委员会指南更新 / 欧洲放射学杂志 / 2022",
          "grade": "指南与共识",
          "ref": "R02"
        },
        {
          "type": "指南",
          "author": "中华护理学会放射介入护理专业委员会（执笔：张红梅、张素、刘宇）",
          "title": "含碘对比剂静脉外渗护理管理实践指南（2026年更新版）",
          "journal": "中华护理杂志",
          "year": 2026,
          "cite": "中华护理学会放射介入护理专业委员会（执笔：张红梅、张素、刘宇） / 含碘对比剂静脉外渗护理管理实践指南（2026年更新版） / 中华护理杂志 / 2026",
          "grade": "指南与共识",
          "ref": "R04"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "NPM_KeepCatheter",
      "name": "保留静脉留置针",
      "type": "NonPharmacologicalManagement",
      "tags": [
        "非药物管理"
      ],
      "aliases": [
        "keep catheter",
        "保留留置针",
        "回抽外渗药液"
      ],
      "summary": "先不拔针，尽量回抽漏出来的药液，再按规范处理。",
      "attrs": [],
      "evidence": [
        {
          "type": "指南",
          "author": "Roditi G, Khan N, van der Molen AJ, et al.",
          "title": "静脉对比剂外渗：系统评价及欧洲泌尿生殖放射学会对比剂安全委员会指南更新",
          "journal": "欧洲放射学杂志",
          "year": 2022,
          "cite": "Roditi G, Khan N, van der Molen AJ, et al. / 静脉对比剂外渗：系统评价及欧洲泌尿生殖放射学会对比剂安全委员会指南更新 / 欧洲放射学杂志 / 2022",
          "grade": "指南与共识",
          "ref": "R02"
        },
        {
          "type": "指南",
          "author": "中华护理学会放射介入护理专业委员会（执笔：张红梅、张素、刘宇）",
          "title": "含碘对比剂静脉外渗护理管理实践指南（2026年更新版）",
          "journal": "中华护理杂志",
          "year": 2026,
          "cite": "中华护理学会放射介入护理专业委员会（执笔：张红梅、张素、刘宇） / 含碘对比剂静脉外渗护理管理实践指南（2026年更新版） / 中华护理杂志 / 2026",
          "grade": "指南与共识",
          "ref": "R04"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "NPM_LimbElevation",
      "name": "患肢抬高",
      "type": "NonPharmacologicalManagement",
      "tags": [
        "非药物管理"
      ],
      "aliases": [
        "limb elevation",
        "抬高患肢",
        "患肢高于心脏水平"
      ],
      "summary": "把患肢抬到比心脏高的位置，帮助消肿。",
      "attrs": [],
      "evidence": [
        {
          "type": "指南",
          "author": "Roditi G, Khan N, van der Molen AJ, et al.",
          "title": "静脉对比剂外渗：系统评价及欧洲泌尿生殖放射学会对比剂安全委员会指南更新",
          "journal": "欧洲放射学杂志",
          "year": 2022,
          "cite": "Roditi G, Khan N, van der Molen AJ, et al. / 静脉对比剂外渗：系统评价及欧洲泌尿生殖放射学会对比剂安全委员会指南更新 / 欧洲放射学杂志 / 2022",
          "grade": "指南与共识",
          "ref": "R02"
        },
        {
          "type": "指南",
          "author": "中华护理学会放射介入护理专业委员会（执笔：张红梅、张素、刘宇）",
          "title": "含碘对比剂静脉外渗护理管理实践指南（2026年更新版）",
          "journal": "中华护理杂志",
          "year": 2026,
          "cite": "中华护理学会放射介入护理专业委员会（执笔：张红梅、张素、刘宇） / 含碘对比剂静脉外渗护理管理实践指南（2026年更新版） / 中华护理杂志 / 2026",
          "grade": "指南与共识",
          "ref": "R04"
        },
        {
          "type": "共识",
          "author": "中华医学会放射学分会放射护理专业委员会放射诊断护理学组（执笔：李雪、郑淑梅、屈梅香）",
          "title": "影像科碘对比剂输注安全专家共识",
          "journal": "介入放射学杂志",
          "year": 2018,
          "cite": "中华医学会放射学分会放射护理专业委员会放射诊断护理学组（执笔：李雪、郑淑梅、屈梅香） / 影像科碘对比剂输注安全专家共识 / 介入放射学杂志 / 2018",
          "grade": "指南与共识",
          "ref": "R07"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "NPM_ColdCompress",
      "name": "局部冷敷",
      "type": "NonPharmacologicalManagement",
      "tags": [
        "非药物管理"
      ],
      "aliases": [
        "cold compress",
        "冷敷"
      ],
      "summary": "外渗早期冷敷能减轻肿胀和疼痛。",
      "attrs": [],
      "evidence": [
        {
          "type": "指南",
          "author": "Roditi G, Khan N, van der Molen AJ, et al.",
          "title": "静脉对比剂外渗：系统评价及欧洲泌尿生殖放射学会对比剂安全委员会指南更新",
          "journal": "欧洲放射学杂志",
          "year": 2022,
          "cite": "Roditi G, Khan N, van der Molen AJ, et al. / 静脉对比剂外渗：系统评价及欧洲泌尿生殖放射学会对比剂安全委员会指南更新 / 欧洲放射学杂志 / 2022",
          "grade": "指南与共识",
          "ref": "R02"
        },
        {
          "type": "共识",
          "author": "中华医学会放射学分会放射护理专业委员会放射诊断护理学组（执笔：李雪、郑淑梅、屈梅香）",
          "title": "影像科碘对比剂输注安全专家共识",
          "journal": "介入放射学杂志",
          "year": 2018,
          "cite": "中华医学会放射学分会放射护理专业委员会放射诊断护理学组（执笔：李雪、郑淑梅、屈梅香） / 影像科碘对比剂输注安全专家共识 / 介入放射学杂志 / 2018",
          "grade": "指南与共识",
          "ref": "R07"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "NPM_CloseObservation",
      "name": "密切观察",
      "type": "NonPharmacologicalManagement",
      "tags": [
        "非药物管理"
      ],
      "aliases": [
        "close observation",
        "观察30分钟",
        "严密观察"
      ],
      "summary": "处置或用药之后至少观察一段时间，确认安全再离开。",
      "attrs": [],
      "evidence": [
        {
          "type": "共识",
          "author": "中华医学会放射学分会放射护理专业委员会放射诊断护理学组（执笔：李雪、郑淑梅、屈梅香）",
          "title": "影像科碘对比剂输注安全专家共识",
          "journal": "介入放射学杂志",
          "year": 2018,
          "cite": "中华医学会放射学分会放射护理专业委员会放射诊断护理学组（执笔：李雪、郑淑梅、屈梅香） / 影像科碘对比剂输注安全专家共识 / 介入放射学杂志 / 2018",
          "grade": "指南与共识",
          "ref": "R07"
        },
        {
          "type": "指南",
          "author": "美国放射学会药物与对比剂委员会",
          "title": "美国放射学会对比剂手册",
          "journal": "美国放射学会",
          "year": 2024,
          "cite": "美国放射学会药物与对比剂委员会 / 美国放射学会对比剂手册 / 美国放射学会 / 2024",
          "grade": "指南与共识",
          "ref": "R01"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "NPM_ContrastPreparation",
      "name": "对比剂预处理",
      "type": "NonPharmacologicalManagement",
      "tags": [
        "非药物管理"
      ],
      "aliases": [
        "contrast preparation",
        "对比剂加温",
        "预热对比剂"
      ],
      "summary": "把对比剂加温到 37℃ 左右再用。对高黏度对比剂可减少过敏/不适反应；现有 Meta 分析未证实能减少外渗。",
      "attrs": [],
      "evidence": [
        {
          "type": "指南",
          "author": "中华医学会放射学分会对比剂安全使用工作组",
          "title": "碘对比剂使用指南（第2版）",
          "journal": "中华放射学杂志",
          "year": 2013,
          "cite": "中华医学会放射学分会对比剂安全使用工作组 / 碘对比剂使用指南（第2版） / 中华放射学杂志 / 2013",
          "grade": "指南与共识",
          "ref": "R03"
        },
        {
          "type": "规范",
          "author": "江西省市场监督管理局",
          "title": "DB36/T 2299—2026 含碘对比剂静脉外渗预防与护理规范",
          "journal": "江西省市场监督管理局（地方标准）",
          "year": 2026,
          "cite": "江西省市场监督管理局 / DB36/T 2299—2026 含碘对比剂静脉外渗预防与护理规范 / 江西省市场监督管理局（地方标准） / 2026",
          "grade": "标准与规范",
          "ref": "R09"
        },
        {
          "type": "Meta分析",
          "author": "Nawras M, Alyousif Z, Beran A, Elsamaloty H",
          "title": "碘对比剂温度与不良反应的关系：307,329 次注射的 Meta 分析",
          "journal": "临床影像学",
          "year": 2023,
          "cite": "Nawras M, Alyousif Z, Beran A, Elsamaloty H / 碘对比剂温度与不良反应的关系：307,329 次注射的 Meta 分析 / 临床影像学 / 2023 · DOI 10.1016/j.clinimag.2023.05.006 · PMID 37216743"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "NPM_VascularVisualization",
      "name": "血管可视化",
      "type": "NonPharmacologicalManagement",
      "tags": [
        "非药物管理"
      ],
      "aliases": [
        "vascular visualization",
        "血管可视化技术",
        "超声引导穿刺"
      ],
      "summary": "看不清血管时，用超声等设备辅助定位再扎针。",
      "attrs": [],
      "evidence": [
        {
          "type": "标准",
          "author": "国家卫生健康委员会",
          "title": "WS/T 433—2023 静脉治疗护理技术操作标准",
          "journal": "国家卫生健康委员会（卫生行业标准）",
          "year": 2023,
          "cite": "国家卫生健康委员会 / WS/T 433—2023 静脉治疗护理技术操作标准 / 国家卫生健康委员会（卫生行业标准） / 2023",
          "grade": "标准与规范",
          "ref": "R08"
        },
        {
          "type": "指南",
          "author": "中华护理学会放射介入护理专业委员会（执笔：张红梅、张素、刘宇）",
          "title": "含碘对比剂静脉外渗护理管理实践指南（2026年更新版）",
          "journal": "中华护理杂志",
          "year": 2026,
          "cite": "中华护理学会放射介入护理专业委员会（执笔：张红梅、张素、刘宇） / 含碘对比剂静脉外渗护理管理实践指南（2026年更新版） / 中华护理杂志 / 2026",
          "grade": "指南与共识",
          "ref": "R04"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "NPM_PsychologicalSupport",
      "name": "心理疏导",
      "type": "NonPharmacologicalManagement",
      "tags": [
        "非药物管理"
      ],
      "aliases": [
        "psychological support",
        "心理护理",
        "安抚患者"
      ],
      "summary": "检查前后安抚情绪，减少紧张带来的不适。",
      "attrs": [],
      "evidence": [
        {
          "type": "书籍",
          "author": "秦月兰、郑淑梅、刘雪莲",
          "title": "影像护理学",
          "journal": "人民卫生出版社",
          "year": 2020,
          "cite": "秦月兰、郑淑梅、刘雪莲 / 影像护理学 / 人民卫生出版社 / 2020",
          "grade": "教材",
          "ref": "R20"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "MP_NursingMeasures",
      "name": "护理措施",
      "type": "ManagementPrinciple",
      "tags": [
        "处置原则"
      ],
      "aliases": [
        "nursing measures",
        "护理处置措施"
      ],
      "summary": "两类风险（碘对比剂过敏反应、碘对比剂外渗）的护理处置总纲。下分两条原则：外渗处置原则（外渗之后的处理顺序与操作边界）、不良反应分级处置原则（按轻重分级决定用药、监护与是否转诊）。",
      "attrs": [],
      "evidence": [
        {
          "type": "指南",
          "author": "中华护理学会放射介入护理专业委员会（执笔：张红梅、张素、刘宇）",
          "title": "含碘对比剂静脉外渗护理管理实践指南（2026年更新版）",
          "journal": "中华护理杂志",
          "year": 2026,
          "cite": "中华护理学会放射介入护理专业委员会（执笔：张红梅、张素、刘宇） / 含碘对比剂静脉外渗护理管理实践指南（2026年更新版） / 中华护理杂志 / 2026",
          "grade": "指南与共识",
          "ref": "R04"
        },
        {
          "type": "共识",
          "author": "中华医学会放射学分会放射护理专业委员会放射诊断护理学组（执笔：李雪、郑淑梅、屈梅香）",
          "title": "影像科碘对比剂输注安全专家共识",
          "journal": "介入放射学杂志",
          "year": 2018,
          "cite": "中华医学会放射学分会放射护理专业委员会放射诊断护理学组（执笔：李雪、郑淑梅、屈梅香） / 影像科碘对比剂输注安全专家共识 / 介入放射学杂志 / 2018",
          "grade": "指南与共识",
          "ref": "R07"
        },
        {
          "type": "指南",
          "author": "美国放射学会药物与对比剂委员会",
          "title": "美国放射学会对比剂手册",
          "journal": "美国放射学会",
          "year": 2024,
          "cite": "美国放射学会药物与对比剂委员会 / 美国放射学会对比剂手册 / 美国放射学会 / 2024",
          "grade": "指南与共识",
          "ref": "R01"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "MP_NursingPrevention",
      "name": "护理预防",
      "type": "ManagementPrinciple",
      "tags": [
        "预防性护理"
      ],
      "aliases": [
        "nursing prevention",
        "预防性护理"
      ],
      "summary": "打药之前把风险挡掉的护理原则：核对过敏史、评估血管条件与外渗高危因素、避免高压注射与不做生理盐水试推、看不清血管时用血管可视化辅助定位，以及对比剂预处理（加温到 37℃ 左右）。",
      "attrs": [],
      "evidence": [
        {
          "type": "指南",
          "author": "中华护理学会放射介入护理专业委员会（执笔：张红梅、张素、刘宇）",
          "title": "含碘对比剂静脉外渗护理管理实践指南（2026年更新版）",
          "journal": "中华护理杂志",
          "year": 2026,
          "cite": "中华护理学会放射介入护理专业委员会（执笔：张红梅、张素、刘宇） / 含碘对比剂静脉外渗护理管理实践指南（2026年更新版） / 中华护理杂志 / 2026",
          "grade": "指南与共识",
          "ref": "R04"
        },
        {
          "type": "规范",
          "author": "江西省市场监督管理局",
          "title": "DB36/T 2299—2026 含碘对比剂静脉外渗预防与护理规范",
          "journal": "江西省市场监督管理局（地方标准）",
          "year": 2026,
          "cite": "江西省市场监督管理局 / DB36/T 2299—2026 含碘对比剂静脉外渗预防与护理规范 / 江西省市场监督管理局（地方标准） / 2026",
          "grade": "标准与规范",
          "ref": "R09"
        },
        {
          "type": "指南",
          "author": "Roditi G, Khan N, van der Molen AJ, et al.",
          "title": "静脉对比剂外渗：系统评价及欧洲泌尿生殖放射学会对比剂安全委员会指南更新",
          "journal": "欧洲放射学杂志",
          "year": 2022,
          "cite": "Roditi G, Khan N, van der Molen AJ, et al. / 静脉对比剂外渗：系统评价及欧洲泌尿生殖放射学会对比剂安全委员会指南更新 / 欧洲放射学杂志 / 2022",
          "grade": "指南与共识",
          "ref": "R02"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "MP_NursingIntervention",
      "name": "护理干预",
      "type": "ManagementPrinciple",
      "tags": [
        "应急干预"
      ],
      "aliases": [
        "nursing intervention",
        "干预性护理"
      ],
      "summary": "反应已经发生之后的现场护理干预原则：按分级处置原则用药与监护，处置后密切观察；情况变坏之前先看出苗头、及时升级处理（早期预警）。",
      "attrs": [],
      "evidence": [
        {
          "type": "指南",
          "author": "中华护理学会放射介入护理专业委员会（执笔：张红梅、张素、刘宇）",
          "title": "含碘对比剂静脉外渗护理管理实践指南（2026年更新版）",
          "journal": "中华护理杂志",
          "year": 2026,
          "cite": "中华护理学会放射介入护理专业委员会（执笔：张红梅、张素、刘宇） / 含碘对比剂静脉外渗护理管理实践指南（2026年更新版） / 中华护理杂志 / 2026",
          "grade": "指南与共识",
          "ref": "R04"
        },
        {
          "type": "推荐实践",
          "author": "Golden DBK, Wang J, Waserman S, et al.",
          "title": "过敏反应：2023 年实践参数更新",
          "journal": "变态反应、哮喘与免疫学年鉴",
          "year": 2024,
          "cite": "Golden DBK, Wang J, Waserman S, et al. / 过敏反应：2023 年实践参数更新 / 变态反应、哮喘与免疫学年鉴 / 2024",
          "grade": "推荐意见",
          "ref": "R16"
        },
        {
          "type": "指南",
          "author": "Roditi G, Khan N, van der Molen AJ, et al.",
          "title": "静脉对比剂外渗：系统评价及欧洲泌尿生殖放射学会对比剂安全委员会指南更新",
          "journal": "欧洲放射学杂志",
          "year": 2022,
          "cite": "Roditi G, Khan N, van der Molen AJ, et al. / 静脉对比剂外渗：系统评价及欧洲泌尿生殖放射学会对比剂安全委员会指南更新 / 欧洲放射学杂志 / 2022",
          "grade": "指南与共识",
          "ref": "R02"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "MP_ExtravasationPrinciple",
      "name": "外渗处置原则",
      "type": "ManagementPrinciple",
      "tags": [
        "外渗处置"
      ],
      "aliases": [
        "extravasation management principle",
        "外渗处理原则"
      ],
      "summary": "外渗之后的处理顺序与操作边界。",
      "attrs": [],
      "evidence": [
        {
          "type": "指南",
          "author": "Roditi G, Khan N, van der Molen AJ, et al.",
          "title": "静脉对比剂外渗：系统评价及欧洲泌尿生殖放射学会对比剂安全委员会指南更新",
          "journal": "欧洲放射学杂志",
          "year": 2022,
          "cite": "Roditi G, Khan N, van der Molen AJ, et al. / 静脉对比剂外渗：系统评价及欧洲泌尿生殖放射学会对比剂安全委员会指南更新 / 欧洲放射学杂志 / 2022",
          "grade": "指南与共识",
          "ref": "R02"
        },
        {
          "type": "指南",
          "author": "中华护理学会放射介入护理专业委员会（执笔：张红梅、张素、刘宇）",
          "title": "含碘对比剂静脉外渗护理管理实践指南（2026年更新版）",
          "journal": "中华护理杂志",
          "year": 2026,
          "cite": "中华护理学会放射介入护理专业委员会（执笔：张红梅、张素、刘宇） / 含碘对比剂静脉外渗护理管理实践指南（2026年更新版） / 中华护理杂志 / 2026",
          "grade": "指南与共识",
          "ref": "R04"
        },
        {
          "type": "共识",
          "author": "中华医学会放射学分会放射护理专业委员会放射诊断护理学组（执笔：李雪、郑淑梅、屈梅香）",
          "title": "影像科碘对比剂输注安全专家共识",
          "journal": "介入放射学杂志",
          "year": 2018,
          "cite": "中华医学会放射学分会放射护理专业委员会放射诊断护理学组（执笔：李雪、郑淑梅、屈梅香） / 影像科碘对比剂输注安全专家共识 / 介入放射学杂志 / 2018",
          "grade": "指南与共识",
          "ref": "R07"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "MP_AdverseReactionTriage",
      "name": "不良反应分级处置原则",
      "type": "ManagementPrinciple",
      "tags": [
        "分级处置"
      ],
      "aliases": [
        "adverse reaction triage",
        "不良反应分级处置"
      ],
      "summary": "按轻重分级决定用药、监护与是否转诊的处置原则。",
      "attrs": [],
      "evidence": [
        {
          "type": "声明",
          "author": "Wang C, Ramsey A, Lang D, et al.",
          "title": "放射性对比剂超敏反应的管理与预防：美国放射学会与美国变态反应、哮喘与免疫学会共识声明",
          "journal": "放射学",
          "year": 2025,
          "cite": "Wang C, Ramsey A, Lang D, et al. / 放射性对比剂超敏反应的管理与预防：美国放射学会与美国变态反应、哮喘与免疫学会共识声明 / 放射学 / 2025",
          "grade": "学会声明",
          "ref": "R12"
        },
        {
          "type": "建议",
          "author": "Brockow K",
          "title": "放射性对比剂超敏反应处理流程（2024 年更新）",
          "journal": "变态反应",
          "year": 2024,
          "cite": "Brockow K / 放射性对比剂超敏反应处理流程（2024 年更新） / 变态反应 / 2024",
          "grade": "推荐意见",
          "ref": "R13"
        },
        {
          "type": "指南",
          "author": "美国放射学会药物与对比剂委员会",
          "title": "美国放射学会对比剂手册",
          "journal": "美国放射学会",
          "year": 2024,
          "cite": "美国放射学会药物与对比剂委员会 / 美国放射学会对比剂手册 / 美国放射学会 / 2024",
          "grade": "指南与共识",
          "ref": "R01"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "NT_EarlyWarning",
      "name": "早期预警",
      "type": "NursingTheory",
      "tags": [
        "护理理论"
      ],
      "aliases": [
        "early warning",
        "早期识别与预警"
      ],
      "summary": "在情况变坏之前先看出苗头、及时升级处理 —— 过敏反应与外渗的现场护理干预里，「早发现、早升级」是防住重症的第一道关口。",
      "attrs": [],
      "evidence": [
        {
          "type": "建议",
          "author": "Brockow K",
          "title": "放射性对比剂超敏反应处理流程（2024 年更新）",
          "journal": "变态反应",
          "year": 2024,
          "cite": "Brockow K / 放射性对比剂超敏反应处理流程（2024 年更新） / 变态反应 / 2024",
          "grade": "推荐意见",
          "ref": "R13"
        },
        {
          "type": "推荐实践",
          "author": "Golden DBK, Wang J, Waserman S, et al.",
          "title": "过敏反应：2023 年实践参数更新",
          "journal": "变态反应、哮喘与免疫学年鉴",
          "year": 2024,
          "cite": "Golden DBK, Wang J, Waserman S, et al. / 过敏反应：2023 年实践参数更新 / 变态反应、哮喘与免疫学年鉴 / 2024",
          "grade": "推荐意见",
          "ref": "R16"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "DE_PreExamNotice",
      "name": "检查前注意事项科普",
      "type": "DiseaseEducation",
      "tags": [
        "疾病科普"
      ],
      "aliases": [
        "pre-examination notice",
        "检查前宣教",
        "增强CT检查前须知",
        "iodine contrast agent",
        "碘对比剂"
      ],
      "summary": "告诉患者检查前该做什么、该跟医生说什么。",
      "attrs": [],
      "evidence": [
        {
          "type": "指南",
          "author": "中华医学会放射学分会对比剂安全使用工作组",
          "title": "碘对比剂使用指南（第2版）",
          "journal": "中华放射学杂志",
          "year": 2013,
          "cite": "中华医学会放射学分会对比剂安全使用工作组 / 碘对比剂使用指南（第2版） / 中华放射学杂志 / 2013",
          "grade": "指南与共识",
          "ref": "R03"
        },
        {
          "type": "书籍",
          "author": "秦月兰、郑淑梅、刘雪莲",
          "title": "影像护理学",
          "journal": "人民卫生出版社",
          "year": 2020,
          "cite": "秦月兰、郑淑梅、刘雪莲 / 影像护理学 / 人民卫生出版社 / 2020",
          "grade": "教材",
          "ref": "R20"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "DE_AfterExamCare",
      "name": "检查后观察与护理科普",
      "type": "DiseaseEducation",
      "tags": [
        "疾病科普"
      ],
      "aliases": [
        "after examination care",
        "检查后宣教",
        "增强CT检查后须知"
      ],
      "summary": "告诉患者检查以后怎么观察、多久能回家、怎么补水。",
      "attrs": [],
      "evidence": [
        {
          "type": "指南",
          "author": "美国放射学会药物与对比剂委员会",
          "title": "美国放射学会对比剂手册",
          "journal": "美国放射学会",
          "year": 2024,
          "cite": "美国放射学会药物与对比剂委员会 / 美国放射学会对比剂手册 / 美国放射学会 / 2024",
          "grade": "指南与共识",
          "ref": "R01"
        },
        {
          "type": "共识",
          "author": "中华医学会放射学分会放射护理专业委员会放射诊断护理学组（执笔：李雪、郑淑梅、屈梅香）",
          "title": "影像科碘对比剂输注安全专家共识",
          "journal": "介入放射学杂志",
          "year": 2018,
          "cite": "中华医学会放射学分会放射护理专业委员会放射诊断护理学组（执笔：李雪、郑淑梅、屈梅香） / 影像科碘对比剂输注安全专家共识 / 介入放射学杂志 / 2018",
          "grade": "指南与共识",
          "ref": "R07"
        },
        {
          "type": "书籍",
          "author": "秦月兰、郑淑梅、刘雪莲",
          "title": "影像护理学",
          "journal": "人民卫生出版社",
          "year": 2020,
          "cite": "秦月兰、郑淑梅、刘雪莲 / 影像护理学 / 人民卫生出版社 / 2020",
          "grade": "教材",
          "ref": "R20"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "DE_AllergyDisclosure",
      "name": "过敏史告知科普",
      "type": "DiseaseEducation",
      "tags": [
        "疾病科普"
      ],
      "aliases": [
        "allergy disclosure",
        "过敏史告知",
        "过敏史说明"
      ],
      "summary": "告诉患者为什么一定要如实说自己的过敏史。",
      "attrs": [],
      "evidence": [
        {
          "type": "声明",
          "author": "Wang C, Ramsey A, Lang D, et al.",
          "title": "放射性对比剂超敏反应的管理与预防：美国放射学会与美国变态反应、哮喘与免疫学会共识声明",
          "journal": "放射学",
          "year": 2025,
          "cite": "Wang C, Ramsey A, Lang D, et al. / 放射性对比剂超敏反应的管理与预防：美国放射学会与美国变态反应、哮喘与免疫学会共识声明 / 放射学 / 2025",
          "grade": "学会声明",
          "ref": "R12"
        },
        {
          "type": "指南",
          "author": "中华医学会放射学分会对比剂安全使用工作组",
          "title": "碘对比剂使用指南（第2版）",
          "journal": "中华放射学杂志",
          "year": 2013,
          "cite": "中华医学会放射学分会对比剂安全使用工作组 / 碘对比剂使用指南（第2版） / 中华放射学杂志 / 2013",
          "grade": "指南与共识",
          "ref": "R03"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "DE_ExtravasationHomeCare",
      "name": "外渗居家护理科普",
      "type": "DiseaseEducation",
      "tags": [
        "疾病科普"
      ],
      "aliases": [
        "extravasation home care",
        "外渗后居家护理"
      ],
      "summary": "告诉患者回家以后怎么观察患肢、什么时候必须回医院。",
      "attrs": [],
      "evidence": [
        {
          "type": "指南",
          "author": "中华护理学会放射介入护理专业委员会（执笔：张红梅、张素、刘宇）",
          "title": "含碘对比剂静脉外渗护理管理实践指南（2026年更新版）",
          "journal": "中华护理杂志",
          "year": 2026,
          "cite": "中华护理学会放射介入护理专业委员会（执笔：张红梅、张素、刘宇） / 含碘对比剂静脉外渗护理管理实践指南（2026年更新版） / 中华护理杂志 / 2026",
          "grade": "指南与共识",
          "ref": "R04"
        },
        {
          "type": "指南",
          "author": "Roditi G, Khan N, van der Molen AJ, et al.",
          "title": "静脉对比剂外渗：系统评价及欧洲泌尿生殖放射学会对比剂安全委员会指南更新",
          "journal": "欧洲放射学杂志",
          "year": 2022,
          "cite": "Roditi G, Khan N, van der Molen AJ, et al. / 静脉对比剂外渗：系统评价及欧洲泌尿生殖放射学会对比剂安全委员会指南更新 / 欧洲放射学杂志 / 2022",
          "grade": "指南与共识",
          "ref": "R02"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "DE_EmergencyKnowledge",
      "name": "急救知识科普",
      "type": "DiseaseEducation",
      "tags": [
        "疾病科普"
      ],
      "aliases": [
        "emergency knowledge",
        "急救知识",
        "自救与呼救"
      ],
      "summary": "告诉患者出现严重反应时立刻该做什么、怎么呼救。",
      "attrs": [],
      "evidence": [
        {
          "type": "推荐实践",
          "author": "Golden DBK, Wang J, Waserman S, et al.",
          "title": "过敏反应：2023 年实践参数更新",
          "journal": "变态反应、哮喘与免疫学年鉴",
          "year": 2024,
          "cite": "Golden DBK, Wang J, Waserman S, et al. / 过敏反应：2023 年实践参数更新 / 变态反应、哮喘与免疫学年鉴 / 2024",
          "grade": "推荐意见",
          "ref": "R16"
        },
        {
          "type": "建议",
          "author": "Brockow K",
          "title": "放射性对比剂超敏反应处理流程（2024 年更新）",
          "journal": "变态反应",
          "year": 2024,
          "cite": "Brockow K / 放射性对比剂超敏反应处理流程（2024 年更新） / 变态反应 / 2024",
          "grade": "推荐意见",
          "ref": "R13"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "SS_MildResolved",
      "name": "轻度反应已缓解",
      "type": "SymptomStatus",
      "tags": [
        "症状状态"
      ],
      "aliases": [
        "mild reaction resolved",
        "轻度已缓解"
      ],
      "summary": "轻度反应经过处理以后症状消退。",
      "attrs": [],
      "evidence": [
        {
          "type": "声明",
          "author": "Wang C, Ramsey A, Lang D, et al.",
          "title": "放射性对比剂超敏反应的管理与预防：美国放射学会与美国变态反应、哮喘与免疫学会共识声明",
          "journal": "放射学",
          "year": 2025,
          "cite": "Wang C, Ramsey A, Lang D, et al. / 放射性对比剂超敏反应的管理与预防：美国放射学会与美国变态反应、哮喘与免疫学会共识声明 / 放射学 / 2025",
          "grade": "学会声明",
          "ref": "R12"
        },
        {
          "type": "共识",
          "author": "中华医学会放射学分会放射护理专业委员会放射诊断护理学组（执笔：李雪、郑淑梅、屈梅香）",
          "title": "影像科碘对比剂输注安全专家共识",
          "journal": "介入放射学杂志",
          "year": 2018,
          "cite": "中华医学会放射学分会放射护理专业委员会放射诊断护理学组（执笔：李雪、郑淑梅、屈梅香） / 影像科碘对比剂输注安全专家共识 / 介入放射学杂志 / 2018",
          "grade": "指南与共识",
          "ref": "R07"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "SS_SevereRecovered",
      "name": "重度反应已恢复",
      "type": "SymptomStatus",
      "tags": [
        "症状状态"
      ],
      "aliases": [
        "severe reaction recovered",
        "重度已恢复"
      ],
      "summary": "重度反应经抢救以后生命体征恢复稳定。",
      "attrs": [],
      "evidence": [
        {
          "type": "推荐实践",
          "author": "Golden DBK, Wang J, Waserman S, et al.",
          "title": "过敏反应：2023 年实践参数更新",
          "journal": "变态反应、哮喘与免疫学年鉴",
          "year": 2024,
          "cite": "Golden DBK, Wang J, Waserman S, et al. / 过敏反应：2023 年实践参数更新 / 变态反应、哮喘与免疫学年鉴 / 2024",
          "grade": "推荐意见",
          "ref": "R16"
        },
        {
          "type": "建议",
          "author": "Brockow K",
          "title": "放射性对比剂超敏反应处理流程（2024 年更新）",
          "journal": "变态反应",
          "year": 2024,
          "cite": "Brockow K / 放射性对比剂超敏反应处理流程（2024 年更新） / 变态反应 / 2024",
          "grade": "推荐意见",
          "ref": "R13"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "FS_LimbFunction",
      "name": "患肢功能状态",
      "type": "FunctionalStatus",
      "tags": [
        "功能状态"
      ],
      "aliases": [
        "limb function",
        "患肢功能",
        "肢体功能状况"
      ],
      "summary": "外渗处理以后患肢能不能正常活动、感觉有没有恢复。",
      "attrs": [],
      "evidence": [
        {
          "type": "指南",
          "author": "中华护理学会放射介入护理专业委员会（执笔：张红梅、张素、刘宇）",
          "title": "含碘对比剂静脉外渗护理管理实践指南（2026年更新版）",
          "journal": "中华护理杂志",
          "year": 2026,
          "cite": "中华护理学会放射介入护理专业委员会（执笔：张红梅、张素、刘宇） / 含碘对比剂静脉外渗护理管理实践指南（2026年更新版） / 中华护理杂志 / 2026",
          "grade": "指南与共识",
          "ref": "R04"
        },
        {
          "type": "指南",
          "author": "Roditi G, Khan N, van der Molen AJ, et al.",
          "title": "静脉对比剂外渗：系统评价及欧洲泌尿生殖放射学会对比剂安全委员会指南更新",
          "journal": "欧洲放射学杂志",
          "year": 2022,
          "cite": "Roditi G, Khan N, van der Molen AJ, et al. / 静脉对比剂外渗：系统评价及欧洲泌尿生殖放射学会对比剂安全委员会指南更新 / 欧洲放射学杂志 / 2022",
          "grade": "指南与共识",
          "ref": "R02"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "R01",
      "name": "美国放射学会对比剂手册",
      "type": "Reference",
      "tags": [
        "文献",
        "指南"
      ],
      "aliases": [
        "ACR Manual on Contrast Media",
        "ACR 对比剂手册",
        "美国放射学会对比剂手册",
        "指南",
        "guideline",
        "guidelines"
      ],
      "summary": "美国放射学会每年更新的对比剂使用手册，是这份图谱里对比剂安全使用的主干依据。",
      "attrs": [
        {
          "k": "文献类型",
          "v": "指南"
        },
        {
          "k": "年份",
          "v": "2024"
        },
        {
          "k": "核验标识",
          "v": "https://www.acr.org/clinical-resources/contrast-manual（官方在线版 · 2024 年版）"
        },
        {
          "k": "证据等级",
          "v": "指南与共识"
        }
      ],
      "evidence": [
        {
          "type": "指南",
          "author": "美国放射学会药物与对比剂委员会",
          "title": "美国放射学会对比剂手册",
          "journal": "美国放射学会",
          "year": 2024,
          "cite": "美国放射学会药物与对比剂委员会 / 美国放射学会对比剂手册 / 美国放射学会 / 2024",
          "grade": "指南与共识",
          "ref": "R01"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "R02",
      "name": "静脉对比剂外渗：系统评价及欧洲泌尿生殖放射学会对比剂安全委员会指南更新",
      "type": "Reference",
      "tags": [
        "文献",
        "指南"
      ],
      "aliases": [
        "ESUR 对比剂外渗指南",
        "欧洲泌尿放射学会外渗指南",
        "指南",
        "guideline",
        "guidelines"
      ],
      "summary": "欧洲泌尿放射学会对比剂安全委员会关于静脉外渗的系统评价与处理指南。",
      "attrs": [
        {
          "k": "文献类型",
          "v": "指南"
        },
        {
          "k": "年份",
          "v": "2022"
        },
        {
          "k": "核验标识",
          "v": "DOI 10.1007/s00330-021-08433-4 · PMID 35175378 · 2022;32(5):3056-3066"
        },
        {
          "k": "证据等级",
          "v": "指南与共识"
        }
      ],
      "evidence": [
        {
          "type": "指南",
          "author": "Roditi G, Khan N, van der Molen AJ, et al.",
          "title": "静脉对比剂外渗：系统评价及欧洲泌尿生殖放射学会对比剂安全委员会指南更新",
          "journal": "欧洲放射学杂志",
          "year": 2022,
          "cite": "Roditi G, Khan N, van der Molen AJ, et al. / 静脉对比剂外渗：系统评价及欧洲泌尿生殖放射学会对比剂安全委员会指南更新 / 欧洲放射学杂志 / 2022",
          "grade": "指南与共识",
          "ref": "R02"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "R03",
      "name": "碘对比剂使用指南（第2版）",
      "type": "Reference",
      "tags": [
        "文献",
        "指南"
      ],
      "aliases": [
        "碘对比剂使用指南",
        "碘对比剂使用指南第2版",
        "对比剂使用指南第2版",
        "指南",
        "guideline",
        "guidelines",
        "CT指南",
        "CT增强指南"
      ],
      "summary": "我国放射学界关于碘对比剂怎么选、怎么用、怎么防反应的基础文件。",
      "attrs": [
        {
          "k": "文献类型",
          "v": "指南"
        },
        {
          "k": "年份",
          "v": "2013"
        },
        {
          "k": "核验标识",
          "v": "DOI 10.3760/cma.j.issn.1005-1201.2013.10.001 · 中华医学期刊全文数据库 rs.yiigle.com/cmaid/733764"
        },
        {
          "k": "证据等级",
          "v": "指南与共识"
        }
      ],
      "evidence": [
        {
          "type": "指南",
          "author": "中华医学会放射学分会对比剂安全使用工作组",
          "title": "碘对比剂使用指南（第2版）",
          "journal": "中华放射学杂志",
          "year": 2013,
          "cite": "中华医学会放射学分会对比剂安全使用工作组 / 碘对比剂使用指南（第2版） / 中华放射学杂志 / 2013",
          "grade": "指南与共识",
          "ref": "R03"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "R04",
      "name": "含碘对比剂静脉外渗护理管理实践指南（2026年更新版）",
      "type": "Reference",
      "tags": [
        "文献",
        "指南"
      ],
      "aliases": [
        "含碘对比剂静脉外渗护理管理实践指南",
        "外渗护理管理实践指南 2026",
        "指南",
        "guideline",
        "guidelines"
      ],
      "summary": "中华护理学会最新一版外渗护理实践指南，是外渗预防与处理的操作蓝本。",
      "attrs": [
        {
          "k": "文献类型",
          "v": "指南"
        },
        {
          "k": "年份",
          "v": "2026"
        },
        {
          "k": "核验标识",
          "v": "DOI 10.3761/j.issn.0254-1769.2026.15.006 · 2026;61(15):2054-2060"
        },
        {
          "k": "证据等级",
          "v": "指南与共识"
        }
      ],
      "evidence": [
        {
          "type": "指南",
          "author": "中华护理学会放射介入护理专业委员会（执笔：张红梅、张素、刘宇）",
          "title": "含碘对比剂静脉外渗护理管理实践指南（2026年更新版）",
          "journal": "中华护理杂志",
          "year": 2026,
          "cite": "中华护理学会放射介入护理专业委员会（执笔：张红梅、张素、刘宇） / 含碘对比剂静脉外渗护理管理实践指南（2026年更新版） / 中华护理杂志 / 2026",
          "grade": "指南与共识",
          "ref": "R04"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "R07",
      "name": "影像科碘对比剂输注安全专家共识",
      "type": "Reference",
      "tags": [
        "文献",
        "共识"
      ],
      "aliases": [
        "影像科碘对比剂输注安全专家共识",
        "输注安全专家共识",
        "共识",
        "consensus"
      ],
      "summary": "讲输药前后每一步怎么做、出了事怎么处理的第一份护理共识。",
      "attrs": [
        {
          "k": "文献类型",
          "v": "共识"
        },
        {
          "k": "年份",
          "v": "2018"
        },
        {
          "k": "核验标识",
          "v": "DOI 10.3969/j.issn.1008-794X.2018.08.001 · 2018;27(8):707-712"
        },
        {
          "k": "证据等级",
          "v": "指南与共识"
        }
      ],
      "evidence": [
        {
          "type": "共识",
          "author": "中华医学会放射学分会放射护理专业委员会放射诊断护理学组（执笔：李雪、郑淑梅、屈梅香）",
          "title": "影像科碘对比剂输注安全专家共识",
          "journal": "介入放射学杂志",
          "year": 2018,
          "cite": "中华医学会放射学分会放射护理专业委员会放射诊断护理学组（执笔：李雪、郑淑梅、屈梅香） / 影像科碘对比剂输注安全专家共识 / 介入放射学杂志 / 2018",
          "grade": "指南与共识",
          "ref": "R07"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "R08",
      "name": "WS/T 433—2023 静脉治疗护理技术操作标准",
      "type": "Reference",
      "tags": [
        "文献",
        "标准"
      ],
      "aliases": [
        "静脉治疗护理技术操作标准",
        "WS/T 433-2023",
        "静脉治疗护理技术操作标准 2023",
        "标准",
        "standard"
      ],
      "summary": "全国静脉治疗的操作标准：怎么选管、怎么穿刺、怎么管并发症。",
      "attrs": [
        {
          "k": "文献类型",
          "v": "标准"
        },
        {
          "k": "年份",
          "v": "2023"
        },
        {
          "k": "核验标识",
          "v": "国卫通〔2023〕9号 · nhc.gov.cn/wjw/pjl/202309/d09188781db944f8936728280cba4759.shtml"
        },
        {
          "k": "证据等级",
          "v": "标准与规范"
        }
      ],
      "evidence": [
        {
          "type": "标准",
          "author": "国家卫生健康委员会",
          "title": "WS/T 433—2023 静脉治疗护理技术操作标准",
          "journal": "国家卫生健康委员会（卫生行业标准）",
          "year": 2023,
          "cite": "国家卫生健康委员会 / WS/T 433—2023 静脉治疗护理技术操作标准 / 国家卫生健康委员会（卫生行业标准） / 2023",
          "grade": "标准与规范",
          "ref": "R08"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "R09",
      "name": "DB36/T 2299—2026 含碘对比剂静脉外渗预防与护理规范",
      "type": "Reference",
      "tags": [
        "文献",
        "规范"
      ],
      "aliases": [
        "含碘对比剂静脉外渗预防与护理规范",
        "DB36/T 2299-2026",
        "规范",
        "specification"
      ],
      "summary": "把外渗预防与护理写成地方标准的地方文件，步骤写得很细。",
      "attrs": [
        {
          "k": "文献类型",
          "v": "规范"
        },
        {
          "k": "年份",
          "v": "2026"
        },
        {
          "k": "核验标识",
          "v": "全国标准信息公共服务平台 std.samr.gov.cn · 备案号 131428-2026 · 2026-09-12 发布 / 2027-04-01 实施"
        },
        {
          "k": "证据等级",
          "v": "标准与规范"
        }
      ],
      "evidence": [
        {
          "type": "规范",
          "author": "江西省市场监督管理局",
          "title": "DB36/T 2299—2026 含碘对比剂静脉外渗预防与护理规范",
          "journal": "江西省市场监督管理局（地方标准）",
          "year": 2026,
          "cite": "江西省市场监督管理局 / DB36/T 2299—2026 含碘对比剂静脉外渗预防与护理规范 / 江西省市场监督管理局（地方标准） / 2026",
          "grade": "标准与规范",
          "ref": "R09"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "R10",
      "name": "DB45/T 2935—2024 CT增强扫描碘对比剂外渗预防与护理规范",
      "type": "Reference",
      "tags": [
        "文献",
        "规范"
      ],
      "aliases": [
        "CT增强扫描碘对比剂外渗预防与护理规范",
        "DB45/T 2935-2024",
        "规范",
        "specification"
      ],
      "summary": "专门针对 CT 增强场景的外渗预防与护理地方规范。",
      "attrs": [
        {
          "k": "文献类型",
          "v": "规范"
        },
        {
          "k": "年份",
          "v": "2024"
        },
        {
          "k": "核验标识",
          "v": "全国标准信息公共服务平台 dbba.sacinfo.org.cn · 2024-11-14 发布 / 2025-02-01 实施"
        },
        {
          "k": "证据等级",
          "v": "标准与规范"
        }
      ],
      "evidence": [
        {
          "type": "规范",
          "author": "广西壮族自治区市场监督管理局",
          "title": "DB45/T 2935—2024 CT增强扫描碘对比剂外渗预防与护理规范",
          "journal": "广西壮族自治区市场监督管理局（地方标准）",
          "year": 2024,
          "cite": "广西壮族自治区市场监督管理局 / DB45/T 2935—2024 CT增强扫描碘对比剂外渗预防与护理规范 / 广西壮族自治区市场监督管理局（地方标准） / 2024",
          "grade": "标准与规范",
          "ref": "R10"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "R12",
      "name": "放射性对比剂超敏反应的管理与预防：美国放射学会与美国变态反应、哮喘与免疫学会共识声明",
      "type": "Reference",
      "tags": [
        "文献",
        "声明"
      ],
      "aliases": [
        "ACR-AAAAI 对比剂过敏反应声明",
        "对比剂过敏反应学会声明",
        "声明",
        "statement"
      ],
      "summary": "两个学会联合发布的过敏反应防治声明，是国际上最新的对比剂过敏处理口径。",
      "attrs": [
        {
          "k": "文献类型",
          "v": "声明"
        },
        {
          "k": "年份",
          "v": "2025"
        },
        {
          "k": "核验标识",
          "v": "DOI 10.1148/radiol.240100 · PMID 40326871 · 2025;315(2):e240100"
        },
        {
          "k": "证据等级",
          "v": "学会声明"
        }
      ],
      "evidence": [
        {
          "type": "声明",
          "author": "Wang C, Ramsey A, Lang D, et al.",
          "title": "放射性对比剂超敏反应的管理与预防：美国放射学会与美国变态反应、哮喘与免疫学会共识声明",
          "journal": "放射学",
          "year": 2025,
          "cite": "Wang C, Ramsey A, Lang D, et al. / 放射性对比剂超敏反应的管理与预防：美国放射学会与美国变态反应、哮喘与免疫学会共识声明 / 放射学 / 2025",
          "grade": "学会声明",
          "ref": "R12"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "R13",
      "name": "放射性对比剂超敏反应处理流程（2024 年更新）",
      "type": "Reference",
      "tags": [
        "文献",
        "建议"
      ],
      "aliases": [
        "对比剂过敏反应管理算法 2024",
        "radiocontrast hypersensitivity algorithm",
        "建议",
        "advice"
      ],
      "summary": "把对比剂过敏反应分成轻中重、并给出逐级处理路径的算法文件。",
      "attrs": [
        {
          "k": "文献类型",
          "v": "建议"
        },
        {
          "k": "年份",
          "v": "2024"
        },
        {
          "k": "核验标识",
          "v": "DOI 10.1111/all.16191 · PMID 38887890 · 2024;79(9):2570-2572"
        },
        {
          "k": "证据等级",
          "v": "推荐意见"
        }
      ],
      "evidence": [
        {
          "type": "建议",
          "author": "Brockow K",
          "title": "放射性对比剂超敏反应处理流程（2024 年更新）",
          "journal": "变态反应",
          "year": 2024,
          "cite": "Brockow K / 放射性对比剂超敏反应处理流程（2024 年更新） / 变态反应 / 2024",
          "grade": "推荐意见",
          "ref": "R13"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "R14",
      "name": "对比剂超敏反应实践指南（加拿大放射医师协会与加拿大过敏与临床免疫学会）",
      "type": "Reference",
      "tags": [
        "文献",
        "建议"
      ],
      "aliases": [
        "CAR-CSACI 对比剂过敏实践指导",
        "对比剂过敏实践指导",
        "建议",
        "advice"
      ],
      "summary": "加拿大放射学会与变态反应学会给出的对比剂过敏实践指导。",
      "attrs": [
        {
          "k": "文献类型",
          "v": "建议"
        },
        {
          "k": "年份",
          "v": "2025"
        },
        {
          "k": "核验标识",
          "v": "DOI 10.1177/08465371241311253 · PMID 39797723 · 2025;76(3):400-416"
        },
        {
          "k": "证据等级",
          "v": "推荐意见"
        }
      ],
      "evidence": [
        {
          "type": "建议",
          "author": "Byrne A, Macdonald DB, Kirkpatrick IDC, et al.",
          "title": "对比剂超敏反应实践指南（加拿大放射医师协会与加拿大过敏与临床免疫学会）",
          "journal": "加拿大放射医师协会杂志",
          "year": 2025,
          "cite": "Byrne A, Macdonald DB, Kirkpatrick IDC, et al. / 对比剂超敏反应实践指南（加拿大放射医师协会与加拿大过敏与临床免疫学会） / 加拿大放射医师协会杂志 / 2025",
          "grade": "推荐意见",
          "ref": "R14"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "R16",
      "name": "过敏反应：2023 年实践参数更新",
      "type": "Reference",
      "tags": [
        "文献",
        "推荐实践"
      ],
      "aliases": [
        "2023 过敏性休克实践参数更新",
        "anaphylaxis practice parameter",
        "推荐实践",
        "practice parameter"
      ],
      "summary": "国际公认的过敏性休克抢救实践参数，肾上腺素怎么打写得很清楚。",
      "attrs": [
        {
          "k": "文献类型",
          "v": "推荐实践"
        },
        {
          "k": "年份",
          "v": "2024"
        },
        {
          "k": "核验标识",
          "v": "DOI 10.1016/j.anai.2023.09.015 · PMID 38108678 · 2024;132(2):124-176"
        },
        {
          "k": "证据等级",
          "v": "推荐意见"
        }
      ],
      "evidence": [
        {
          "type": "推荐实践",
          "author": "Golden DBK, Wang J, Waserman S, et al.",
          "title": "过敏反应：2023 年实践参数更新",
          "journal": "变态反应、哮喘与免疫学年鉴",
          "year": 2024,
          "cite": "Golden DBK, Wang J, Waserman S, et al. / 过敏反应：2023 年实践参数更新 / 变态反应、哮喘与免疫学年鉴 / 2024",
          "grade": "推荐意见",
          "ref": "R16"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "R17",
      "name": "放射科碘对比剂外渗影响因素的系统评价",
      "type": "Reference",
      "tags": [
        "文献",
        "系统评价"
      ],
      "aliases": [
        "放射科碘对比剂外渗影响因素的系统评价",
        "外渗影响因素系统评价",
        "系统评价",
        "systematic review",
        "systematic reviews"
      ],
      "summary": "汇总 19 项研究、2063 例外渗案例，归纳出外渗的常见危险因素。",
      "attrs": [
        {
          "k": "文献类型",
          "v": "系统评价"
        },
        {
          "k": "年份",
          "v": "2023"
        },
        {
          "k": "核验标识",
          "v": "上海护理 2023;23(5):45-49 · 官网摘要页 sh-nj.com/shhl/ch/reader/view_abstract.aspx?file_no=20221220（该文 DOI 未在数据库核到，故不列）"
        },
        {
          "k": "证据等级",
          "v": "汇总证据"
        }
      ],
      "evidence": [
        {
          "type": "系统评价",
          "author": "姚金秀、杨丽娜、梅申聪、董芳辉",
          "title": "放射科碘对比剂外渗影响因素的系统评价",
          "journal": "上海护理",
          "year": 2023,
          "cite": "姚金秀、杨丽娜、梅申聪、董芳辉 / 放射科碘对比剂外渗影响因素的系统评价 / 上海护理 / 2023",
          "grade": "汇总证据",
          "ref": "R17"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "R20",
      "name": "影像护理学",
      "type": "Reference",
      "tags": [
        "文献",
        "书籍"
      ],
      "aliases": [
        "影像护理学",
        "imaging nursing",
        "影像护理学教材",
        "书籍",
        "book"
      ],
      "summary": "系统讲影像科护理的教材，护理常规与患者宣教的通识来源。",
      "attrs": [
        {
          "k": "文献类型",
          "v": "书籍"
        },
        {
          "k": "年份",
          "v": "2020"
        },
        {
          "k": "核验标识",
          "v": "ISBN 978-7-117-30161-9（人民卫生出版社第 1 版）"
        },
        {
          "k": "证据等级",
          "v": "教材"
        }
      ],
      "evidence": [
        {
          "type": "书籍",
          "author": "秦月兰、郑淑梅、刘雪莲",
          "title": "影像护理学",
          "journal": "人民卫生出版社",
          "year": 2020,
          "cite": "秦月兰、郑淑梅、刘雪莲 / 影像护理学 / 人民卫生出版社 / 2020",
          "grade": "教材",
          "ref": "R20"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "R21",
      "graph": "topic-01",
      "type": "Reference",
      "name": "碘对比剂温度与不良反应关系的 Meta 分析（307,329 次注射）",
      "tags": [
        "文献",
        "Meta分析"
      ],
      "aliases": [
        "The relationship between iodinated contrast material temperature and adverse reactions",
        "碘对比剂温度 Meta 分析",
        "对比剂加温 Meta 分析"
      ],
      "summary": "汇总 5 项研究、307,329 次注射：高黏度对比剂加温到 37℃ 可减少过敏反应；但未证实能减少外渗。",
      "attrs": [
        {
          "k": "文献类型",
          "v": "Meta分析"
        },
        {
          "k": "年份",
          "v": "2023"
        },
        {
          "k": "核验标识",
          "v": "DOI 10.1016/j.clinimag.2023.05.006 · PMID 37216743"
        },
        {
          "k": "证据等级",
          "v": "汇总证据"
        }
      ],
      "evidence": [
        {
          "type": "Meta分析",
          "author": "Nawras M, Alyousif Z, Beran A, Elsamaloty H",
          "title": "碘对比剂温度与不良反应的关系：307,329 次注射的 Meta 分析",
          "journal": "临床影像学",
          "year": 2023,
          "cite": "Nawras M, Alyousif Z, Beran A, Elsamaloty H / 碘对比剂温度与不良反应的关系：307,329 次注射的 Meta 分析 / 临床影像学 / 2023 · DOI 10.1016/j.clinimag.2023.05.006 · PMID 37216743"
        }
      ]
    },
    {
      "id": "R22",
      "graph": "topic-01",
      "type": "Reference",
      "name": "CT 扫描患者对比剂外渗：危险因素与干预的系统评价和 Meta 分析",
      "tags": [
        "文献",
        "Meta分析"
      ],
      "aliases": [
        "Contrast media extravasations in patients undergoing computerized tomography scanning",
        "CT对比剂外渗 Meta分析",
        "对比剂外渗危险因素 Meta分析"
      ],
      "summary": "汇总 CT 增强扫描外渗的危险因素与干预证据：女性、住院患者等风险较高；干预证据仍有限。",
      "attrs": [
        {
          "k": "文献类型",
          "v": "Meta分析"
        },
        {
          "k": "年份",
          "v": "2018"
        },
        {
          "k": "核验标识",
          "v": "DOI 10.11124/JBISRIR-2017-003348 · PMID 29324560"
        },
        {
          "k": "证据等级",
          "v": "汇总证据"
        }
      ],
      "evidence": [
        {
          "type": "Meta分析",
          "author": "Ding S, Meystre NR, Campeanu C, Gullo G",
          "title": "CT 扫描患者对比剂外渗：危险因素与干预的系统评价和 Meta 分析",
          "journal": "JBI 系统评价与实施报告",
          "year": 2018,
          "cite": "Ding S, Meystre NR, Campeanu C, Gullo G / CT 扫描患者对比剂外渗：危险因素与干预的系统评价和 Meta 分析 / JBI 系统评价与实施报告 / 2018 · DOI 10.11124/JBISRIR-2017-003348 · PMID 29324560"
        }
      ]
    },
    {
      "id": "R23",
      "graph": "topic-01",
      "type": "Reference",
      "name": "对比剂即刻超敏反应危险因素的系统评价与 Meta 分析",
      "tags": [
        "文献",
        "Meta分析"
      ],
      "aliases": [
        "Risk factors associated with immediate hypersensitivity reaction to contrast media",
        "对比剂超敏反应危险因素 Meta分析"
      ],
      "summary": "汇总对比剂即刻超敏反应的危险因素：女性风险较高，哮喘史未见显著关联，门诊患者风险较高。",
      "attrs": [
        {
          "k": "文献类型",
          "v": "Meta分析"
        },
        {
          "k": "年份",
          "v": "2026"
        },
        {
          "k": "核验标识",
          "v": "DOI 10.1016/j.ejrad.2025.112472 · PMID 41175815"
        },
        {
          "k": "证据等级",
          "v": "汇总证据"
        }
      ],
      "evidence": [
        {
          "type": "Meta分析",
          "author": "Huang W, He C, Chen Y, Xu H, Yao J, Zhao L",
          "title": "对比剂即刻超敏反应危险因素的系统评价与 Meta 分析",
          "journal": "欧洲放射学杂志",
          "year": 2026,
          "cite": "Huang W, He C, Chen Y, Xu H, Yao J, Zhao L / 对比剂即刻超敏反应危险因素的系统评价与 Meta 分析 / 欧洲放射学杂志 / 2026 · DOI 10.1016/j.ejrad.2025.112472 · PMID 41175815"
        }
      ]
    },
    {
      "id": "S_ExtravasationSwelling",
      "graph": "topic-01",
      "type": "SymptomSign",
      "name": "局部肿胀",
      "tags": [
        "外渗表现",
        "症状体征"
      ],
      "aliases": [
        "swelling",
        "局部肿痛",
        "肿胀",
        "局部肿胀"
      ],
      "summary": "打针的部位肿起来，是外渗最直观的表现；肿胀可向近心端或远心端延伸。",
      "attrs": [],
      "evidence": [
        {
          "type": "指南",
          "author": "Roditi G, Khan N, van der Molen AJ, et al.",
          "title": "静脉对比剂外渗：系统评价及欧洲泌尿生殖放射学会对比剂安全委员会指南更新",
          "journal": "欧洲放射学杂志",
          "year": 2022,
          "cite": "Roditi G, Khan N, van der Molen AJ, et al. / 静脉对比剂外渗：系统评价及欧洲泌尿生殖放射学会对比剂安全委员会指南更新 / 欧洲放射学杂志 / 2022",
          "grade": "指南与共识",
          "ref": "R02"
        },
        {
          "type": "指南",
          "author": "中华护理学会放射介入护理专业委员会（执笔：张红梅、张素、刘宇）",
          "title": "含碘对比剂静脉外渗护理管理实践指南（2026年更新版）",
          "journal": "中华护理杂志",
          "year": 2026,
          "cite": "中华护理学会放射介入护理专业委员会（执笔：张红梅、张素、刘宇） / 含碘对比剂静脉外渗护理管理实践指南（2026年更新版） / 中华护理杂志 / 2026",
          "grade": "指南与共识",
          "ref": "R04"
        }
      ]
    },
    {
      "id": "S_ExtravasationPain",
      "graph": "topic-01",
      "type": "SymptomSign",
      "name": "局部疼痛",
      "tags": [
        "外渗表现",
        "症状体征"
      ],
      "aliases": [
        "pain",
        "局部刺痛",
        "灼痛",
        "局部疼痛"
      ],
      "summary": "推药时局部刺痛或灼痛，随后疼痛可逐渐加重。",
      "attrs": [],
      "evidence": [
        {
          "type": "指南",
          "author": "Roditi G, Khan N, van der Molen AJ, et al.",
          "title": "静脉对比剂外渗：系统评价及欧洲泌尿生殖放射学会对比剂安全委员会指南更新",
          "journal": "欧洲放射学杂志",
          "year": 2022,
          "cite": "Roditi G, Khan N, van der Molen AJ, et al. / 静脉对比剂外渗：系统评价及欧洲泌尿生殖放射学会对比剂安全委员会指南更新 / 欧洲放射学杂志 / 2022",
          "grade": "指南与共识",
          "ref": "R02"
        },
        {
          "type": "指南",
          "author": "中华护理学会放射介入护理专业委员会（执笔：张红梅、张素、刘宇）",
          "title": "含碘对比剂静脉外渗护理管理实践指南（2026年更新版）",
          "journal": "中华护理杂志",
          "year": 2026,
          "cite": "中华护理学会放射介入护理专业委员会（执笔：张红梅、张素、刘宇） / 含碘对比剂静脉外渗护理管理实践指南（2026年更新版） / 中华护理杂志 / 2026",
          "grade": "指南与共识",
          "ref": "R04"
        }
      ]
    },
    {
      "id": "S_ExtravasationRedness",
      "graph": "topic-01",
      "type": "SymptomSign",
      "name": "局部发红",
      "tags": [
        "外渗表现",
        "症状体征"
      ],
      "aliases": [
        "redness",
        "局部红肿",
        "局部发红"
      ],
      "summary": "外渗部位皮肤发红。",
      "attrs": [],
      "evidence": [
        {
          "type": "指南",
          "author": "Roditi G, Khan N, van der Molen AJ, et al.",
          "title": "静脉对比剂外渗：系统评价及欧洲泌尿生殖放射学会对比剂安全委员会指南更新",
          "journal": "欧洲放射学杂志",
          "year": 2022,
          "cite": "Roditi G, Khan N, van der Molen AJ, et al. / 静脉对比剂外渗：系统评价及欧洲泌尿生殖放射学会对比剂安全委员会指南更新 / 欧洲放射学杂志 / 2022",
          "grade": "指南与共识",
          "ref": "R02"
        },
        {
          "type": "指南",
          "author": "中华护理学会放射介入护理专业委员会（执笔：张红梅、张素、刘宇）",
          "title": "含碘对比剂静脉外渗护理管理实践指南（2026年更新版）",
          "journal": "中华护理杂志",
          "year": 2026,
          "cite": "中华护理学会放射介入护理专业委员会（执笔：张红梅、张素、刘宇） / 含碘对比剂静脉外渗护理管理实践指南（2026年更新版） / 中华护理杂志 / 2026",
          "grade": "指南与共识",
          "ref": "R04"
        }
      ]
    },
    {
      "id": "S_ExtravasationCoolSkin",
      "graph": "topic-01",
      "type": "SymptomSign",
      "name": "皮肤发凉",
      "tags": [
        "外渗表现",
        "症状体征"
      ],
      "aliases": [
        "cool skin",
        "局部发凉",
        "皮肤发凉"
      ],
      "summary": "外渗部位皮肤温度低于周围，提示局部循环受到影响。",
      "attrs": [],
      "evidence": [
        {
          "type": "指南",
          "author": "Roditi G, Khan N, van der Molen AJ, et al.",
          "title": "静脉对比剂外渗：系统评价及欧洲泌尿生殖放射学会对比剂安全委员会指南更新",
          "journal": "欧洲放射学杂志",
          "year": 2022,
          "cite": "Roditi G, Khan N, van der Molen AJ, et al. / 静脉对比剂外渗：系统评价及欧洲泌尿生殖放射学会对比剂安全委员会指南更新 / 欧洲放射学杂志 / 2022",
          "grade": "指南与共识",
          "ref": "R02"
        },
        {
          "type": "指南",
          "author": "中华护理学会放射介入护理专业委员会（执笔：张红梅、张素、刘宇）",
          "title": "含碘对比剂静脉外渗护理管理实践指南（2026年更新版）",
          "journal": "中华护理杂志",
          "year": 2026,
          "cite": "中华护理学会放射介入护理专业委员会（执笔：张红梅、张素、刘宇） / 含碘对比剂静脉外渗护理管理实践指南（2026年更新版） / 中华护理杂志 / 2026",
          "grade": "指南与共识",
          "ref": "R04"
        }
      ]
    },
    {
      "id": "S_ExtravasationPallor",
      "graph": "topic-01",
      "type": "SymptomSign",
      "name": "皮肤发白发紧",
      "tags": [
        "外渗表现",
        "症状体征"
      ],
      "aliases": [
        "pale tight skin",
        "皮肤苍白",
        "局部发白",
        "皮肤发白发紧"
      ],
      "summary": "外渗部位皮肤发白、发紧，是皮下积液张力高的表现。",
      "attrs": [],
      "evidence": [
        {
          "type": "指南",
          "author": "Roditi G, Khan N, van der Molen AJ, et al.",
          "title": "静脉对比剂外渗：系统评价及欧洲泌尿生殖放射学会对比剂安全委员会指南更新",
          "journal": "欧洲放射学杂志",
          "year": 2022,
          "cite": "Roditi G, Khan N, van der Molen AJ, et al. / 静脉对比剂外渗：系统评价及欧洲泌尿生殖放射学会对比剂安全委员会指南更新 / 欧洲放射学杂志 / 2022",
          "grade": "指南与共识",
          "ref": "R02"
        },
        {
          "type": "指南",
          "author": "中华护理学会放射介入护理专业委员会（执笔：张红梅、张素、刘宇）",
          "title": "含碘对比剂静脉外渗护理管理实践指南（2026年更新版）",
          "journal": "中华护理杂志",
          "year": 2026,
          "cite": "中华护理学会放射介入护理专业委员会（执笔：张红梅、张素、刘宇） / 含碘对比剂静脉外渗护理管理实践指南（2026年更新版） / 中华护理杂志 / 2026",
          "grade": "指南与共识",
          "ref": "R04"
        }
      ]
    },
    {
      "id": "NT_SelfCareTheory",
      "name": "自护理论",
      "type": "NursingTheory",
      "tags": [
        "护理理论",
        "自护理论"
      ],
      "aliases": [
        "Orem 自护理论",
        "自我护理理论",
        "Orem's Self-Care Deficit Nursing Theory",
        "SCDNT"
      ],
      "summary": "自护理论（Orem，1971）认为人天生具备自我护理的能力，护理的任务是在患者自护能力不足时提供补偿与支持。对应到本主题：指导患者与家属参与碘对比剂过敏反应与外渗的预防、早期识别与居家自我照护。",
      "attrs": [
        {
          "k": "理论提出者",
          "v": "Dorothea E. Orem"
        },
        {
          "k": "提出年份",
          "v": "1971"
        },
        {
          "k": "理论依据",
          "v": "系统评价与剂量反应 Meta 分析（Nasiri 等 2023）—— 纳入 46 项研究"
        }
      ],
      "evidence": [
        {
          "type": "系统评价",
          "author": "Nasiri M, Jafari Z, Rakhshan M, Yarahmadi F, et al.",
          "title": "Orem 自护理论照护方案在慢性病成人中的应用：系统评价与剂量反应 Meta 分析",
          "journal": "国际护理评论",
          "year": 2023,
          "cite": "Nasiri M, Jafari Z, Rakhshan M, Yarahmadi F, et al. / Orem 自护理论照护方案在慢性病成人中的应用：系统评价与剂量反应 Meta 分析 / 国际护理评论 / 2023",
          "grade": "汇总证据",
          "ref": "R24"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "R24",
      "name": "Orem 自护理论照护方案在慢性病成人中的应用：系统评价与剂量反应 Meta 分析",
      "type": "Reference",
      "tags": [
        "文献",
        "系统评价"
      ],
      "aliases": [
        "Application of Orem's theory-based caring programs among chronically ill adults",
        "Orem 自护理论系统评价",
        "Nasiri 2023 系统评价"
      ],
      "summary": "系统评价与剂量反应 Meta 分析，纳入 46 项研究：以自护理论为基础的照护方案可改善慢病成人的生活质量、自我照护能力与自我效能，并降低焦虑与抑郁；但研究间异质性高、证据质量不理想，仍需设计良好的试验。",
      "attrs": [
        {
          "k": "文献类型",
          "v": "系统评价"
        },
        {
          "k": "年份",
          "v": "2023"
        },
        {
          "k": "核验标识",
          "v": "DOI 10.1111/inr.12808 · PROSPERO CRD42020152789 · Int Nurs Rev 70(1):59-77"
        },
        {
          "k": "证据等级",
          "v": "汇总证据"
        }
      ],
      "evidence": [
        {
          "type": "系统评价",
          "author": "Nasiri M, Jafari Z, Rakhshan M, Yarahmadi F, et al.",
          "title": "Orem 自护理论照护方案在慢性病成人中的应用：系统评价与剂量反应 Meta 分析",
          "journal": "国际护理评论",
          "year": 2023,
          "cite": "Nasiri M, Jafari Z, Rakhshan M, Yarahmadi F, et al. / Orem 自护理论照护方案在慢性病成人中的应用：系统评价与剂量反应 Meta 分析 / 国际护理评论 / 2023",
          "grade": "汇总证据",
          "ref": "R24"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "FW_SymptomSign",
      "name": "症状体征",
      "type": "SymptomSign",
      "tags": [
        "知识框架",
        "一级框架"
      ],
      "aliases": [
        "症状体征"
      ],
      "summary": "论文「疾病知识图」一级框架之一。收录碘对比剂使用后可能出现的症状与体征 —— 不良反应、过敏反应、碘对比剂外渗；过敏反应下的下一级表现（皮疹、荨麻疹、瘙痒、颜面部水肿、咽喉部不适、胸闷、全身无力、过敏性休克），以及碘对比剂外渗下的局部表现（局部肿胀、局部疼痛、局部发红、皮肤发凉、皮肤发白发紧）。",
      "attrs": [
        {
          "k": "框架层级",
          "v": "一级框架"
        }
      ],
      "evidence": [
        {
          "type": "指南",
          "author": "美国放射学会药物与对比剂委员会",
          "title": "美国放射学会对比剂手册",
          "journal": "美国放射学会",
          "year": 2024,
          "cite": "美国放射学会药物与对比剂委员会 / 美国放射学会对比剂手册 / 美国放射学会 / 2024",
          "grade": "指南与共识",
          "ref": "R01"
        },
        {
          "type": "声明",
          "author": "Wang C, Ramsey A, Lang D, et al.",
          "title": "放射性对比剂超敏反应的管理与预防：美国放射学会与美国变态反应、哮喘与免疫学会共识声明",
          "journal": "放射学",
          "year": 2025,
          "cite": "Wang C, Ramsey A, Lang D, et al. / 放射性对比剂超敏反应的管理与预防：美国放射学会与美国变态反应、哮喘与免疫学会共识声明 / 放射学 / 2025",
          "grade": "学会声明",
          "ref": "R12"
        },
        {
          "type": "建议",
          "author": "Byrne A, Macdonald DB, Kirkpatrick IDC, et al.",
          "title": "对比剂超敏反应实践指南（加拿大放射医师协会与加拿大过敏与临床免疫学会）",
          "journal": "加拿大放射医师协会杂志",
          "year": 2025,
          "cite": "Byrne A, Macdonald DB, Kirkpatrick IDC, et al. / 对比剂超敏反应实践指南（加拿大放射医师协会与加拿大过敏与临床免疫学会） / 加拿大放射医师协会杂志 / 2025",
          "grade": "推荐意见",
          "ref": "R14"
        },
        {
          "type": "建议",
          "author": "Brockow K",
          "title": "放射性对比剂超敏反应处理流程（2024 年更新）",
          "journal": "变态反应",
          "year": 2024,
          "cite": "Brockow K / 放射性对比剂超敏反应处理流程（2024 年更新） / 变态反应 / 2024",
          "grade": "推荐意见",
          "ref": "R13"
        },
        {
          "type": "Meta分析",
          "author": "Nawras M, Alyousif Z, Beran A, Elsamaloty H",
          "title": "碘对比剂温度与不良反应的关系：307,329 次注射的 Meta 分析",
          "journal": "临床影像学",
          "year": 2023,
          "cite": "Nawras M, Alyousif Z, Beran A, Elsamaloty H / 碘对比剂温度与不良反应的关系：307,329 次注射的 Meta 分析 / 临床影像学 / 2023 · DOI 10.1016/j.clinimag.2023.05.006 · PMID 37216743"
        },
        {
          "type": "Meta分析",
          "author": "Huang W, He C, Chen Y, Xu H, Yao J, Zhao L",
          "title": "对比剂即刻超敏反应危险因素的系统评价与 Meta 分析",
          "journal": "欧洲放射学杂志",
          "year": 2026,
          "cite": "Huang W, He C, Chen Y, Xu H, Yao J, Zhao L / 对比剂即刻超敏反应危险因素的系统评价与 Meta 分析 / 欧洲放射学杂志 / 2026 · DOI 10.1016/j.ejrad.2025.112472 · PMID 41175815"
        },
        {
          "type": "推荐实践",
          "author": "Golden DBK, Wang J, Waserman S, et al.",
          "title": "过敏反应：2023 年实践参数更新",
          "journal": "变态反应、哮喘与免疫学年鉴",
          "year": 2024,
          "cite": "Golden DBK, Wang J, Waserman S, et al. / 过敏反应：2023 年实践参数更新 / 变态反应、哮喘与免疫学年鉴 / 2024",
          "grade": "推荐意见",
          "ref": "R16"
        },
        {
          "type": "指南",
          "author": "Roditi G, Khan N, van der Molen AJ, et al.",
          "title": "静脉对比剂外渗：系统评价及欧洲泌尿生殖放射学会对比剂安全委员会指南更新",
          "journal": "欧洲放射学杂志",
          "year": 2022,
          "cite": "Roditi G, Khan N, van der Molen AJ, et al. / 静脉对比剂外渗：系统评价及欧洲泌尿生殖放射学会对比剂安全委员会指南更新 / 欧洲放射学杂志 / 2022",
          "grade": "指南与共识",
          "ref": "R02"
        },
        {
          "type": "指南",
          "author": "中华护理学会放射介入护理专业委员会（执笔：张红梅、张素、刘宇）",
          "title": "含碘对比剂静脉外渗护理管理实践指南（2026年更新版）",
          "journal": "中华护理杂志",
          "year": 2026,
          "cite": "中华护理学会放射介入护理专业委员会（执笔：张红梅、张素、刘宇） / 含碘对比剂静脉外渗护理管理实践指南（2026年更新版） / 中华护理杂志 / 2026",
          "grade": "指南与共识",
          "ref": "R04"
        },
        {
          "type": "系统评价",
          "author": "姚金秀、杨丽娜、梅申聪、董芳辉",
          "title": "放射科碘对比剂外渗影响因素的系统评价",
          "journal": "上海护理",
          "year": 2023,
          "cite": "姚金秀、杨丽娜、梅申聪、董芳辉 / 放射科碘对比剂外渗影响因素的系统评价 / 上海护理 / 2023",
          "grade": "汇总证据",
          "ref": "R17"
        },
        {
          "type": "规范",
          "author": "江西省市场监督管理局",
          "title": "DB36/T 2299—2026 含碘对比剂静脉外渗预防与护理规范",
          "journal": "江西省市场监督管理局（地方标准）",
          "year": 2026,
          "cite": "江西省市场监督管理局 / DB36/T 2299—2026 含碘对比剂静脉外渗预防与护理规范 / 江西省市场监督管理局（地方标准） / 2026",
          "grade": "标准与规范",
          "ref": "R09"
        },
        {
          "type": "规范",
          "author": "广西壮族自治区市场监督管理局",
          "title": "DB45/T 2935—2024 CT增强扫描碘对比剂外渗预防与护理规范",
          "journal": "广西壮族自治区市场监督管理局（地方标准）",
          "year": 2024,
          "cite": "广西壮族自治区市场监督管理局 / DB45/T 2935—2024 CT增强扫描碘对比剂外渗预防与护理规范 / 广西壮族自治区市场监督管理局（地方标准） / 2024",
          "grade": "标准与规范",
          "ref": "R10"
        },
        {
          "type": "Meta分析",
          "author": "Ding S, Meystre NR, Campeanu C, Gullo G",
          "title": "CT 扫描患者对比剂外渗：危险因素与干预的系统评价和 Meta 分析",
          "journal": "JBI 系统评价与实施报告",
          "year": 2018,
          "cite": "Ding S, Meystre NR, Campeanu C, Gullo G / CT 扫描患者对比剂外渗：危险因素与干预的系统评价和 Meta 分析 / JBI 系统评价与实施报告 / 2018 · DOI 10.11124/JBISRIR-2017-003348 · PMID 29324560"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "FW_Exam",
      "name": "辅助检查",
      "type": "Exam",
      "tags": [
        "知识框架",
        "一级框架"
      ],
      "aliases": [
        "辅助检查"
      ],
      "summary": "论文「疾病知识图」一级框架之一。收录与本主题相关的检查项目 —— CT 增强扫描、碘对比剂。",
      "attrs": [
        {
          "k": "框架层级",
          "v": "一级框架"
        }
      ],
      "evidence": [
        {
          "type": "指南",
          "author": "美国放射学会药物与对比剂委员会",
          "title": "美国放射学会对比剂手册",
          "journal": "美国放射学会",
          "year": 2024,
          "cite": "美国放射学会药物与对比剂委员会 / 美国放射学会对比剂手册 / 美国放射学会 / 2024",
          "grade": "指南与共识",
          "ref": "R01"
        },
        {
          "type": "指南",
          "author": "中华医学会放射学分会对比剂安全使用工作组",
          "title": "碘对比剂使用指南（第2版）",
          "journal": "中华放射学杂志",
          "year": 2013,
          "cite": "中华医学会放射学分会对比剂安全使用工作组 / 碘对比剂使用指南（第2版） / 中华放射学杂志 / 2013",
          "grade": "指南与共识",
          "ref": "R03"
        },
        {
          "type": "规范",
          "author": "广西壮族自治区市场监督管理局",
          "title": "DB45/T 2935—2024 CT增强扫描碘对比剂外渗预防与护理规范",
          "journal": "广西壮族自治区市场监督管理局（地方标准）",
          "year": 2024,
          "cite": "广西壮族自治区市场监督管理局 / DB45/T 2935—2024 CT增强扫描碘对比剂外渗预防与护理规范 / 广西壮族自治区市场监督管理局（地方标准） / 2024",
          "grade": "标准与规范",
          "ref": "R10"
        },
        {
          "type": "共识",
          "author": "中华医学会放射学分会放射护理专业委员会放射诊断护理学组（执笔：李雪、郑淑梅、屈梅香）",
          "title": "影像科碘对比剂输注安全专家共识",
          "journal": "介入放射学杂志",
          "year": 2018,
          "cite": "中华医学会放射学分会放射护理专业委员会放射诊断护理学组（执笔：李雪、郑淑梅、屈梅香） / 影像科碘对比剂输注安全专家共识 / 介入放射学杂志 / 2018",
          "grade": "指南与共识",
          "ref": "R07"
        },
        {
          "type": "推荐",
          "author": "de Laforcade L, Bobot M, Bellin MF, et al.",
          "title": "欧洲泌尿生殖放射学会对比剂使用建议：法国肾脏病学会、法语放射学会与法语肾脏病医师学会的实践调查与述评",
          "journal": "肾脏病与治疗",
          "year": 2021,
          "cite": "de Laforcade L, Bobot M, Bellin MF, et al. / 欧洲泌尿生殖放射学会对比剂使用建议：法国肾脏病学会、法语放射学会与法语肾脏病医师学会的实践调查与述评 / 肾脏病与治疗 / 2021",
          "grade": "推荐意见",
          "ref": "R15"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "FW_ManagementPrinciple",
      "name": "处置原则",
      "type": "ManagementPrinciple",
      "tags": [
        "知识框架",
        "一级框架"
      ],
      "aliases": [
        "处置原则"
      ],
      "summary": "论文「疾病知识图」一级框架之一。收录护理处置原则 —— 护理措施、护理预防、护理干预，以及其下的外渗处置原则与不良反应分级处置原则。",
      "attrs": [
        {
          "k": "框架层级",
          "v": "一级框架"
        }
      ],
      "evidence": [
        {
          "type": "指南",
          "author": "中华护理学会放射介入护理专业委员会（执笔：张红梅、张素、刘宇）",
          "title": "含碘对比剂静脉外渗护理管理实践指南（2026年更新版）",
          "journal": "中华护理杂志",
          "year": 2026,
          "cite": "中华护理学会放射介入护理专业委员会（执笔：张红梅、张素、刘宇） / 含碘对比剂静脉外渗护理管理实践指南（2026年更新版） / 中华护理杂志 / 2026",
          "grade": "指南与共识",
          "ref": "R04"
        },
        {
          "type": "共识",
          "author": "中华医学会放射学分会放射护理专业委员会放射诊断护理学组（执笔：李雪、郑淑梅、屈梅香）",
          "title": "影像科碘对比剂输注安全专家共识",
          "journal": "介入放射学杂志",
          "year": 2018,
          "cite": "中华医学会放射学分会放射护理专业委员会放射诊断护理学组（执笔：李雪、郑淑梅、屈梅香） / 影像科碘对比剂输注安全专家共识 / 介入放射学杂志 / 2018",
          "grade": "指南与共识",
          "ref": "R07"
        },
        {
          "type": "指南",
          "author": "美国放射学会药物与对比剂委员会",
          "title": "美国放射学会对比剂手册",
          "journal": "美国放射学会",
          "year": 2024,
          "cite": "美国放射学会药物与对比剂委员会 / 美国放射学会对比剂手册 / 美国放射学会 / 2024",
          "grade": "指南与共识",
          "ref": "R01"
        },
        {
          "type": "规范",
          "author": "江西省市场监督管理局",
          "title": "DB36/T 2299—2026 含碘对比剂静脉外渗预防与护理规范",
          "journal": "江西省市场监督管理局（地方标准）",
          "year": 2026,
          "cite": "江西省市场监督管理局 / DB36/T 2299—2026 含碘对比剂静脉外渗预防与护理规范 / 江西省市场监督管理局（地方标准） / 2026",
          "grade": "标准与规范",
          "ref": "R09"
        },
        {
          "type": "指南",
          "author": "Roditi G, Khan N, van der Molen AJ, et al.",
          "title": "静脉对比剂外渗：系统评价及欧洲泌尿生殖放射学会对比剂安全委员会指南更新",
          "journal": "欧洲放射学杂志",
          "year": 2022,
          "cite": "Roditi G, Khan N, van der Molen AJ, et al. / 静脉对比剂外渗：系统评价及欧洲泌尿生殖放射学会对比剂安全委员会指南更新 / 欧洲放射学杂志 / 2022",
          "grade": "指南与共识",
          "ref": "R02"
        },
        {
          "type": "推荐实践",
          "author": "Golden DBK, Wang J, Waserman S, et al.",
          "title": "过敏反应：2023 年实践参数更新",
          "journal": "变态反应、哮喘与免疫学年鉴",
          "year": 2024,
          "cite": "Golden DBK, Wang J, Waserman S, et al. / 过敏反应：2023 年实践参数更新 / 变态反应、哮喘与免疫学年鉴 / 2024",
          "grade": "推荐意见",
          "ref": "R16"
        },
        {
          "type": "声明",
          "author": "Wang C, Ramsey A, Lang D, et al.",
          "title": "放射性对比剂超敏反应的管理与预防：美国放射学会与美国变态反应、哮喘与免疫学会共识声明",
          "journal": "放射学",
          "year": 2025,
          "cite": "Wang C, Ramsey A, Lang D, et al. / 放射性对比剂超敏反应的管理与预防：美国放射学会与美国变态反应、哮喘与免疫学会共识声明 / 放射学 / 2025",
          "grade": "学会声明",
          "ref": "R12"
        },
        {
          "type": "建议",
          "author": "Brockow K",
          "title": "放射性对比剂超敏反应处理流程（2024 年更新）",
          "journal": "变态反应",
          "year": 2024,
          "cite": "Brockow K / 放射性对比剂超敏反应处理流程（2024 年更新） / 变态反应 / 2024",
          "grade": "推荐意见",
          "ref": "R13"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "FW_NursingTheory",
      "name": "护理理论",
      "type": "NursingTheory",
      "tags": [
        "知识框架",
        "一级框架"
      ],
      "aliases": [
        "护理理论"
      ],
      "summary": "论文「疾病知识图」一级框架之一。收录指导护理实践的理论 —— 自护理论（Orem）：人天生具备自我护理的能力，护理的任务是在患者自护能力不足时提供补偿与支持；对应到本主题，是指导患者与家属参与预防、早期识别与居家自我照护。以及早期预警：在情况变坏之前先看出苗头、及时升级处理。",
      "attrs": [
        {
          "k": "框架层级",
          "v": "一级框架"
        }
      ],
      "evidence": [
        {
          "type": "建议",
          "author": "Brockow K",
          "title": "放射性对比剂超敏反应处理流程（2024 年更新）",
          "journal": "变态反应",
          "year": 2024,
          "cite": "Brockow K / 放射性对比剂超敏反应处理流程（2024 年更新） / 变态反应 / 2024",
          "grade": "推荐意见",
          "ref": "R13"
        },
        {
          "type": "推荐实践",
          "author": "Golden DBK, Wang J, Waserman S, et al.",
          "title": "过敏反应：2023 年实践参数更新",
          "journal": "变态反应、哮喘与免疫学年鉴",
          "year": 2024,
          "cite": "Golden DBK, Wang J, Waserman S, et al. / 过敏反应：2023 年实践参数更新 / 变态反应、哮喘与免疫学年鉴 / 2024",
          "grade": "推荐意见",
          "ref": "R16"
        },
        {
          "type": "系统评价",
          "author": "Nasiri M, Jafari Z, Rakhshan M, Yarahmadi F, et al.",
          "title": "Orem 自护理论照护方案在慢性病成人中的应用：系统评价与剂量反应 Meta 分析",
          "journal": "国际护理评论",
          "year": 2023,
          "cite": "Nasiri M, Jafari Z, Rakhshan M, Yarahmadi F, et al. / Orem 自护理论照护方案在慢性病成人中的应用：系统评价与剂量反应 Meta 分析 / 国际护理评论 / 2023",
          "grade": "汇总证据",
          "ref": "R24"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "FW_DiseaseEducation",
      "name": "疾病科普",
      "type": "DiseaseEducation",
      "tags": [
        "知识框架",
        "一级框架"
      ],
      "aliases": [
        "疾病科普"
      ],
      "summary": "论文「疾病知识图」一级框架之一。论文 §3.2 指出「疾病知识图中科普模块的内容可面向公众开放，便于公众了解疾病的早期症状及常见误区」。收录检查前注意事项、检查后观察与护理、过敏史告知、外渗居家护理、急救知识五篇科普。",
      "attrs": [
        {
          "k": "框架层级",
          "v": "一级框架"
        }
      ],
      "evidence": [
        {
          "type": "指南",
          "author": "中华医学会放射学分会对比剂安全使用工作组",
          "title": "碘对比剂使用指南（第2版）",
          "journal": "中华放射学杂志",
          "year": 2013,
          "cite": "中华医学会放射学分会对比剂安全使用工作组 / 碘对比剂使用指南（第2版） / 中华放射学杂志 / 2013",
          "grade": "指南与共识",
          "ref": "R03"
        },
        {
          "type": "书籍",
          "author": "秦月兰、郑淑梅、刘雪莲",
          "title": "影像护理学",
          "journal": "人民卫生出版社",
          "year": 2020,
          "cite": "秦月兰、郑淑梅、刘雪莲 / 影像护理学 / 人民卫生出版社 / 2020",
          "grade": "教材",
          "ref": "R20"
        },
        {
          "type": "指南",
          "author": "美国放射学会药物与对比剂委员会",
          "title": "美国放射学会对比剂手册",
          "journal": "美国放射学会",
          "year": 2024,
          "cite": "美国放射学会药物与对比剂委员会 / 美国放射学会对比剂手册 / 美国放射学会 / 2024",
          "grade": "指南与共识",
          "ref": "R01"
        },
        {
          "type": "共识",
          "author": "中华医学会放射学分会放射护理专业委员会放射诊断护理学组（执笔：李雪、郑淑梅、屈梅香）",
          "title": "影像科碘对比剂输注安全专家共识",
          "journal": "介入放射学杂志",
          "year": 2018,
          "cite": "中华医学会放射学分会放射护理专业委员会放射诊断护理学组（执笔：李雪、郑淑梅、屈梅香） / 影像科碘对比剂输注安全专家共识 / 介入放射学杂志 / 2018",
          "grade": "指南与共识",
          "ref": "R07"
        },
        {
          "type": "声明",
          "author": "Wang C, Ramsey A, Lang D, et al.",
          "title": "放射性对比剂超敏反应的管理与预防：美国放射学会与美国变态反应、哮喘与免疫学会共识声明",
          "journal": "放射学",
          "year": 2025,
          "cite": "Wang C, Ramsey A, Lang D, et al. / 放射性对比剂超敏反应的管理与预防：美国放射学会与美国变态反应、哮喘与免疫学会共识声明 / 放射学 / 2025",
          "grade": "学会声明",
          "ref": "R12"
        },
        {
          "type": "指南",
          "author": "中华护理学会放射介入护理专业委员会（执笔：张红梅、张素、刘宇）",
          "title": "含碘对比剂静脉外渗护理管理实践指南（2026年更新版）",
          "journal": "中华护理杂志",
          "year": 2026,
          "cite": "中华护理学会放射介入护理专业委员会（执笔：张红梅、张素、刘宇） / 含碘对比剂静脉外渗护理管理实践指南（2026年更新版） / 中华护理杂志 / 2026",
          "grade": "指南与共识",
          "ref": "R04"
        },
        {
          "type": "指南",
          "author": "Roditi G, Khan N, van der Molen AJ, et al.",
          "title": "静脉对比剂外渗：系统评价及欧洲泌尿生殖放射学会对比剂安全委员会指南更新",
          "journal": "欧洲放射学杂志",
          "year": 2022,
          "cite": "Roditi G, Khan N, van der Molen AJ, et al. / 静脉对比剂外渗：系统评价及欧洲泌尿生殖放射学会对比剂安全委员会指南更新 / 欧洲放射学杂志 / 2022",
          "grade": "指南与共识",
          "ref": "R02"
        },
        {
          "type": "推荐实践",
          "author": "Golden DBK, Wang J, Waserman S, et al.",
          "title": "过敏反应：2023 年实践参数更新",
          "journal": "变态反应、哮喘与免疫学年鉴",
          "year": 2024,
          "cite": "Golden DBK, Wang J, Waserman S, et al. / 过敏反应：2023 年实践参数更新 / 变态反应、哮喘与免疫学年鉴 / 2024",
          "grade": "推荐意见",
          "ref": "R16"
        },
        {
          "type": "建议",
          "author": "Brockow K",
          "title": "放射性对比剂超敏反应处理流程（2024 年更新）",
          "journal": "变态反应",
          "year": 2024,
          "cite": "Brockow K / 放射性对比剂超敏反应处理流程（2024 年更新） / 变态反应 / 2024",
          "grade": "推荐意见",
          "ref": "R13"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "FW_SymptomCategory",
      "name": "症状分类",
      "type": "SymptomCategory",
      "tags": [
        "知识框架",
        "二级框架"
      ],
      "aliases": [
        "症状分类"
      ],
      "summary": "论文表 1「症状分类」二级框架。把症状按谱归类 —— 碘对比剂不良反应谱，其下有过敏反应谱、静脉外渗反应谱。",
      "attrs": [
        {
          "k": "框架层级",
          "v": "二级框架"
        }
      ],
      "evidence": [
        {
          "type": "指南",
          "author": "美国放射学会药物与对比剂委员会",
          "title": "美国放射学会对比剂手册",
          "journal": "美国放射学会",
          "year": 2024,
          "cite": "美国放射学会药物与对比剂委员会 / 美国放射学会对比剂手册 / 美国放射学会 / 2024",
          "grade": "指南与共识",
          "ref": "R01"
        },
        {
          "type": "声明",
          "author": "Wang C, Ramsey A, Lang D, et al.",
          "title": "放射性对比剂超敏反应的管理与预防：美国放射学会与美国变态反应、哮喘与免疫学会共识声明",
          "journal": "放射学",
          "year": 2025,
          "cite": "Wang C, Ramsey A, Lang D, et al. / 放射性对比剂超敏反应的管理与预防：美国放射学会与美国变态反应、哮喘与免疫学会共识声明 / 放射学 / 2025",
          "grade": "学会声明",
          "ref": "R12"
        },
        {
          "type": "指南",
          "author": "Roditi G, Khan N, van der Molen AJ, et al.",
          "title": "静脉对比剂外渗：系统评价及欧洲泌尿生殖放射学会对比剂安全委员会指南更新",
          "journal": "欧洲放射学杂志",
          "year": 2022,
          "cite": "Roditi G, Khan N, van der Molen AJ, et al. / 静脉对比剂外渗：系统评价及欧洲泌尿生殖放射学会对比剂安全委员会指南更新 / 欧洲放射学杂志 / 2022",
          "grade": "指南与共识",
          "ref": "R02"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "FW_AssessmentTool",
      "name": "评估工具",
      "type": "AssessmentTool",
      "tags": [
        "知识框架",
        "二级框架"
      ],
      "aliases": [
        "评估工具"
      ],
      "summary": "论文表 1「评估工具」二级框架。收录评估工具 —— 过敏史询问、外渗风险评估、血管条件评估。",
      "attrs": [
        {
          "k": "框架层级",
          "v": "二级框架"
        }
      ],
      "evidence": [
        {
          "type": "指南",
          "author": "中华医学会放射学分会对比剂安全使用工作组",
          "title": "碘对比剂使用指南（第2版）",
          "journal": "中华放射学杂志",
          "year": 2013,
          "cite": "中华医学会放射学分会对比剂安全使用工作组 / 碘对比剂使用指南（第2版） / 中华放射学杂志 / 2013",
          "grade": "指南与共识",
          "ref": "R03"
        },
        {
          "type": "声明",
          "author": "Wang C, Ramsey A, Lang D, et al.",
          "title": "放射性对比剂超敏反应的管理与预防：美国放射学会与美国变态反应、哮喘与免疫学会共识声明",
          "journal": "放射学",
          "year": 2025,
          "cite": "Wang C, Ramsey A, Lang D, et al. / 放射性对比剂超敏反应的管理与预防：美国放射学会与美国变态反应、哮喘与免疫学会共识声明 / 放射学 / 2025",
          "grade": "学会声明",
          "ref": "R12"
        },
        {
          "type": "指南",
          "author": "中华护理学会放射介入护理专业委员会（执笔：张红梅、张素、刘宇）",
          "title": "含碘对比剂静脉外渗护理管理实践指南（2026年更新版）",
          "journal": "中华护理杂志",
          "year": 2026,
          "cite": "中华护理学会放射介入护理专业委员会（执笔：张红梅、张素、刘宇） / 含碘对比剂静脉外渗护理管理实践指南（2026年更新版） / 中华护理杂志 / 2026",
          "grade": "指南与共识",
          "ref": "R04"
        },
        {
          "type": "系统评价",
          "author": "姚金秀、杨丽娜、梅申聪、董芳辉",
          "title": "放射科碘对比剂外渗影响因素的系统评价",
          "journal": "上海护理",
          "year": 2023,
          "cite": "姚金秀、杨丽娜、梅申聪、董芳辉 / 放射科碘对比剂外渗影响因素的系统评价 / 上海护理 / 2023",
          "grade": "汇总证据",
          "ref": "R17"
        },
        {
          "type": "Meta分析",
          "author": "Ding S, Meystre NR, Campeanu C, Gullo G",
          "title": "CT 扫描患者对比剂外渗：危险因素与干预的系统评价和 Meta 分析",
          "journal": "JBI 系统评价与实施报告",
          "year": 2018,
          "cite": "Ding S, Meystre NR, Campeanu C, Gullo G / CT 扫描患者对比剂外渗：危险因素与干预的系统评价和 Meta 分析 / JBI 系统评价与实施报告 / 2018 · DOI 10.11124/JBISRIR-2017-003348 · PMID 29324560"
        },
        {
          "type": "标准",
          "author": "国家卫生健康委员会",
          "title": "WS/T 433—2023 静脉治疗护理技术操作标准",
          "journal": "国家卫生健康委员会（卫生行业标准）",
          "year": 2023,
          "cite": "国家卫生健康委员会 / WS/T 433—2023 静脉治疗护理技术操作标准 / 国家卫生健康委员会（卫生行业标准） / 2023",
          "grade": "标准与规范",
          "ref": "R08"
        },
        {
          "type": "规范",
          "author": "江西省市场监督管理局",
          "title": "DB36/T 2299—2026 含碘对比剂静脉外渗预防与护理规范",
          "journal": "江西省市场监督管理局（地方标准）",
          "year": 2026,
          "cite": "江西省市场监督管理局 / DB36/T 2299—2026 含碘对比剂静脉外渗预防与护理规范 / 江西省市场监督管理局（地方标准） / 2026",
          "grade": "标准与规范",
          "ref": "R09"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "FW_RiskFactor",
      "name": "高危因素识别",
      "type": "RiskFactor",
      "tags": [
        "知识框架",
        "二级框架"
      ],
      "aliases": [
        "高危因素识别"
      ],
      "summary": "论文表 1「高危因素识别」二级框架。收录高危因素 —— 既往碘对比剂过敏史、未控制的哮喘、高龄或低龄、静脉条件差、高压注射、未做生理盐水试推。",
      "attrs": [
        {
          "k": "框架层级",
          "v": "二级框架"
        }
      ],
      "evidence": [
        {
          "type": "声明",
          "author": "Wang C, Ramsey A, Lang D, et al.",
          "title": "放射性对比剂超敏反应的管理与预防：美国放射学会与美国变态反应、哮喘与免疫学会共识声明",
          "journal": "放射学",
          "year": 2025,
          "cite": "Wang C, Ramsey A, Lang D, et al. / 放射性对比剂超敏反应的管理与预防：美国放射学会与美国变态反应、哮喘与免疫学会共识声明 / 放射学 / 2025",
          "grade": "学会声明",
          "ref": "R12"
        },
        {
          "type": "建议",
          "author": "Brockow K",
          "title": "放射性对比剂超敏反应处理流程（2024 年更新）",
          "journal": "变态反应",
          "year": 2024,
          "cite": "Brockow K / 放射性对比剂超敏反应处理流程（2024 年更新） / 变态反应 / 2024",
          "grade": "推荐意见",
          "ref": "R13"
        },
        {
          "type": "Meta分析",
          "author": "Huang W, He C, Chen Y, Xu H, Yao J, Zhao L",
          "title": "对比剂即刻超敏反应危险因素的系统评价与 Meta 分析",
          "journal": "欧洲放射学杂志",
          "year": 2026,
          "cite": "Huang W, He C, Chen Y, Xu H, Yao J, Zhao L / 对比剂即刻超敏反应危险因素的系统评价与 Meta 分析 / 欧洲放射学杂志 / 2026 · DOI 10.1016/j.ejrad.2025.112472 · PMID 41175815"
        },
        {
          "type": "指南",
          "author": "中华护理学会放射介入护理专业委员会（执笔：张红梅、张素、刘宇）",
          "title": "含碘对比剂静脉外渗护理管理实践指南（2026年更新版）",
          "journal": "中华护理杂志",
          "year": 2026,
          "cite": "中华护理学会放射介入护理专业委员会（执笔：张红梅、张素、刘宇） / 含碘对比剂静脉外渗护理管理实践指南（2026年更新版） / 中华护理杂志 / 2026",
          "grade": "指南与共识",
          "ref": "R04"
        },
        {
          "type": "系统评价",
          "author": "姚金秀、杨丽娜、梅申聪、董芳辉",
          "title": "放射科碘对比剂外渗影响因素的系统评价",
          "journal": "上海护理",
          "year": 2023,
          "cite": "姚金秀、杨丽娜、梅申聪、董芳辉 / 放射科碘对比剂外渗影响因素的系统评价 / 上海护理 / 2023",
          "grade": "汇总证据",
          "ref": "R17"
        },
        {
          "type": "指南",
          "author": "Roditi G, Khan N, van der Molen AJ, et al.",
          "title": "静脉对比剂外渗：系统评价及欧洲泌尿生殖放射学会对比剂安全委员会指南更新",
          "journal": "欧洲放射学杂志",
          "year": 2022,
          "cite": "Roditi G, Khan N, van der Molen AJ, et al. / 静脉对比剂外渗：系统评价及欧洲泌尿生殖放射学会对比剂安全委员会指南更新 / 欧洲放射学杂志 / 2022",
          "grade": "指南与共识",
          "ref": "R02"
        },
        {
          "type": "规范",
          "author": "江西省市场监督管理局",
          "title": "DB36/T 2299—2026 含碘对比剂静脉外渗预防与护理规范",
          "journal": "江西省市场监督管理局（地方标准）",
          "year": 2026,
          "cite": "江西省市场监督管理局 / DB36/T 2299—2026 含碘对比剂静脉外渗预防与护理规范 / 江西省市场监督管理局（地方标准） / 2026",
          "grade": "标准与规范",
          "ref": "R09"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "FW_PharmacologicalManagement",
      "name": "药物管理",
      "type": "PharmacologicalManagement",
      "tags": [
        "知识框架",
        "二级框架"
      ],
      "aliases": [
        "药物管理"
      ],
      "summary": "论文表 1「药物管理」二级框架。收录药物处置 —— 肌内注射肾上腺素、糖皮质激素、抗组胺药、50% 硫酸镁湿敷、0.05% 地塞米松湿敷。",
      "attrs": [
        {
          "k": "框架层级",
          "v": "二级框架"
        }
      ],
      "evidence": [
        {
          "type": "推荐实践",
          "author": "Golden DBK, Wang J, Waserman S, et al.",
          "title": "过敏反应：2023 年实践参数更新",
          "journal": "变态反应、哮喘与免疫学年鉴",
          "year": 2024,
          "cite": "Golden DBK, Wang J, Waserman S, et al. / 过敏反应：2023 年实践参数更新 / 变态反应、哮喘与免疫学年鉴 / 2024",
          "grade": "推荐意见",
          "ref": "R16"
        },
        {
          "type": "声明",
          "author": "Wang C, Ramsey A, Lang D, et al.",
          "title": "放射性对比剂超敏反应的管理与预防：美国放射学会与美国变态反应、哮喘与免疫学会共识声明",
          "journal": "放射学",
          "year": 2025,
          "cite": "Wang C, Ramsey A, Lang D, et al. / 放射性对比剂超敏反应的管理与预防：美国放射学会与美国变态反应、哮喘与免疫学会共识声明 / 放射学 / 2025",
          "grade": "学会声明",
          "ref": "R12"
        },
        {
          "type": "建议",
          "author": "Brockow K",
          "title": "放射性对比剂超敏反应处理流程（2024 年更新）",
          "journal": "变态反应",
          "year": 2024,
          "cite": "Brockow K / 放射性对比剂超敏反应处理流程（2024 年更新） / 变态反应 / 2024",
          "grade": "推荐意见",
          "ref": "R13"
        },
        {
          "type": "共识",
          "author": "中华医学会放射学分会放射护理专业委员会放射诊断护理学组（执笔：李雪、郑淑梅、屈梅香）",
          "title": "影像科碘对比剂输注安全专家共识",
          "journal": "介入放射学杂志",
          "year": 2018,
          "cite": "中华医学会放射学分会放射护理专业委员会放射诊断护理学组（执笔：李雪、郑淑梅、屈梅香） / 影像科碘对比剂输注安全专家共识 / 介入放射学杂志 / 2018",
          "grade": "指南与共识",
          "ref": "R07"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "FW_NonPharmacologicalManagement",
      "name": "非药物管理",
      "type": "NonPharmacologicalManagement",
      "tags": [
        "知识框架",
        "二级框架"
      ],
      "aliases": [
        "非药物管理"
      ],
      "summary": "论文表 1「非药物管理」二级框架。论文第 20 页写明：点击「非药物管理」实体节点，Web 端返回其关联实体节点。收录非药物处置 —— 立即停止注射、保留静脉留置针、患肢抬高、局部冷敷、密切观察、对比剂预处理、血管可视化、心理疏导。",
      "attrs": [
        {
          "k": "框架层级",
          "v": "二级框架"
        }
      ],
      "evidence": [
        {
          "type": "指南",
          "author": "Roditi G, Khan N, van der Molen AJ, et al.",
          "title": "静脉对比剂外渗：系统评价及欧洲泌尿生殖放射学会对比剂安全委员会指南更新",
          "journal": "欧洲放射学杂志",
          "year": 2022,
          "cite": "Roditi G, Khan N, van der Molen AJ, et al. / 静脉对比剂外渗：系统评价及欧洲泌尿生殖放射学会对比剂安全委员会指南更新 / 欧洲放射学杂志 / 2022",
          "grade": "指南与共识",
          "ref": "R02"
        },
        {
          "type": "指南",
          "author": "中华护理学会放射介入护理专业委员会（执笔：张红梅、张素、刘宇）",
          "title": "含碘对比剂静脉外渗护理管理实践指南（2026年更新版）",
          "journal": "中华护理杂志",
          "year": 2026,
          "cite": "中华护理学会放射介入护理专业委员会（执笔：张红梅、张素、刘宇） / 含碘对比剂静脉外渗护理管理实践指南（2026年更新版） / 中华护理杂志 / 2026",
          "grade": "指南与共识",
          "ref": "R04"
        },
        {
          "type": "共识",
          "author": "中华医学会放射学分会放射护理专业委员会放射诊断护理学组（执笔：李雪、郑淑梅、屈梅香）",
          "title": "影像科碘对比剂输注安全专家共识",
          "journal": "介入放射学杂志",
          "year": 2018,
          "cite": "中华医学会放射学分会放射护理专业委员会放射诊断护理学组（执笔：李雪、郑淑梅、屈梅香） / 影像科碘对比剂输注安全专家共识 / 介入放射学杂志 / 2018",
          "grade": "指南与共识",
          "ref": "R07"
        },
        {
          "type": "指南",
          "author": "美国放射学会药物与对比剂委员会",
          "title": "美国放射学会对比剂手册",
          "journal": "美国放射学会",
          "year": 2024,
          "cite": "美国放射学会药物与对比剂委员会 / 美国放射学会对比剂手册 / 美国放射学会 / 2024",
          "grade": "指南与共识",
          "ref": "R01"
        },
        {
          "type": "指南",
          "author": "中华医学会放射学分会对比剂安全使用工作组",
          "title": "碘对比剂使用指南（第2版）",
          "journal": "中华放射学杂志",
          "year": 2013,
          "cite": "中华医学会放射学分会对比剂安全使用工作组 / 碘对比剂使用指南（第2版） / 中华放射学杂志 / 2013",
          "grade": "指南与共识",
          "ref": "R03"
        },
        {
          "type": "规范",
          "author": "江西省市场监督管理局",
          "title": "DB36/T 2299—2026 含碘对比剂静脉外渗预防与护理规范",
          "journal": "江西省市场监督管理局（地方标准）",
          "year": 2026,
          "cite": "江西省市场监督管理局 / DB36/T 2299—2026 含碘对比剂静脉外渗预防与护理规范 / 江西省市场监督管理局（地方标准） / 2026",
          "grade": "标准与规范",
          "ref": "R09"
        },
        {
          "type": "Meta分析",
          "author": "Nawras M, Alyousif Z, Beran A, Elsamaloty H",
          "title": "碘对比剂温度与不良反应的关系：307,329 次注射的 Meta 分析",
          "journal": "临床影像学",
          "year": 2023,
          "cite": "Nawras M, Alyousif Z, Beran A, Elsamaloty H / 碘对比剂温度与不良反应的关系：307,329 次注射的 Meta 分析 / 临床影像学 / 2023 · DOI 10.1016/j.clinimag.2023.05.006 · PMID 37216743"
        },
        {
          "type": "标准",
          "author": "国家卫生健康委员会",
          "title": "WS/T 433—2023 静脉治疗护理技术操作标准",
          "journal": "国家卫生健康委员会（卫生行业标准）",
          "year": 2023,
          "cite": "国家卫生健康委员会 / WS/T 433—2023 静脉治疗护理技术操作标准 / 国家卫生健康委员会（卫生行业标准） / 2023",
          "grade": "标准与规范",
          "ref": "R08"
        },
        {
          "type": "书籍",
          "author": "秦月兰、郑淑梅、刘雪莲",
          "title": "影像护理学",
          "journal": "人民卫生出版社",
          "year": 2020,
          "cite": "秦月兰、郑淑梅、刘雪莲 / 影像护理学 / 人民卫生出版社 / 2020",
          "grade": "教材",
          "ref": "R20"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "FW_SymptomStatus",
      "name": "症状现状",
      "type": "SymptomStatus",
      "tags": [
        "知识框架",
        "二级框架"
      ],
      "aliases": [
        "症状现状"
      ],
      "summary": "论文表 1「症状现状」二级框架。收录症状现状 —— 轻度反应已缓解、重度反应已恢复。（在本题数据里，这两个节点是护理措施 / 护理干预 / 外渗处置原则的「影响」目标，故归在处置原则之下。）",
      "attrs": [
        {
          "k": "框架层级",
          "v": "二级框架"
        }
      ],
      "evidence": [
        {
          "type": "声明",
          "author": "Wang C, Ramsey A, Lang D, et al.",
          "title": "放射性对比剂超敏反应的管理与预防：美国放射学会与美国变态反应、哮喘与免疫学会共识声明",
          "journal": "放射学",
          "year": 2025,
          "cite": "Wang C, Ramsey A, Lang D, et al. / 放射性对比剂超敏反应的管理与预防：美国放射学会与美国变态反应、哮喘与免疫学会共识声明 / 放射学 / 2025",
          "grade": "学会声明",
          "ref": "R12"
        },
        {
          "type": "共识",
          "author": "中华医学会放射学分会放射护理专业委员会放射诊断护理学组（执笔：李雪、郑淑梅、屈梅香）",
          "title": "影像科碘对比剂输注安全专家共识",
          "journal": "介入放射学杂志",
          "year": 2018,
          "cite": "中华医学会放射学分会放射护理专业委员会放射诊断护理学组（执笔：李雪、郑淑梅、屈梅香） / 影像科碘对比剂输注安全专家共识 / 介入放射学杂志 / 2018",
          "grade": "指南与共识",
          "ref": "R07"
        },
        {
          "type": "推荐实践",
          "author": "Golden DBK, Wang J, Waserman S, et al.",
          "title": "过敏反应：2023 年实践参数更新",
          "journal": "变态反应、哮喘与免疫学年鉴",
          "year": 2024,
          "cite": "Golden DBK, Wang J, Waserman S, et al. / 过敏反应：2023 年实践参数更新 / 变态反应、哮喘与免疫学年鉴 / 2024",
          "grade": "推荐意见",
          "ref": "R16"
        },
        {
          "type": "建议",
          "author": "Brockow K",
          "title": "放射性对比剂超敏反应处理流程（2024 年更新）",
          "journal": "变态反应",
          "year": 2024,
          "cite": "Brockow K / 放射性对比剂超敏反应处理流程（2024 年更新） / 变态反应 / 2024",
          "grade": "推荐意见",
          "ref": "R13"
        }
      ],
      "graph": "topic-01"
    },
    {
      "id": "FW_FunctionalStatus",
      "name": "功能状况",
      "type": "FunctionalStatus",
      "tags": [
        "知识框架",
        "二级框架"
      ],
      "aliases": [
        "功能状况"
      ],
      "summary": "论文表 1「功能状况」二级框架。收录功能状况 —— 患肢功能状态。（在本题数据里，该节点是护理干预的「影响」目标，故归在处置原则之下。）",
      "attrs": [
        {
          "k": "框架层级",
          "v": "二级框架"
        }
      ],
      "evidence": [
        {
          "type": "指南",
          "author": "中华护理学会放射介入护理专业委员会（执笔：张红梅、张素、刘宇）",
          "title": "含碘对比剂静脉外渗护理管理实践指南（2026年更新版）",
          "journal": "中华护理杂志",
          "year": 2026,
          "cite": "中华护理学会放射介入护理专业委员会（执笔：张红梅、张素、刘宇） / 含碘对比剂静脉外渗护理管理实践指南（2026年更新版） / 中华护理杂志 / 2026",
          "grade": "指南与共识",
          "ref": "R04"
        },
        {
          "type": "指南",
          "author": "Roditi G, Khan N, van der Molen AJ, et al.",
          "title": "静脉对比剂外渗：系统评价及欧洲泌尿生殖放射学会对比剂安全委员会指南更新",
          "journal": "欧洲放射学杂志",
          "year": 2022,
          "cite": "Roditi G, Khan N, van der Molen AJ, et al. / 静脉对比剂外渗：系统评价及欧洲泌尿生殖放射学会对比剂安全委员会指南更新 / 欧洲放射学杂志 / 2022",
          "grade": "指南与共识",
          "ref": "R02"
        }
      ],
      "graph": "topic-01"
    }
  ],
  "edges": [
    {
      "source": "S_Urticaria",
      "target": "S_Rash",
      "type": "BELONGS_TO",
      "label": "属于"
    },
    {
      "source": "S_Rash",
      "target": "SC_Hypersensitivity",
      "type": "BELONGS_TO",
      "label": "属于"
    },
    {
      "source": "S_AllergicReaction",
      "target": "SC_Hypersensitivity",
      "type": "BELONGS_TO",
      "label": "属于"
    },
    {
      "source": "S_AnaphylacticShock",
      "target": "SC_Hypersensitivity",
      "type": "BELONGS_TO",
      "label": "属于"
    },
    {
      "source": "S_FacialEdema",
      "target": "SC_Hypersensitivity",
      "type": "BELONGS_TO",
      "label": "属于"
    },
    {
      "source": "S_ThroatDiscomfort",
      "target": "SC_Hypersensitivity",
      "type": "BELONGS_TO",
      "label": "属于"
    },
    {
      "source": "S_ChestTightness",
      "target": "SC_Hypersensitivity",
      "type": "BELONGS_TO",
      "label": "属于"
    },
    {
      "source": "S_GeneralizedWeakness",
      "target": "SC_Hypersensitivity",
      "type": "BELONGS_TO",
      "label": "属于"
    },
    {
      "source": "S_Pruritus",
      "target": "SC_Hypersensitivity",
      "type": "BELONGS_TO",
      "label": "属于"
    },
    {
      "source": "S_Extravasation",
      "target": "SC_ExtravasationSpectrum",
      "type": "BELONGS_TO",
      "label": "属于"
    },
    {
      "source": "S_AdverseReaction",
      "target": "SC_AdverseSpectrum",
      "type": "BELONGS_TO",
      "label": "属于"
    },
    {
      "source": "SC_Hypersensitivity",
      "target": "SC_AdverseSpectrum",
      "type": "BELONGS_TO",
      "label": "属于"
    },
    {
      "source": "SC_ExtravasationSpectrum",
      "target": "SC_AdverseSpectrum",
      "type": "BELONGS_TO",
      "label": "属于"
    },
    {
      "source": "MP_NursingIntervention",
      "target": "NT_EarlyWarning",
      "type": "BELONGS_TO",
      "label": "属于"
    },
    {
      "source": "MP_ExtravasationPrinciple",
      "target": "MP_NursingMeasures",
      "type": "BELONGS_TO",
      "label": "属于"
    },
    {
      "source": "MP_AdverseReactionTriage",
      "target": "MP_NursingMeasures",
      "type": "BELONGS_TO",
      "label": "属于"
    },
    {
      "source": "DC_CTEnhancedRisk",
      "target": "S_AdverseReaction",
      "type": "HAS_SYMPTOM",
      "label": "存在症状"
    },
    {
      "source": "DC_CTEnhancedRisk",
      "target": "S_AllergicReaction",
      "type": "HAS_SYMPTOM",
      "label": "存在症状"
    },
    {
      "source": "DC_CTEnhancedRisk",
      "target": "S_Extravasation",
      "type": "HAS_SYMPTOM",
      "label": "存在症状"
    },
    {
      "source": "E_CTEnhancedScan",
      "target": "S_AdverseReaction",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "E_CTEnhancedScan",
      "target": "S_Extravasation",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "E_ContrastInjection",
      "target": "S_AllergicReaction",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "E_ContrastInjection",
      "target": "S_Extravasation",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "E_ContrastInjection",
      "target": "S_AdverseReaction",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "S_AllergicReaction",
      "target": "S_AnaphylacticShock",
      "type": "HAS_SYMPTOM",
      "label": "存在症状"
    },
    {
      "source": "S_AllergicReaction",
      "target": "S_Urticaria",
      "type": "HAS_SYMPTOM",
      "label": "存在症状"
    },
    {
      "source": "S_AllergicReaction",
      "target": "S_FacialEdema",
      "type": "HAS_SYMPTOM",
      "label": "存在症状"
    },
    {
      "source": "S_AllergicReaction",
      "target": "S_ThroatDiscomfort",
      "type": "HAS_SYMPTOM",
      "label": "存在症状"
    },
    {
      "source": "S_AllergicReaction",
      "target": "S_ChestTightness",
      "type": "HAS_SYMPTOM",
      "label": "存在症状"
    },
    {
      "source": "S_AllergicReaction",
      "target": "S_GeneralizedWeakness",
      "type": "HAS_SYMPTOM",
      "label": "存在症状"
    },
    {
      "source": "S_Urticaria",
      "target": "S_Pruritus",
      "type": "HAS_SYMPTOM",
      "label": "存在症状"
    },
    {
      "source": "DC_CTEnhancedRisk",
      "target": "MP_NursingMeasures",
      "type": "MANAGED_BY",
      "label": "由……处置"
    },
    {
      "source": "DC_CTEnhancedRisk",
      "target": "MP_NursingPrevention",
      "type": "MANAGED_BY",
      "label": "由……处置"
    },
    {
      "source": "S_AdverseReaction",
      "target": "MP_NursingMeasures",
      "type": "MANAGED_BY",
      "label": "由……处置"
    },
    {
      "source": "S_AdverseReaction",
      "target": "MP_AdverseReactionTriage",
      "type": "MANAGED_BY",
      "label": "由……处置"
    },
    {
      "source": "S_AllergicReaction",
      "target": "MP_NursingMeasures",
      "type": "MANAGED_BY",
      "label": "由……处置"
    },
    {
      "source": "S_AllergicReaction",
      "target": "MP_NursingIntervention",
      "type": "MANAGED_BY",
      "label": "由……处置"
    },
    {
      "source": "S_AllergicReaction",
      "target": "MP_AdverseReactionTriage",
      "type": "MANAGED_BY",
      "label": "由……处置"
    },
    {
      "source": "S_AllergicReaction",
      "target": "NT_EarlyWarning",
      "type": "MANAGED_BY",
      "label": "由……处置"
    },
    {
      "source": "S_AnaphylacticShock",
      "target": "MP_NursingIntervention",
      "type": "MANAGED_BY",
      "label": "由……处置"
    },
    {
      "source": "S_AnaphylacticShock",
      "target": "MP_AdverseReactionTriage",
      "type": "MANAGED_BY",
      "label": "由……处置"
    },
    {
      "source": "S_Urticaria",
      "target": "MP_NursingIntervention",
      "type": "MANAGED_BY",
      "label": "由……处置"
    },
    {
      "source": "S_Pruritus",
      "target": "MP_NursingMeasures",
      "type": "MANAGED_BY",
      "label": "由……处置"
    },
    {
      "source": "S_Rash",
      "target": "MP_NursingMeasures",
      "type": "MANAGED_BY",
      "label": "由……处置"
    },
    {
      "source": "S_FacialEdema",
      "target": "MP_NursingIntervention",
      "type": "MANAGED_BY",
      "label": "由……处置"
    },
    {
      "source": "S_ThroatDiscomfort",
      "target": "MP_NursingIntervention",
      "type": "MANAGED_BY",
      "label": "由……处置"
    },
    {
      "source": "S_ChestTightness",
      "target": "MP_NursingIntervention",
      "type": "MANAGED_BY",
      "label": "由……处置"
    },
    {
      "source": "S_GeneralizedWeakness",
      "target": "MP_NursingIntervention",
      "type": "MANAGED_BY",
      "label": "由……处置"
    },
    {
      "source": "S_Extravasation",
      "target": "MP_NursingIntervention",
      "type": "MANAGED_BY",
      "label": "由……处置"
    },
    {
      "source": "S_Extravasation",
      "target": "MP_ExtravasationPrinciple",
      "type": "MANAGED_BY",
      "label": "由……处置"
    },
    {
      "source": "E_CTEnhancedScan",
      "target": "MP_NursingPrevention",
      "type": "MANAGED_BY",
      "label": "由……处置"
    },
    {
      "source": "E_ContrastInjection",
      "target": "MP_NursingPrevention",
      "type": "MANAGED_BY",
      "label": "由……处置"
    },
    {
      "source": "DC_CTEnhancedRisk",
      "target": "DE_PreExamNotice",
      "type": "EDUCATED_BY",
      "label": "由……教育"
    },
    {
      "source": "DC_CTEnhancedRisk",
      "target": "DE_AfterExamCare",
      "type": "EDUCATED_BY",
      "label": "由……教育"
    },
    {
      "source": "DC_CTEnhancedRisk",
      "target": "DE_AllergyDisclosure",
      "type": "EDUCATED_BY",
      "label": "由……教育"
    },
    {
      "source": "DC_CTEnhancedRisk",
      "target": "DE_ExtravasationHomeCare",
      "type": "EDUCATED_BY",
      "label": "由……教育"
    },
    {
      "source": "DC_CTEnhancedRisk",
      "target": "DE_EmergencyKnowledge",
      "type": "EDUCATED_BY",
      "label": "由……教育"
    },
    {
      "source": "E_ContrastInjection",
      "target": "DE_PreExamNotice",
      "type": "EDUCATED_BY",
      "label": "由……教育"
    },
    {
      "source": "S_Extravasation",
      "target": "DE_ExtravasationHomeCare",
      "type": "EDUCATED_BY",
      "label": "由……教育"
    },
    {
      "source": "S_AnaphylacticShock",
      "target": "DE_EmergencyKnowledge",
      "type": "EDUCATED_BY",
      "label": "由……教育"
    },
    {
      "source": "S_AllergicReaction",
      "target": "AT_AllergyHistory",
      "type": "ASSESSED_BY",
      "label": "由……评估"
    },
    {
      "source": "S_AnaphylacticShock",
      "target": "AT_AllergyHistory",
      "type": "ASSESSED_BY",
      "label": "由……评估"
    },
    {
      "source": "S_AdverseReaction",
      "target": "AT_AllergyHistory",
      "type": "ASSESSED_BY",
      "label": "由……评估"
    },
    {
      "source": "S_Urticaria",
      "target": "AT_AllergyHistory",
      "type": "ASSESSED_BY",
      "label": "由……评估"
    },
    {
      "source": "S_Extravasation",
      "target": "AT_ExtravasationAssessment",
      "type": "ASSESSED_BY",
      "label": "由……评估"
    },
    {
      "source": "S_Extravasation",
      "target": "AT_VascularAssessment",
      "type": "ASSESSED_BY",
      "label": "由……评估"
    },
    {
      "source": "S_AllergicReaction",
      "target": "RF_ContrastAllergyHistory",
      "type": "AT_RISK_BY",
      "label": "风险来自"
    },
    {
      "source": "S_AllergicReaction",
      "target": "RF_UncontrolledAsthma",
      "type": "AT_RISK_BY",
      "label": "风险来自"
    },
    {
      "source": "S_AnaphylacticShock",
      "target": "RF_ContrastAllergyHistory",
      "type": "AT_RISK_BY",
      "label": "风险来自"
    },
    {
      "source": "S_AnaphylacticShock",
      "target": "RF_UncontrolledAsthma",
      "type": "AT_RISK_BY",
      "label": "风险来自"
    },
    {
      "source": "S_AnaphylacticShock",
      "target": "RF_AgeExtremes",
      "type": "AT_RISK_BY",
      "label": "风险来自"
    },
    {
      "source": "S_Extravasation",
      "target": "RF_FragileVein",
      "type": "AT_RISK_BY",
      "label": "风险来自"
    },
    {
      "source": "S_Extravasation",
      "target": "RF_HighPressureInjection",
      "type": "AT_RISK_BY",
      "label": "风险来自"
    },
    {
      "source": "S_Extravasation",
      "target": "RF_NoSalineFlush",
      "type": "AT_RISK_BY",
      "label": "风险来自"
    },
    {
      "source": "S_Extravasation",
      "target": "RF_AgeExtremes",
      "type": "AT_RISK_BY",
      "label": "风险来自"
    },
    {
      "source": "S_AdverseReaction",
      "target": "RF_ContrastAllergyHistory",
      "type": "AT_RISK_BY",
      "label": "风险来自"
    },
    {
      "source": "S_Rash",
      "target": "RF_ContrastAllergyHistory",
      "type": "AT_RISK_BY",
      "label": "风险来自"
    },
    {
      "source": "S_Urticaria",
      "target": "RF_ContrastAllergyHistory",
      "type": "AT_RISK_BY",
      "label": "风险来自"
    },
    {
      "source": "S_Pruritus",
      "target": "RF_ContrastAllergyHistory",
      "type": "AT_RISK_BY",
      "label": "风险来自"
    },
    {
      "source": "S_FacialEdema",
      "target": "RF_ContrastAllergyHistory",
      "type": "AT_RISK_BY",
      "label": "风险来自"
    },
    {
      "source": "S_ThroatDiscomfort",
      "target": "RF_ContrastAllergyHistory",
      "type": "AT_RISK_BY",
      "label": "风险来自"
    },
    {
      "source": "S_AnaphylacticShock",
      "target": "PM_AdrenalineIM",
      "type": "TREATED_BY",
      "label": "由……治疗",
      "note": "大腿外侧中部肌内注射，必要时每 5～15 分钟重复"
    },
    {
      "source": "S_AnaphylacticShock",
      "target": "PM_Corticosteroid",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "S_AllergicReaction",
      "target": "PM_Antihistamine",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "S_AllergicReaction",
      "target": "PM_Corticosteroid",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "S_Urticaria",
      "target": "PM_Antihistamine",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "S_Rash",
      "target": "PM_Antihistamine",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "S_Pruritus",
      "target": "PM_Antihistamine",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "S_FacialEdema",
      "target": "PM_Corticosteroid",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "S_Extravasation",
      "target": "PM_MagnesiumSulfate",
      "type": "TREATED_BY",
      "label": "由……治疗",
      "note": "早期冷敷使用"
    },
    {
      "source": "S_Extravasation",
      "target": "PM_DexamethasoneWetCompress",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "S_Extravasation",
      "target": "NPM_StopInjection",
      "type": "TREATED_BY",
      "label": "由……治疗",
      "note": "第一步：立即停止推注"
    },
    {
      "source": "S_Extravasation",
      "target": "NPM_KeepCatheter",
      "type": "TREATED_BY",
      "label": "由……治疗",
      "note": "第二步：保留留置针并尽量回抽"
    },
    {
      "source": "S_Extravasation",
      "target": "NPM_LimbElevation",
      "type": "TREATED_BY",
      "label": "由……治疗",
      "note": "禁止局部按压揉搓"
    },
    {
      "source": "S_Extravasation",
      "target": "NPM_ColdCompress",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "S_Extravasation",
      "target": "NPM_VascularVisualization",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "S_AdverseReaction",
      "target": "NPM_CloseObservation",
      "type": "TREATED_BY",
      "label": "由……治疗",
      "note": "轻度反应观察 30 分钟"
    },
    {
      "source": "S_AnaphylacticShock",
      "target": "NPM_CloseObservation",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "S_AllergicReaction",
      "target": "NPM_CloseObservation",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "E_CTEnhancedScan",
      "target": "NPM_ContrastPreparation",
      "type": "TREATED_BY",
      "label": "由……治疗",
      "note": "对比剂加温至 37℃ 左右"
    },
    {
      "source": "E_ContrastInjection",
      "target": "NPM_ContrastPreparation",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "E_ContrastInjection",
      "target": "NPM_VascularVisualization",
      "type": "TREATED_BY",
      "label": "由……治疗",
      "note": "使用耐高压型留置针，优先肘正中静脉"
    },
    {
      "source": "S_AdverseReaction",
      "target": "NPM_PsychologicalSupport",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "S_Extravasation",
      "target": "NPM_PsychologicalSupport",
      "type": "TREATED_BY",
      "label": "由……治疗"
    },
    {
      "source": "MP_NursingIntervention",
      "target": "SS_SevereRecovered",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "MP_NursingMeasures",
      "target": "SS_MildResolved",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "MP_ExtravasationPrinciple",
      "target": "SS_MildResolved",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "MP_AdverseReactionTriage",
      "target": "SS_MildResolved",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "MP_NursingIntervention",
      "target": "FS_LimbFunction",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "MP_ExtravasationPrinciple",
      "target": "FS_LimbFunction",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "SS_MildResolved",
      "target": "FS_LimbFunction",
      "type": "EFFECT_ON",
      "label": "影响"
    },
    {
      "source": "DC_CTEnhancedRisk",
      "target": "R01",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "DC_CTEnhancedRisk",
      "target": "R03",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "E_CTEnhancedScan",
      "target": "R01",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "E_CTEnhancedScan",
      "target": "R03",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "E_ContrastInjection",
      "target": "R01",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "E_ContrastInjection",
      "target": "R03",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "E_ContrastInjection",
      "target": "R07",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "S_AdverseReaction",
      "target": "R01",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "S_AdverseReaction",
      "target": "R12",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "S_AdverseReaction",
      "target": "R14",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "S_Rash",
      "target": "R12",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "S_Rash",
      "target": "R13",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "S_AllergicReaction",
      "target": "R12",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "S_AllergicReaction",
      "target": "R13",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "S_AllergicReaction",
      "target": "R14",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "S_Urticaria",
      "target": "R12",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "S_Urticaria",
      "target": "R13",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "S_Urticaria",
      "target": "R16",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "S_Pruritus",
      "target": "R12",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "S_Pruritus",
      "target": "R16",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "S_FacialEdema",
      "target": "R12",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "S_FacialEdema",
      "target": "R13",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "S_ThroatDiscomfort",
      "target": "R12",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "S_ThroatDiscomfort",
      "target": "R16",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "S_ChestTightness",
      "target": "R12",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "S_ChestTightness",
      "target": "R13",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "S_GeneralizedWeakness",
      "target": "R12",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "S_GeneralizedWeakness",
      "target": "R16",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "S_AnaphylacticShock",
      "target": "R16",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "S_AnaphylacticShock",
      "target": "R12",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "S_AnaphylacticShock",
      "target": "R13",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "S_Extravasation",
      "target": "R02",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "S_Extravasation",
      "target": "R04",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "S_Extravasation",
      "target": "R17",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "S_Extravasation",
      "target": "R09",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "SC_AdverseSpectrum",
      "target": "R01",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "SC_Hypersensitivity",
      "target": "R12",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "SC_ExtravasationSpectrum",
      "target": "R02",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "AT_AllergyHistory",
      "target": "R03",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "AT_AllergyHistory",
      "target": "R12",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "AT_ExtravasationAssessment",
      "target": "R04",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "AT_ExtravasationAssessment",
      "target": "R17",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "AT_VascularAssessment",
      "target": "R08",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "AT_VascularAssessment",
      "target": "R09",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "RF_ContrastAllergyHistory",
      "target": "R12",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "RF_ContrastAllergyHistory",
      "target": "R13",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "RF_UncontrolledAsthma",
      "target": "R12",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "RF_UncontrolledAsthma",
      "target": "R13",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "RF_AgeExtremes",
      "target": "R04",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "RF_AgeExtremes",
      "target": "R17",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "RF_FragileVein",
      "target": "R04",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "RF_FragileVein",
      "target": "R17",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "RF_HighPressureInjection",
      "target": "R02",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "RF_HighPressureInjection",
      "target": "R04",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "RF_HighPressureInjection",
      "target": "R17",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "RF_NoSalineFlush",
      "target": "R04",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "RF_NoSalineFlush",
      "target": "R09",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "PM_AdrenalineIM",
      "target": "R16",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "PM_AdrenalineIM",
      "target": "R12",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "PM_Corticosteroid",
      "target": "R12",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "PM_Corticosteroid",
      "target": "R13",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "PM_Antihistamine",
      "target": "R12",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "PM_Antihistamine",
      "target": "R13",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "PM_MagnesiumSulfate",
      "target": "R07",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "PM_DexamethasoneWetCompress",
      "target": "R07",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "NPM_StopInjection",
      "target": "R02",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "NPM_StopInjection",
      "target": "R04",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "NPM_KeepCatheter",
      "target": "R02",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "NPM_KeepCatheter",
      "target": "R04",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "NPM_LimbElevation",
      "target": "R02",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "NPM_LimbElevation",
      "target": "R04",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "NPM_LimbElevation",
      "target": "R07",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "NPM_ColdCompress",
      "target": "R02",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "NPM_ColdCompress",
      "target": "R07",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "NPM_CloseObservation",
      "target": "R07",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "NPM_CloseObservation",
      "target": "R01",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "NPM_ContrastPreparation",
      "target": "R03",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "NPM_ContrastPreparation",
      "target": "R09",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "NPM_VascularVisualization",
      "target": "R08",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "NPM_VascularVisualization",
      "target": "R04",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "NPM_PsychologicalSupport",
      "target": "R20",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "MP_NursingMeasures",
      "target": "R04",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "MP_NursingMeasures",
      "target": "R07",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "MP_NursingMeasures",
      "target": "R01",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "MP_NursingPrevention",
      "target": "R04",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "MP_NursingPrevention",
      "target": "R09",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "MP_NursingPrevention",
      "target": "R02",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "MP_NursingIntervention",
      "target": "R04",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "MP_NursingIntervention",
      "target": "R16",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "MP_NursingIntervention",
      "target": "R02",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "MP_ExtravasationPrinciple",
      "target": "R02",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "MP_ExtravasationPrinciple",
      "target": "R04",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "MP_ExtravasationPrinciple",
      "target": "R07",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "MP_AdverseReactionTriage",
      "target": "R12",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "MP_AdverseReactionTriage",
      "target": "R13",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "MP_AdverseReactionTriage",
      "target": "R01",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "NT_EarlyWarning",
      "target": "R13",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "NT_EarlyWarning",
      "target": "R16",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "DE_PreExamNotice",
      "target": "R03",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "DE_PreExamNotice",
      "target": "R20",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "DE_AfterExamCare",
      "target": "R01",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "DE_AfterExamCare",
      "target": "R07",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "DE_AfterExamCare",
      "target": "R20",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "DE_AllergyDisclosure",
      "target": "R12",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "DE_AllergyDisclosure",
      "target": "R03",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "DE_ExtravasationHomeCare",
      "target": "R04",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "DE_ExtravasationHomeCare",
      "target": "R02",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "DE_EmergencyKnowledge",
      "target": "R16",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "DE_EmergencyKnowledge",
      "target": "R13",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "SS_MildResolved",
      "target": "R12",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "SS_MildResolved",
      "target": "R07",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "SS_SevereRecovered",
      "target": "R16",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "SS_SevereRecovered",
      "target": "R13",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "FS_LimbFunction",
      "target": "R04",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "FS_LimbFunction",
      "target": "R02",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "S_Extravasation",
      "target": "R10",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "E_CTEnhancedScan",
      "target": "R10",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "NPM_ContrastPreparation",
      "target": "R21",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "S_AllergicReaction",
      "target": "R21",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "S_Extravasation",
      "target": "R21",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "S_Extravasation",
      "target": "R22",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "AT_ExtravasationAssessment",
      "target": "R22",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "S_AllergicReaction",
      "target": "R23",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "RF_UncontrolledAsthma",
      "target": "R23",
      "type": "SUPPORTED_BY",
      "label": "有文献支持"
    },
    {
      "source": "S_Extravasation",
      "target": "S_ExtravasationSwelling",
      "type": "HAS_SYMPTOM",
      "label": "存在症状"
    },
    {
      "source": "S_Extravasation",
      "target": "S_ExtravasationPain",
      "type": "HAS_SYMPTOM",
      "label": "存在症状"
    },
    {
      "source": "S_Extravasation",
      "target": "S_ExtravasationRedness",
      "type": "HAS_SYMPTOM",
      "label": "存在症状"
    },
    {
      "source": "S_Extravasation",
      "target": "S_ExtravasationCoolSkin",
      "type": "HAS_SYMPTOM",
      "label": "存在症状"
    },
    {
      "source": "S_Extravasation",
      "target": "S_ExtravasationPallor",
      "type": "HAS_SYMPTOM",
      "label": "存在症状"
    },
    {
      "source": "DC_CTEnhancedRisk",
      "target": "MP_NursingIntervention",
      "type": "MANAGED_BY",
      "label": "由……处置"
    },
    {
      "source": "FW_SymptomCategory",
      "target": "FW_SymptomSign",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "FW_AssessmentTool",
      "target": "FW_SymptomSign",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "FW_RiskFactor",
      "target": "FW_ManagementPrinciple",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "FW_PharmacologicalManagement",
      "target": "FW_ManagementPrinciple",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "FW_NonPharmacologicalManagement",
      "target": "FW_ManagementPrinciple",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "FW_SymptomStatus",
      "target": "FW_ManagementPrinciple",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "FW_FunctionalStatus",
      "target": "FW_ManagementPrinciple",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "FW_SymptomSign",
      "target": "S_AdverseReaction",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "FW_SymptomSign",
      "target": "S_Rash",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "FW_SymptomSign",
      "target": "S_AllergicReaction",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "FW_SymptomSign",
      "target": "S_Urticaria",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "FW_SymptomSign",
      "target": "S_Pruritus",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "FW_SymptomSign",
      "target": "S_FacialEdema",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "FW_SymptomSign",
      "target": "S_ThroatDiscomfort",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "FW_SymptomSign",
      "target": "S_ChestTightness",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "FW_SymptomSign",
      "target": "S_GeneralizedWeakness",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "FW_SymptomSign",
      "target": "S_AnaphylacticShock",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "FW_SymptomSign",
      "target": "S_Extravasation",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "FW_SymptomSign",
      "target": "S_ExtravasationSwelling",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "FW_SymptomSign",
      "target": "S_ExtravasationPain",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "FW_SymptomSign",
      "target": "S_ExtravasationRedness",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "FW_SymptomSign",
      "target": "S_ExtravasationCoolSkin",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "FW_SymptomSign",
      "target": "S_ExtravasationPallor",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "FW_Exam",
      "target": "E_CTEnhancedScan",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "FW_Exam",
      "target": "E_ContrastInjection",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "FW_ManagementPrinciple",
      "target": "MP_NursingMeasures",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "FW_ManagementPrinciple",
      "target": "MP_NursingPrevention",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "FW_ManagementPrinciple",
      "target": "MP_NursingIntervention",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "FW_ManagementPrinciple",
      "target": "MP_ExtravasationPrinciple",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "FW_ManagementPrinciple",
      "target": "MP_AdverseReactionTriage",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "FW_NursingTheory",
      "target": "NT_EarlyWarning",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "FW_NursingTheory",
      "target": "NT_SelfCareTheory",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "FW_DiseaseEducation",
      "target": "DE_PreExamNotice",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "FW_DiseaseEducation",
      "target": "DE_AfterExamCare",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "FW_DiseaseEducation",
      "target": "DE_AllergyDisclosure",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "FW_DiseaseEducation",
      "target": "DE_ExtravasationHomeCare",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "FW_DiseaseEducation",
      "target": "DE_EmergencyKnowledge",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "FW_SymptomCategory",
      "target": "SC_AdverseSpectrum",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "FW_SymptomCategory",
      "target": "SC_Hypersensitivity",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "FW_SymptomCategory",
      "target": "SC_ExtravasationSpectrum",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "FW_AssessmentTool",
      "target": "AT_AllergyHistory",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "FW_AssessmentTool",
      "target": "AT_ExtravasationAssessment",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "FW_AssessmentTool",
      "target": "AT_VascularAssessment",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "FW_RiskFactor",
      "target": "RF_ContrastAllergyHistory",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "FW_RiskFactor",
      "target": "RF_UncontrolledAsthma",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "FW_RiskFactor",
      "target": "RF_AgeExtremes",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "FW_RiskFactor",
      "target": "RF_FragileVein",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "FW_RiskFactor",
      "target": "RF_HighPressureInjection",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "FW_RiskFactor",
      "target": "RF_NoSalineFlush",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "FW_PharmacologicalManagement",
      "target": "PM_AdrenalineIM",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "FW_PharmacologicalManagement",
      "target": "PM_Corticosteroid",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "FW_PharmacologicalManagement",
      "target": "PM_Antihistamine",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "FW_PharmacologicalManagement",
      "target": "PM_MagnesiumSulfate",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "FW_PharmacologicalManagement",
      "target": "PM_DexamethasoneWetCompress",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "FW_NonPharmacologicalManagement",
      "target": "NPM_StopInjection",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "FW_NonPharmacologicalManagement",
      "target": "NPM_KeepCatheter",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "FW_NonPharmacologicalManagement",
      "target": "NPM_LimbElevation",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "FW_NonPharmacologicalManagement",
      "target": "NPM_ColdCompress",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "FW_NonPharmacologicalManagement",
      "target": "NPM_CloseObservation",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "FW_NonPharmacologicalManagement",
      "target": "NPM_ContrastPreparation",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "FW_NonPharmacologicalManagement",
      "target": "NPM_VascularVisualization",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "FW_NonPharmacologicalManagement",
      "target": "NPM_PsychologicalSupport",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "FW_SymptomStatus",
      "target": "SS_MildResolved",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "FW_SymptomStatus",
      "target": "SS_SevereRecovered",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "FW_FunctionalStatus",
      "target": "FS_LimbFunction",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "DC_CTEnhancedRisk",
      "target": "FW_SymptomSign",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "DC_CTEnhancedRisk",
      "target": "FW_Exam",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "DC_CTEnhancedRisk",
      "target": "FW_ManagementPrinciple",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "DC_CTEnhancedRisk",
      "target": "FW_NursingTheory",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    },
    {
      "source": "DC_CTEnhancedRisk",
      "target": "FW_DiseaseEducation",
      "type": "BELONGS_TO",
      "label": "属于",
      "role": "framework"
    }
  ]
}
;

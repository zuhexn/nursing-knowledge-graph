window.KG_PATIENT = {
  "topicKey": "topic-01",
  "intro": "这是一份关于 CT 增强扫描后碘对比剂过敏反应和碘对比剂外渗的知识地图。先看「做完增强检查后，请这样做」，再看「如果您有以下症状」。",
  "disclaimer": "本页内容整理自公开文献，用于护理与健康科普，不能替代医生的诊断和治疗。身体不适请及时就医。",
  "urgentTitle": "如果您有以下症状，请马上告诉医护人员",
  "urgent": [
    {
      "nodeId": "S_AnaphylacticShock",
      "plain": "过敏反应很重，会危及生命",
      "action": "立刻告诉医护人员并呼救，需要马上抢救"
    },
    {
      "nodeId": "S_ThroatDiscomfort",
      "plain": "嗓子发紧、像有东西卡住",
      "action": "立刻告诉医护人员，别等它自己过去"
    },
    {
      "nodeId": "S_FacialEdema",
      "plain": "面部和眼睑肿起来，提示反应正在加重",
      "action": "立刻告诉医护人员，说明是打完造影剂以后出现的"
    },
    {
      "nodeId": "S_ChestTightness",
      "plain": "胸口发闷、觉得透不过气",
      "action": "立刻告诉医护人员"
    },
    {
      "nodeId": "S_Urticaria",
      "plain": "身上成片出现的红色风团",
      "action": "立刻告诉医护人员"
    },
    {
      "nodeId": "S_Extravasation",
      "plain": "造影剂没进血管、漏到皮下，轻则肿痛，重则组织坏死",
      "action": "立刻告诉打针的护士；不要揉搓注射部位"
    }
  ],
  "aftercareTitle": "做完增强检查后，请这样做",
  "aftercare": [
    {
      "nodeId": "NPM_ObservationThenRemove",
      "plain": "做完增强检查后，请在留观区留观 30 分钟后再拔针。",
      "action": "留观期间有不舒服（头晕、恶心、心慌、皮肤发痒、喉咙发紧、喘不上气），马上告诉护士 —— 不用等留观结束。"
    }
  ],
  "urgentLead": "留观期间您可以继续多喝水。"
};

# CT增强检查护理风险 · 知识图谱（静态交付包）

> 本目录是**一份可独立拷走就用的完整交付**：前端 + 数据 + 构建脚本都在里面，
> 单独拷走这一份，照样能打开、能检索。**纯静态 · 零后端 · 全部相对路径。**

## 一、怎么打开

| 方式 | 做法 |
|---|---|
| 本地看 | 双击 `index.html`（数据走 `data/*.js` 副本，浏览器本地打开不受跨域限制）|
| 上线 | 整个目录原样丢进任意静态托管（对象存储 / CDN / 静态站点），无需服务端配置 |

⛔ 页面**不请求任何后端接口**，也**不连数据库**——数据随目录发布，检索在浏览器里算。

## 二、目录结构

```
topic-01-kg/
├── index.html                     单页图谱（力导向图 + 图例 + 检索 + 节点详情）
├── lib/echarts.min.js             图形库（本地内置 · 断网也能打开）
├── data/topic-01-graph.json     图谱数据（自包含：类型定义 + 节点 + 边 + 文献出处）
├── data/topic-01-graph.js       同一份数据的 JS 副本（页面直接读它）
├── data/topic-01-triples.csv    5 列表原件（输入形态 · 可直接重新生成图谱数据）
├── data/search-terms.json         检索词清单（校验规则第 5 条的对照夹具）
├── build.py                       构建脚本（校验 + 重新生成）
├── README.md                      本文件
└── neo4j/                         可选 · Neo4j 导入包（非运行依赖）
    ├── nodes.csv
    ├── edges.csv
    └── import.cypher
```

## 三、怎么用 build.py

```bash
# 重新校验 + 重建（Python 3.8+，只用标准库）
python build.py --input data/topic-01-graph.json --out .

# 只校验，不产出
python build.py --input data/topic-01-graph.json --check-only

# 从 5 列表转图谱数据骨架（类型, 名称, 关系, 目标类型, 目标名称）
python build.py --from-triples 三元组.csv --out-graph 图谱数据.json
```

**校验不通过 → 打印明细 + 非零退出**（不静默、不产出半成品）。判据 9 条：

1. 节点 id 全局唯一
2. 边的 source / target 都存在
3. 无重复边（source + target + type）
4. 节点 (type, name) 唯一
5. 客户检索词覆盖（对照 `data/search-terms.json`）
6. 有主张的节点类型至少 1 条文献
7. 文献四要素齐全（作者 / 标题 / 期刊 / 年份）
8. 多份数据走同一套判据（类型词汇表一致）
9. 不混题（一份数据只有一个 `graph` 取值）

## 四、检索怎么用

| 输入 | 命中通道 |
|---|---|
| 节点名称 / 别名 / 简介 / 属性 | 节点文本通道（大小写不敏感 · 首尾空格忽略 · 双向子串）|
| 文献类型（指南 / 共识 / 系统评价 / Meta 分析 …）| 文献类型通道 —— 命中**引用了该类型文献**的节点 |

英文文献类型词（`guidelines` / `systematic reviews` / `meta analysis`）与中文类型词命中**同一批节点**。
⛔ 节点级同义词（英文写法 / 旧称 / 错字写法）一律写在数据文件的 `aliases` 里，不写死在代码里。

## 五、数据说明

- 数据文件自包含：`meta`（题目元数据）· `nodeTypes`（类型定义，**样式随数据走**）·
  `relationTypes`（关系定义）· `nodes` · `edges`。
- 节点类型未在 `nodeTypes` 里声明时，页面走兜底样式，不会白屏。
- 文献出处挂在节点的 `evidence` 上，页面详情面板里逐条显示作者 / 标题 / 期刊 / 年份。
- ⛔ **没有真实出处的节点不要写进图谱** —— 校验脚本会按缺失项报出来。

## 六、Neo4j 导入包（可选）

`neo4j/` 里是给**想自己入库**的人准备的：把两个 csv 放进 Neo4j 的 import 目录，
在 Browser 里执行 `import.cypher`。它是**可选件**，页面本身不需要数据库。

---
生成于 2026-11-03 13:43
